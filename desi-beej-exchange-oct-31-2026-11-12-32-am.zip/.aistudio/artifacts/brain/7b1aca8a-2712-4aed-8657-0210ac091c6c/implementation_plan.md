# Global Automatic Location Detection & Address Autocomplete for Desi Beej Exchange

Replace the fixed city dropdown list in **Desi Beej Exchange** with a real-time worldwide **Address Autocomplete**, **GPS Current Location Detection (`Use Current Location`)**, and **Structured Location Editor** (`Country`, `State/Province`, `City`, `Area / Village / Tehsil`, and `Full Street / Mandi Address`) across the seed listing form, homepage catalog filter bar, and farmer inquiry form—while preserving every existing marketplace, chat, voice call, crops guide, and admin feature.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Location API Architecture, Free Tier Limits & API Key Details**
> - **Primary Live Global Search & Reverse Geocoding (OpenStreetMap Nominatim + Photon Geocoding API)**:
>   - **API Key Required**: **None** (100% free, no credit card or billing setup required).
>   - **Free Limits**: Supports worldwide countries, states/provinces, cities, towns, villages, chaks, and streets with a fair-use limit of **1 request per second** (enforced automatically via a 400ms input debounce and request cancellation controller).
>   - **Bilingual Support**: Queries accept both Urdu (`اردو`) and English input and return real geographical coordinates (`latitude`, `longitude`) and structured administrative boundaries.
> - **Optional Google Maps Platform Upgrade Support (`VITE_GOOGLE_MAPS_API_KEY`)**:
>   - If you configure `VITE_GOOGLE_MAPS_API_KEY` in the future, the location service automatically upgrades to Google Places / Geocoding while keeping OpenStreetMap as a seamless zero-downtime fallback.
> - **Confirmed Scope Across All 3 Surfaces**:
>   1. **Seed Listing Post & Edit Modal**: Full autocomplete search, `Use Current Location (GPS)` button, and editable structured fields (`Country`, `State/Province`, `City`, `Area/Village`, `Full Address`).
>   2. **Homepage Catalog Location Filter Bar**: Replaces the restricted 10-city dropdown with a dynamic global/local location search & GPS proximity filter (plus quick chips for active cities currently in the catalog).
>   3. **Seed Inquiry & Barter Request Form**: Replaces the plain city input with GPS one-tap detection and live address autocomplete so buyers can share their exact village, city, and country.

---

## 1. Overview & Core Concept

- **What It Does**: Enables farmers and seed buyers anywhere in Pakistan or worldwide to search any country, province/state, city, town, village, or street address with live autocomplete suggestions, detect their exact coordinates via device GPS (`Use Current Location`), inspect or edit each structured location field individually, or type their address manually if GPS permission is denied or offline.
- **Target Audience / Persona**: Pakistani and diaspora farmers, agricultural seed guardians, and buyers on mobile phones and desktop computers browsing in Urdu (RTL) or English (LTR).
- **Key Value**: Eliminates the rigid 10-city limitation so farmers from any village, tehsil, district, or country can accurately list, discover, and filter heirloom seeds using real geographical data with zero fake or hardcoded placeholder locations.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Searching an Address with Live Autocomplete**:
   - The user types a village, area, city, or country name (e.g., `"Chak 45"`, `"Sahiwal"`, `"Rahim Yar Khan"`, `"Lahore"`, `"Multan"`, or `"London"`) in Urdu or English.
   - After a 400ms debounce, a floating suggestion popover displays real matching locations from the live geocoding service, showing the primary locality name and full administrative hierarchy (`Area, City, State/Province, Country`).
   - Selecting a suggestion automatically populates and saves the structured fields: **Country (`ملک`)**, **State / Province (`صوبہ / اسٹیٹ`)**, **City / District (`شہر / ضلع`)**, **Area / Village (`علاقہ / گاؤں / تحصیل`)**, and **Full Address (`مکمل پتہ`)**.
2. **One-Tap GPS Detection (`Use Current Location | موجودہ لوکیشن استعمال کریں`)**:
   - Clicking **Use Current Location** requests browser/mobile GPS permission via `navigator.geolocation.getCurrentPosition` (with high accuracy enabled).
   - While acquiring GPS and reverse-geocoding coordinates, the button displays an animated spinner and status label (`لوکیشن معلوم کی جا رہی ہے... / Detecting GPS location...`).
   - Once resolved, all 5 structured location fields (`Country`, `State/Province`, `City`, `Area`, `Address`) and coordinates (`lat`, `lng`) are populated automatically.
3. **Manual Override & Permission-Denied Fallback**:
   - At any time—whether after selecting an autocomplete result, after using GPS, or if the user denies location permission—the user can click **"Edit Location Details / پتہ خود درج یا تبدیل کریں"** to directly edit `Country`, `State/Province`, `City`, `Area`, and `Address` by hand.
   - If GPS permission is denied or unavailable, a clear, non-intrusive bilingual banner explains the reason and automatically expands the manual address inputs so the user is never blocked.

### Visual Identity & Theme
- **Aesthetic Direction**: High-Craft Light Mode (`#FAF8F5` warm alabaster canvas, `#FFFFFF` elevated cards, `#E6E2D8` agricultural parchment borders) matching the existing Desi Beej Exchange design system.
- **Color Palette & Mood**:
  - Primary Accent: Deep Indus Agricultural Green (`#14532D`) for the `Use Current Location` button, active focus rings, and verified GPS badges.
  - Secondary Surface: Soft Sage (`#EAF2EC`) for structured location breakdown pills and selected location summary cards.
  - Warning / Fallback State: Warm Amber (`#FEF3C7` surface / `#92400E` text) for GPS permission guidance.
- **Typography & Hierarchy**:
  - Full RTL (`dir="rtl"`, `Noto Nastaliq Urdu` / `Plus Jakarta Sans`) and LTR (`dir="ltr"`) support.
  - Tabular numerals (`font-mono-num`) for GPS coordinates and distance indicators.
- **Interactive Feedback & Motion**:
  - Keyboard navigation (`ArrowDown`, `ArrowUp`, `Enter`, `Escape`) inside the autocomplete dropdown.
  - Clear loading skeletons and empty-result notices when searching uncommon rural addresses, with an immediate one-click fallback to use the typed text as a manual address.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Engine Live Geocoding (OpenStreetMap Nominatim/Photon + Optional Google Maps Key)**
  - *Chosen Approach*: Use real-time OpenStreetMap (`Nominatim` & `Photon` APIs) out of the box with zero API key setup required, while automatically supporting `VITE_GOOGLE_MAPS_API_KEY` if provided in environment variables.
  - *Why*: Guarantees 100% real worldwide and rural Pakistani location search and GPS reverse-geocoding immediately in preview and production without failing on missing billing cards or daily demo key caps, while respecting requirement #10 (zero fake locations or mock coordinates).
  - *Alternatives Considered*: Requiring a paid Google Maps billing key exclusively (rejected because it blocks users who haven't attached a credit card) or using a static JSON city list (rejected because it cannot cover every village, area, and street worldwide).
- **Decision 2: Structured 5-Field Location Data Model with Backward Compatibility**
  - *Chosen Approach*: Store structured location fields (`country`, `state`, `city`, `area`, `address`, `latitude`, `longitude`) on seed listings and inquiries while syncing `city` and `locationEn`/`locationUr` for seamless compatibility with existing seed cards, seller profiles, and admin moderation tables.
  - *Why*: Ensures all 5 required components (`Country`, `State/Province`, `City`, `Area`, `Address`) are distinctly saved and displayed without breaking any existing components.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌───────────────────────────────────────────────────────────────────────────┐
│                   Live Location & Geocoding Service Layer                 │
│  ┌─────────────────────────────┐      ┌────────────────────────────────┐  │
│  │ Browser Geolocation API     │      │ Live Geocoding & Autocomplete  │  │
│  │ navigator.geolocation (GPS) │      │ • OpenStreetMap Nominatim/Photon│  │
│  │ High-Accuracy Lat/Lng       │      │ • Optional Google Places/Geocode│  │
│  └──────────────┬──────────────┘      └───────────────┬────────────────┘  │
└─────────────────┼─────────────────────────────────────┼───────────────────┘
                  │ Reverse Geocode (Lat, Lng)          │ Debounced Query (400ms)
                  ▼                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│             Reusable <LocationAutocompletePicker /> Component             │
│  • Global Search Input with Live Suggestions Dropdown                     │
│  • "Use Current Location (GPS)" Button with Permission Error Handling     │
│  • Structured 5-Field Editor (Country, State/Province, City, Area, Address│
└─────────┬──────────────────────────────┬──────────────────────────┬───────┘
          │                              │                          │
          ▼                              ▼                          ▼
┌─────────────────────────┐  ┌──────────────────────────┐  ┌────────────────┐
│ 1. Add / Edit Seed Modal│  │ 2. Homepage Catalog      │  │ 3. Seed Detail │
│    Saves structured     │  │    Location Filter Bar   │  │    Inquiry Form│
│    Country, State, City,│  │    Global location search│  │    GPS + Auto- │
│    Area, Address & GPS  │  │    + GPS "Near Me" filter│  │    complete    │
└─────────────────────────┘  └──────────────────────────┘  └────────────────┘
```

### Data Model & State
- **`StructuredLocation` Entity**:
  - `country`: Country name (e.g., `"Pakistan"` / `"پاکستان"`)
  - `state`: State or Province (e.g., `"Punjab"` / `"پنجاب"`)
  - `city`: City, District, or Municipality (e.g., `"Sahiwal"` / `"ساہیوال"`)
  - `area`: Neighborhood, Tehsil, Village, or Chak (e.g., `"Chichawatni"` / `"چیچہ وطنی"`)
  - `address`: Formatted or user-refined street/mandi address
  - `latitude` & `longitude` (optional numbers): Real GPS or geocoded coordinates for distance calculation and verification
  - `source`: `'gps' | 'autocomplete' | 'manual'`
- **`SeedListing` & `SeedInquiry` Extensions**:
  - Attach `structuredLocation?: StructuredLocation` to `SeedListing` and `SeedInquiry` while automatically keeping `city`, `locationEn`, and `locationUr` synchronized so existing cards, detail views, and admin panels display rich location badges.

### Interactive Component & State Mapping
1. **Autocomplete Input & Debounced Search**:
   - Typing 2+ characters triggers a 400ms debounced `AbortController`-backed fetch to the live geocoding endpoint with `accept-language` matched to the active app language (`ur` or `en`).
   - Selecting any result normalizes the raw address components (`country`, `state`/`province`, `city`/`town`/`county`, `suburb`/`village`/`neighbourhood`, `display_name`) into the 5 structured fields.
2. **GPS `Use Current Location` Flow**:
   - Invokes `navigator.geolocation.getCurrentPosition` with `{ enableHighAccuracy: true, timeout: 10000 }`.
   - On success, reverse-geocodes the exact `latitude` and `longitude` into the 5 structured fields and opens the structured preview so the farmer can verify or tweak their village/chak details.
   - On `PERMISSION_DENIED`, `POSITION_UNAVAILABLE`, or `TIMEOUT`, displays a clear bilingual message and automatically focuses the manual structured fields.
3. **Homepage Catalog Location Filtering**:
   - Replaces the fixed 10-city `<select>` with a smart Location Filter control that lets users:
     - Type any country, province, city, or village with live autocomplete suggestions.
     - Click **`Use Current Location (میرے قریب)`** to filter or sort listings by proximity (`km` distance from the user's real GPS coordinates) or matching city/province.
     - Quickly select `"All Locations (تمام مقامات)"` or any city currently represented in the active listings.
