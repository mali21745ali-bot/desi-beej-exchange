import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Image as ImageIcon,
  Mic,
  Square,
  Play,
  Pause,
  Phone,
  PhoneIncoming,
  PhoneOff,
  MicOff,
  Check,
  CheckCheck,
  Info,
  ArrowLeft,
  ArrowRight,
  AlertCircle,
  X,
  MessageSquare,
} from 'lucide-react';
import {
  ChatConversation,
  ChatMessage,
  Language,
  VoiceCallStatus,
} from '../types/seed';
import { chatAndCallService } from '../services/chatAndCallService';
import { SeedImage } from './SeedImage';

interface FarmerChatViewProps {
  lang: Language;
  initialConversationId?: string | null;
  onOpenSeedById?: (seedId: string) => void;
  onOpenSellerById?: (sellerId: string) => void;
}

const VoiceMessagePlayer: React.FC<{
  audioUrl: string;
  durationSec: number;
  isOwn: boolean;
}> = ({ audioUrl, durationSec, isOwn }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [totalDuration, setTotalDuration] = useState(durationSec || 4);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    const audio = new Audio(audioUrl);
    audioRef.current = audio;

    const onLoadedMetadata = () => {
      if (audio.duration && isFinite(audio.duration)) {
        setTotalDuration(Math.round(audio.duration));
      }
    };
    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };
    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.pause();
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('ended', onEnded);
    };
  }, [audioUrl]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(() => {
        setIsPlaying(false);
      });
      setIsPlaying(true);
    }
  };

  const formatSec = (sec: number) => {
    const s = Math.max(0, Math.round(sec));
    const mins = Math.floor(s / 60);
    const rem = s % 60;
    return `${mins}:${rem < 10 ? '0' : ''}${rem}`;
  };

  const progressPercent =
    totalDuration > 0 ? Math.min(100, (currentTime / totalDuration) * 100) : 0;

  return (
    <div className="flex items-center gap-3 min-w-[210px] sm:min-w-[240px] py-1">
      <button
        type="button"
        onClick={togglePlay}
        aria-label={isPlaying ? 'Pause voice message' : 'Play voice message'}
        className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
          isOwn
            ? 'bg-white text-[#14532D] hover:bg-[#EFECE6]'
            : 'bg-[#14532D] text-white hover:bg-[#0F3F22]'
        }`}
      >
        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
      </button>

      <div className="flex-1 space-y-1">
        <div
          className={`h-1.5 rounded-full overflow-hidden ${
            isOwn ? 'bg-white/30' : 'bg-[#E6E2D8]'
          }`}
        >
          <div
            className={`h-full transition-all duration-150 ${
              isOwn ? 'bg-white' : 'bg-[#14532D]'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <div
          className={`flex items-center justify-between text-[11px] font-mono-num ${
            isOwn ? 'text-white/90' : 'text-[#5C6660]'
          }`}
        >
          <span>{formatSec(currentTime)}</span>
          <span>{formatSec(totalDuration)}</span>
        </div>
      </div>
    </div>
  );
};

export const FarmerChatView: React.FC<FarmerChatViewProps> = ({
  lang,
  initialConversationId,
  onOpenSeedById,
  onOpenSellerById,
}) => {
  const [conversations, setConversations] = useState<ChatConversation[]>(() =>
    chatAndCallService.getConversations()
  );
  const [activeConvId, setActiveConvId] = useState<string>(() => {
    if (initialConversationId) return initialConversationId;
    const list = chatAndCallService.getConversations();
    return list[0]?.id || 'conv-seller-1';
  });
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    chatAndCallService.getMessages(activeConvId)
  );
  const [mobileShowInbox, setMobileShowInbox] = useState<boolean>(
    !initialConversationId
  );

  // Composer State
  const [inputText, setInputText] = useState('');
  const [showFirebaseArchModal, setShowFirebaseArchModal] = useState(false);

  // Voice Recording State (MediaRecorder API)
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [micError, setMicError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);

  // Live WebRTC Voice Call State
  const [callStatus, setCallStatus] = useState<VoiceCallStatus>('idle');
  const [callDurationSec, setCallDurationSec] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [callError, setCallError] = useState<string | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const loopbackPeerRef = useRef<RTCPeerConnection | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const callTimerRef = useRef<number | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (initialConversationId) {
      setActiveConvId(initialConversationId);
      setMobileShowInbox(false);
    }
  }, [initialConversationId]);

  useEffect(() => {
    const loaded = chatAndCallService.getMessages(activeConvId);
    setMessages(loaded);
    // Mark incoming messages as read
    const convos = chatAndCallService.getConversations().map((c) =>
      c.id === activeConvId ? { ...c, unreadCount: 0 } : c
    );
    chatAndCallService.saveConversations(convos);
    setConversations(convos);
  }, [activeConvId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, activeConvId]);

  // Listen to BroadcastChannel for cross-tab messaging & WebRTC signaling
  useEffect(() => {
    const channel = chatAndCallService.getChannel();
    if (!channel) return;

    const handleChannelMessage = async (event: MessageEvent) => {
      const data = event.data;
      if (!data) return;

      if (data.type === 'chat:new-message') {
        setConversations(chatAndCallService.getConversations());
        if (data.conversationId === activeConvId) {
          setMessages(chatAndCallService.getMessages(activeConvId));
        }
      } else if (data.type === 'webrtc:incoming-call' && data.conversationId === activeConvId) {
        if (callStatus === 'idle') {
          setCallStatus('incoming');
        }
      } else if (data.type === 'webrtc:end-call' && data.conversationId === activeConvId) {
        cleanupWebRTCCall();
        setCallStatus('idle');
      }
    };

    channel.addEventListener('message', handleChannelMessage);
    return () => {
      channel.removeEventListener('message', handleChannelMessage);
    };
  }, [activeConvId, callStatus]);

  // Call Duration Timer
  useEffect(() => {
    if (callStatus === 'connected') {
      callTimerRef.current = window.setInterval(() => {
        setCallDurationSec((prev) => prev + 1);
      }, 1000);
    } else {
      if (callTimerRef.current) {
        clearInterval(callTimerRef.current);
        callTimerRef.current = null;
      }
    }
    return () => {
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [callStatus]);

  // Cleanup media streams on unmount
  useEffect(() => {
    return () => {
      cleanupRecording();
      cleanupWebRTCCall();
    };
  }, []);

  const activeConversation =
    conversations.find((c) => c.id === activeConvId) || conversations[0];

  const formatTimestamp = () => {
    return new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDurationClock = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressMessageStatuses = (convId: string, msgId: string) => {
    setTimeout(() => {
      const afterDelivered = chatAndCallService.updateMessageStatus(
        convId,
        msgId,
        'delivered'
      );
      if (convId === activeConvId) setMessages([...afterDelivered]);
    }, 600);

    setTimeout(() => {
      const afterRead = chatAndCallService.updateMessageStatus(
        convId,
        msgId,
        'read'
      );
      if (convId === activeConvId) setMessages([...afterRead]);
    }, 1500);
  };

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !activeConversation) return;

    const msgId = `msg-${Date.now()}`;
    const newMsg: ChatMessage = {
      id: msgId,
      conversationId: activeConversation.id,
      senderId: 'current-user',
      senderNameEn: 'You (Local Farmer)',
      senderNameUr: 'آپ (مقامی کسان)',
      type: 'text',
      text: inputText.trim(),
      timestamp: formatTimestamp(),
      status: 'sent',
    };

    const updated = chatAndCallService.appendMessage(
      activeConversation.id,
      newMsg
    );
    setMessages(updated);
    setConversations(chatAndCallService.getConversations());
    setInputText('');
    progressMessageStatuses(activeConversation.id, msgId);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeConversation) return;

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const msgId = `msg-img-${Date.now()}`;
        const newMsg: ChatMessage = {
          id: msgId,
          conversationId: activeConversation.id,
          senderId: 'current-user',
          senderNameEn: 'You (Local Farmer)',
          senderNameUr: 'آپ (مقامی کسان)',
          type: 'image',
          imageUrl: reader.result,
          text: file.name,
          timestamp: formatTimestamp(),
          status: 'sent',
        };
        const updated = chatAndCallService.appendMessage(
          activeConversation.id,
          newMsg
        );
        setMessages(updated);
        setConversations(chatAndCallService.getConversations());
        progressMessageStatuses(activeConversation.id, msgId);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // =========================================================================
  // VOICE MESSAGE RECORDING (Browser MediaRecorder API)
  // =========================================================================
  const cleanupRecording = () => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (recordingStreamRef.current) {
      recordingStreamRef.current.getTracks().forEach((t) => t.stop());
      recordingStreamRef.current = null;
    }
    mediaRecorderRef.current = null;
    setIsRecording(false);
    setRecordingSeconds(0);
  };

  const startVoiceRecording = async () => {
    setMicError(null);
    if (
      typeof navigator === 'undefined' ||
      !navigator.mediaDevices ||
      !navigator.mediaDevices.getUserMedia
    ) {
      setMicError(
        lang === 'ur'
          ? 'آپ کا براؤزر مائیکروفون ریکارڈنگ کو سپورٹ نہیں کرتا۔'
          : 'Your browser environment does not support MediaDevices.getUserMedia.'
      );
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordingStreamRef.current = stream;
      recordedChunksRef.current = [];

      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          recordedChunksRef.current.push(ev.data);
        }
      };

      recorder.start();
      setIsRecording(true);
      setRecordingSeconds(0);

      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      const errName = err?.name || 'PermissionDenied';
      setMicError(
        lang === 'ur'
          ? `مائیکروفون تک رسائی مسترد کر دی گئی یا دستیاب نہیں ہے (${errName})۔ براہ کرم براؤزر سیٹنگز میں مائیکروفون کی اجازت دیں۔`
          : `Microphone permission was denied or no microphone hardware was found (${errName}). Please allow microphone access in your browser address bar.`
      );
    }
  };

  const stopAndSendVoiceRecording = () => {
    const recorder = mediaRecorderRef.current;
    const durationCaptured = Math.max(1, recordingSeconds);
    if (!recorder || !activeConversation) {
      cleanupRecording();
      return;
    }

    recorder.onstop = () => {
      const blob = new Blob(recordedChunksRef.current, {
        type: recorder.mimeType || 'audio/webm',
      });
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          const msgId = `msg-voice-${Date.now()}`;
          const newMsg: ChatMessage = {
            id: msgId,
            conversationId: activeConversation.id,
            senderId: 'current-user',
            senderNameEn: 'You (Local Farmer)',
            senderNameUr: 'آپ (مقامی کسان)',
            type: 'voice',
            audioDataUrl: reader.result,
            audioDurationSec: durationCaptured,
            timestamp: formatTimestamp(),
            status: 'sent',
          };
          const updated = chatAndCallService.appendMessage(
            activeConversation.id,
            newMsg
          );
          setMessages(updated);
          setConversations(chatAndCallService.getConversations());
          progressMessageStatuses(activeConversation.id, msgId);
        }
      };
      reader.readAsDataURL(blob);
      cleanupRecording();
    };

    recorder.stop();
  };

  // =========================================================================
  // LIVE VOICE CALLS (WebRTC RTCPeerConnection + Microphone Permission)
  // =========================================================================
  const cleanupWebRTCCall = () => {
    if (callTimerRef.current) {
      clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
    }
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
    if (loopbackPeerRef.current) {
      loopbackPeerRef.current.close();
      loopbackPeerRef.current = null;
    }
    setIsMuted(false);
    setCallDurationSec(0);
  };

  const establishWebRTCPeerSession = async (stream: MediaStream) => {
    const rtcConfig: RTCConfiguration = {
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    };

    const callerPC = new RTCPeerConnection(rtcConfig);
    const calleeLoopbackPC = new RTCPeerConnection(rtcConfig);
    peerConnectionRef.current = callerPC;
    loopbackPeerRef.current = calleeLoopbackPC;

    // Wire ICE candidates between local WebRTC peers (in production, sent via Firebase Firestore signaling)
    callerPC.onicecandidate = (e) => {
      if (e.candidate) {
        calleeLoopbackPC.addIceCandidate(e.candidate).catch(() => {});
      }
    };
    calleeLoopbackPC.onicecandidate = (e) => {
      if (e.candidate) {
        callerPC.addIceCandidate(e.candidate).catch(() => {});
      }
    };

    calleeLoopbackPC.ontrack = (event) => {
      if (remoteAudioRef.current && event.streams[0]) {
        remoteAudioRef.current.srcObject = event.streams[0];
      }
    };

    stream.getAudioTracks().forEach((track) => {
      callerPC.addTrack(track, stream);
    });

    const offer = await callerPC.createOffer();
    await callerPC.setLocalDescription(offer);
    await calleeLoopbackPC.setRemoteDescription(offer);

    const answer = await calleeLoopbackPC.createAnswer();
    await calleeLoopbackPC.setLocalDescription(answer);
    await callerPC.setRemoteDescription(answer);
  };

  const handleStartVoiceCall = async () => {
    setCallError(null);
    setCallStatus('requesting-mic');

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;
      setCallStatus('calling');

      // Notify any other open browser tab via BroadcastChannel
      chatAndCallService.getChannel()?.postMessage({
        type: 'webrtc:incoming-call',
        conversationId: activeConversation?.id,
      });

      await establishWebRTCPeerSession(stream);
      setTimeout(() => {
        setCallStatus((prev) => (prev === 'calling' ? 'connected' : prev));
      }, 900);
    } catch (err: any) {
      cleanupWebRTCCall();
      setCallStatus('error');
      setCallError(
        lang === 'ur'
          ? `وائس کال کے لیے مائیکروفون کی اجازت ضروری ہے (${err?.name || 'MicError'})۔ براہ کرم براؤزر میں مائیکروفون آن کریں۔`
          : `Microphone permission is required before starting a WebRTC voice call (${err?.name || 'MicError'}). Please grant microphone permission in your browser.`
      );
    }
  };

  const handleTriggerIncomingCallDemo = () => {
    setCallError(null);
    setCallStatus('incoming');
  };

  const handleAcceptIncomingCall = async () => {
    setCallError(null);
    setCallStatus('requesting-mic');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      localStreamRef.current = stream;
      await establishWebRTCPeerSession(stream);
      setCallStatus('connected');
    } catch (err: any) {
      cleanupWebRTCCall();
      setCallStatus('error');
      setCallError(
        lang === 'ur'
          ? `کال ریسیو کرنے کے لیے مائیکروفون کی اجازت نہیں ملی (${err?.name || 'MicError'})۔`
          : `Could not accept call because microphone permission was denied (${err?.name || 'MicError'}).`
      );
    }
  };

  const handleRejectOrEndCall = () => {
    chatAndCallService.getChannel()?.postMessage({
      type: 'webrtc:end-call',
      conversationId: activeConversation?.id,
    });
    cleanupWebRTCCall();
    setCallStatus('idle');
  };

  const handleToggleMute = () => {
    if (!localStreamRef.current) return;
    const tracks = localStreamRef.current.getAudioTracks();
    tracks.forEach((track) => {
      track.enabled = isMuted;
    });
    setIsMuted(!isMuted);
  };

  const renderStatusIndicator = (status: ChatMessage['status']) => {
    if (status === 'read') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-white/95">
          <CheckCheck className="w-3.5 h-3.5" />
          <span>{lang === 'ur' ? 'پڑھا گیا' : 'Read'}</span>
        </span>
      );
    }
    if (status === 'delivered') {
      return (
        <span className="inline-flex items-center gap-1 text-[11px] text-white/85">
          <CheckCheck className="w-3.5 h-3.5" />
          <span>{lang === 'ur' ? 'پہنچ گیا' : 'Delivered'}</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-[11px] text-white/75">
        <Check className="w-3.5 h-3.5" />
        <span>{lang === 'ur' ? 'بھیجا گیا' : 'Sent'}</span>
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
      {/* Hidden audio element for WebRTC stream */}
      <audio ref={remoteAudioRef} muted />

      {/* Transparent Local vs Firebase Signaling Notice Banner */}
      <div className="bg-white border border-[#E6E2D8] rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Info className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
          <div className="text-xs text-[#4A554E] leading-relaxed">
            <span className="font-semibold text-[#18241B]">
              {lang === 'ur'
                ? 'کسان چیٹ اور ویب آر ٹی سی (WebRTC) وائس کال ڈیمو نوٹس: '
                : 'Farmer Chat & WebRTC Voice Call Architecture Notice: '}
            </span>
            {lang === 'ur'
              ? 'اس ڈیمو میں ٹیکسٹ پیغامات، تصاویر، مائیکروفون وائس ریکارڈنگ (MediaRecorder API) اور لائیو WebRTC آڈیو کال اس براؤزر میں مقامی طور پر کام کرتے ہیں۔ مختلف شہروں میں موجود دو الگ کسانوں کے درمیان حقیقی رابطے کے لیے Firebase Firestore سگنلنگ بیک اینڈ درکار ہوتا ہے۔'
              : 'Text messages, image sharing, real MediaRecorder voice recording/playback, and WebRTC RTCPeerConnection audio streams run locally in your browser (and sync across tabs via BroadcastChannel). Real communication between different farmers over the internet requires Firebase Firestore signaling & Storage.'}
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowFirebaseArchModal(true)}
          className="px-3.5 py-2 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg whitespace-nowrap shrink-0"
        >
          {lang === 'ur' ? 'فائر بیس آرکیٹیکچر تفصیل' : 'Firebase Signaling Guide'}
        </button>
      </div>

      {/* Main Split Chat Container */}
      <div className="bg-white border border-[#E6E2D8] rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[620px]">
        {/* Left Column: Conversation Inbox (4 cols) */}
        <aside
          className={`lg:col-span-4 border-e border-[#E6E2D8] flex flex-col ${
            mobileShowInbox ? 'block' : 'hidden lg:flex'
          }`}
        >
          <div className="p-4 border-b border-[#E6E2D8] bg-[#FAF8F5] flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#18241B]">
                {lang === 'ur' ? 'کسان ان باکس (گفتگو)' : 'Farmer Conversation Inbox'}
              </h2>
              <p className="text-xs text-[#5C6660]">
                {conversations.length}{' '}
                {lang === 'ur' ? 'فعال بات چیت' : 'active farmer threads'}
              </p>
            </div>
            <MessageSquare className="w-5 h-5 text-[#14532D]" />
          </div>

          <div className="divide-y divide-[#F0EDE6] overflow-y-auto flex-1">
            {conversations.map((conv) => {
              const isSelected = conv.id === activeConversation?.id;
              const name =
                lang === 'ur' ? conv.participantNameUr : conv.participantNameEn;
              const farm =
                lang === 'ur' ? conv.participantFarmUr : conv.participantFarmEn;
              const seedName =
                lang === 'ur'
                  ? conv.relatedSeedNameUr || conv.relatedSeedNameEn
                  : conv.relatedSeedNameEn;

              return (
                <button
                  key={conv.id}
                  type="button"
                  onClick={() => {
                    setActiveConvId(conv.id);
                    setMobileShowInbox(false);
                  }}
                  className={`w-full text-start p-4 transition-colors flex flex-col gap-1 ${
                    isSelected
                      ? 'bg-[#EAF2EC]/70'
                      : 'hover:bg-[#FAF8F5]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-[#18241B] truncate">
                      {name}
                    </span>
                    <span className="text-[11px] text-[#5C6660] font-mono-num shrink-0">
                      {conv.updatedAt}
                    </span>
                  </div>
                  <p className="text-xs text-[#4A554E] truncate">
                    {farm} · {conv.participantCity}
                  </p>
                  {seedName && (
                    <p className="text-[11px] text-[#14532D] font-medium truncate mt-0.5">
                      {lang === 'ur' ? 'بیج: ' : 'Seed: '}
                      {seedName}
                    </p>
                  )}
                </button>
              );
            })}
          </div>
        </aside>

        {/* Right Column: Active 1-to-1 Chat & Voice Call Interface (8 cols) */}
        <section
          className={`lg:col-span-8 flex flex-col justify-between relative ${
            mobileShowInbox ? 'hidden lg:flex' : 'flex'
          }`}
        >
          {activeConversation && (
            <>
              {/* Chat Header with Voice Call Controls */}
              <div className="p-4 border-b border-[#E6E2D8] bg-[#FAF8F5] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setMobileShowInbox(true)}
                    className="lg:hidden p-1.5 text-[#4A554E] hover:text-[#18241B] rounded-lg border border-[#E6E2D8]"
                  >
                    {lang === 'ur' ? (
                      <ArrowRight className="w-4 h-4" />
                    ) : (
                      <ArrowLeft className="w-4 h-4" />
                    )}
                  </button>

                  <div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          onOpenSellerById?.(activeConversation.participantId)
                        }
                        className="text-base font-bold text-[#18241B] hover:text-[#14532D] hover:underline text-start"
                      >
                        {lang === 'ur'
                          ? activeConversation.participantNameUr
                          : activeConversation.participantNameEn}
                      </button>
                      <span className="text-xs text-[#5C6660]">
                        · {activeConversation.participantCity}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                      <span>
                        {lang === 'ur'
                          ? activeConversation.participantFarmUr
                          : activeConversation.participantFarmEn}
                      </span>
                      {activeConversation.relatedSeedId && (
                        <>
                          <span>·</span>
                          <button
                            type="button"
                            onClick={() =>
                              onOpenSeedById?.(activeConversation.relatedSeedId!)
                            }
                            className="text-[#14532D] font-medium hover:underline truncate max-w-[240px]"
                          >
                            {lang === 'ur'
                              ? activeConversation.relatedSeedNameUr
                              : activeConversation.relatedSeedNameEn}
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Live Voice Call Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleTriggerIncomingCallDemo}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#18241B] bg-white hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors whitespace-nowrap"
                  >
                    <PhoneIncoming className="w-3.5 h-3.5 text-[#14532D]" />
                    <span>
                      {lang === 'ur' ? 'ان کمنگ کال ٹیسٹ' : 'Test Incoming Call'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={handleStartVoiceCall}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{lang === 'ur' ? 'وائس کال کریں' : 'Voice Call'}</span>
                  </button>
                </div>
              </div>

              {/* Live WebRTC Voice Call Overlay / Banner */}
              {callStatus !== 'idle' && (
                <div className="bg-[#18241B] text-white p-5 border-b border-[#E6E2D8]">
                  {callStatus === 'incoming' ? (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <p className="text-xs text-[#A7F3D0] font-medium">
                          {lang === 'ur'
                            ? 'ان کمنگ کسان وائس کال (WebRTC)...'
                            : 'Incoming Farmer Voice Call (WebRTC)...'}
                        </p>
                        <h3 className="text-lg font-bold mt-0.5">
                          {lang === 'ur'
                            ? activeConversation.participantNameUr
                            : activeConversation.participantNameEn}{' '}
                          ({activeConversation.participantCity})
                        </h3>
                        <p className="text-xs text-white/75">
                          {lang === 'ur'
                            ? 'کال سننے کے لیے مائیکروفون تک رسائی کی تصدیق کی جائے گی۔'
                            : 'Accepting will request microphone permission and establish a WebRTC audio stream.'}
                        </p>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={handleAcceptIncomingCall}
                          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#15803D] hover:bg-[#166534] rounded-lg"
                        >
                          <Phone className="w-4 h-4" />
                          <span>{lang === 'ur' ? 'کال سنیں (Accept)' : 'Accept Call'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={handleRejectOrEndCall}
                          className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded-lg"
                        >
                          <PhoneOff className="w-4 h-4" />
                          <span>{lang === 'ur' ? 'مسترد کریں (Reject)' : 'Reject Call'}</span>
                        </button>
                      </div>
                    </div>
                  ) : callStatus === 'error' ? (
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-start gap-2.5 text-xs text-[#FCA5A5]">
                        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                        <span>{callError}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setCallStatus('idle')}
                        className="px-3 py-1.5 text-xs font-semibold bg-white/10 hover:bg-white/20 rounded-lg"
                      >
                        {lang === 'ur' ? 'بند کریں' : 'Dismiss'}
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <p className="text-xs text-[#A7F3D0] font-medium">
                          {callStatus === 'requesting-mic'
                            ? lang === 'ur'
                              ? 'مائیکروفون کی اجازت طلب کی جا رہی ہے...'
                              : 'Requesting microphone permission...'
                            : callStatus === 'calling'
                              ? lang === 'ur'
                                ? 'ویب آر ٹی سی کال ملائی جا رہی ہے...'
                                : 'Connecting WebRTC PeerConnection...'
                              : lang === 'ur'
                                ? 'لائیو وائس کال جاری ہے (WebRTC آڈیو فعال)'
                                : 'Live WebRTC Voice Call Connected (Loopback / Multi-Tab)'}
                        </p>
                        <div className="flex items-baseline gap-3 mt-1">
                          <h3 className="text-lg font-bold">
                            {lang === 'ur'
                              ? activeConversation.participantNameUr
                              : activeConversation.participantNameEn}
                          </h3>
                          <span className="text-sm font-mono-num text-[#A7F3D0] font-semibold">
                            {formatDurationClock(callDurationSec)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={handleToggleMute}
                          className={`inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors ${
                            isMuted
                              ? 'bg-[#B45309] text-white'
                              : 'bg-white/15 hover:bg-white/25 text-white'
                          }`}
                        >
                          {isMuted ? (
                            <>
                              <MicOff className="w-4 h-4" />
                              <span>{lang === 'ur' ? 'ان میوٹ کریں' : 'Unmute Mic'}</span>
                            </>
                          ) : (
                            <>
                              <Mic className="w-4 h-4" />
                              <span>{lang === 'ur' ? 'مائیک میوٹ کریں' : 'Mute Mic'}</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={handleRejectOrEndCall}
                          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded-lg"
                        >
                          <PhoneOff className="w-4 h-4" />
                          <span>{lang === 'ur' ? 'کال ختم کریں' : 'End Call'}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Message Thread Area */}
              <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-[#FAF8F5]/60 max-h-[460px]">
                {messages.map((msg) => {
                  const isOwn = msg.senderId === 'current-user';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${
                        isOwn ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-[85%] sm:max-w-[70%] rounded-xl p-3.5 space-y-2 ${
                          isOwn
                            ? 'bg-[#14532D] text-white'
                            : 'bg-white border border-[#E6E2D8] text-[#18241B]'
                        }`}
                      >
                        <div
                          className={`text-[11px] font-medium ${
                            isOwn ? 'text-white/80' : 'text-[#5C6660]'
                          }`}
                        >
                          {lang === 'ur' ? msg.senderNameUr : msg.senderNameEn}
                        </div>

                        {msg.type === 'image' && msg.imageUrl && (
                          <div className="rounded-lg overflow-hidden border border-black/10 max-w-xs">
                            <SeedImage
                              src={msg.imageUrl}
                              alt={msg.text || 'Shared seed image'}
                              className="w-full h-auto object-cover max-h-56"
                            />
                          </div>
                        )}

                        {msg.type === 'voice' && msg.audioDataUrl && (
                          <VoiceMessagePlayer
                            audioUrl={msg.audioDataUrl}
                            durationSec={msg.audioDurationSec || 4}
                            isOwn={isOwn}
                          />
                        )}

                        {msg.text && msg.type !== 'voice' && (
                          <p className="text-sm leading-relaxed break-words">
                            {msg.text}
                          </p>
                        )}

                        <div
                          className={`flex items-center justify-end gap-2 pt-1 text-[11px] font-mono-num ${
                            isOwn ? 'text-white/80' : 'text-[#5C6660]'
                          }`}
                        >
                          <span>{msg.timestamp}</span>
                          {isOwn && renderStatusIndicator(msg.status)}
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Microphone Permission Error Banner */}
              {micError && (
                <div className="px-4 py-2.5 bg-[#FEF2F2] border-t border-[#FECACA] flex items-center justify-between gap-3 text-xs text-[#991B1B]">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{micError}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setMicError(null)}
                    className="font-semibold underline shrink-0"
                  >
                    {lang === 'ur' ? 'بند کریں' : 'Dismiss'}
                  </button>
                </div>
              )}

              {/* Message Composer & Voice Recording Footer */}
              <div className="p-4 bg-white border-t border-[#E6E2D8]">
                {isRecording ? (
                  <div className="flex items-center justify-between gap-4 bg-[#FAF8F5] border border-[#14532D] rounded-xl px-4 py-2.5">
                    <div className="flex items-center gap-3">
                      <Mic className="w-4 h-4 text-[#991B1B]" />
                      <span className="text-xs font-semibold text-[#18241B]">
                        {lang === 'ur'
                          ? 'آواز ریکارڈ ہو رہی ہے...'
                          : 'Recording Voice Message...'}
                      </span>
                      <span className="text-xs font-mono-num font-bold text-[#14532D]">
                        {formatDurationClock(recordingSeconds)}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={cleanupRecording}
                        className="px-3 py-1.5 text-xs font-medium text-[#4A554E] hover:text-[#18241B] rounded-lg"
                      >
                        {lang === 'ur' ? 'منسوخ کریں' : 'Cancel'}
                      </button>
                      <button
                        type="button"
                        onClick={stopAndSendVoiceRecording}
                        className="inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg"
                      >
                        <Square className="w-3 h-3 fill-current" />
                        <span>
                          {lang === 'ur' ? 'وائس میسج بھیجیں' : 'Stop & Send Voice'}
                        </span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <form
                    onSubmit={handleSendText}
                    className="flex items-center gap-2.5"
                  >
                    {/* Image Upload Button */}
                    <label
                      title={lang === 'ur' ? 'تصویر بھیجیں' : 'Share Seed Photo'}
                      className="p-2.5 text-[#4A554E] hover:text-[#14532D] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg cursor-pointer shrink-0 transition-colors"
                    >
                      <ImageIcon className="w-4 h-4" />
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="hidden"
                      />
                    </label>

                    {/* Microphone Voice Recording Button */}
                    <button
                      type="button"
                      onClick={startVoiceRecording}
                      title={
                        lang === 'ur'
                          ? 'آواز کا پیغام ریکارڈ کریں'
                          : 'Record Voice Message (MediaRecorder)'
                      }
                      className="p-2.5 text-[#4A554E] hover:text-[#14532D] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg shrink-0 transition-colors"
                    >
                      <Mic className="w-4 h-4" />
                    </button>

                    {/* Text Message Input */}
                    <input
                      type="text"
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      placeholder={
                        lang === 'ur'
                          ? 'کسان کو بیج کی قیمت یا تبادلے کے بارے میں پیغام لکھیں...'
                          : 'Write a message to the farmer about seed quality, price, or barter...'
                      }
                      className="flex-1 px-4 py-2.5 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                    />

                    {/* Send Button */}
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors shrink-0"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">
                        {lang === 'ur' ? 'بھیجیں' : 'Send'}
                      </span>
                    </button>
                  </form>
                )}
              </div>
            </>
          )}
        </section>
      </div>

      {/* Firebase Signaling & Multi-User Architecture Explanation Modal */}
      {showFirebaseArchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white border border-[#E6E2D8] rounded-xl max-w-xl w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E2D8] pb-3">
              <h3 className="text-base font-bold text-[#18241B]">
                {lang === 'ur'
                  ? 'لوکل ڈیمو بمقابلہ فائر بیس (Firebase) پروڈکشن آرکیٹیکچر'
                  : 'Local Demo vs. Firebase Production Signaling Architecture'}
              </h3>
              <button
                type="button"
                onClick={() => setShowFirebaseArchModal(false)}
                className="p-1 text-[#5C6660] hover:text-[#18241B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#36403A] leading-relaxed">
              <div>
                <p className="font-bold text-[#14532D] mb-1">
                  1. What Works Locally Right Now (No Paid API / No Server Required):
                </p>
                <p>
                  • Browser <code>MediaRecorder</code> API records real microphone audio blobs with live duration timers and Play/Pause playback.
                  <br />• Browser <code>RTCPeerConnection</code> requests microphone permission, negotiates SDP Offer/Answer over local loopback & <code>BroadcastChannel</code> across open browser tabs, and supports Mute/Unmute and Incoming/Outgoing call screens.
                  <br />• Conversation history and image attachments persist in <code>localStorage</code> via <code>chatAndCallService.ts</code>.
                </p>
              </div>

              <div>
                <p className="font-bold text-[#14532D] mb-1">
                  2. What Requires Firebase for Cross-Device Internet Communication:
                </p>
                <p>
                  • <code>localStorage</code> and <code>BroadcastChannel</code> only exist on the user&apos;s own device. To let a farmer in Sahiwal chat with or call a farmer in Multan over the internet:
                  <br />• <strong>Firebase Firestore Messaging</strong>: Replace <code>chatAndCallService.appendMessage</code> with <code>onSnapshot(collection(db, &apos;conversations/{'{id}'}/messages&apos;))</code>.
                  <br />• <strong>Firebase Storage</strong>: Upload voice blobs (<code>audio/webm</code>) and seed photos to <code>ref(storage, &apos;chat_media/...&apos;)</code>.
                  <br />• <strong>Firebase WebRTC Signaling</strong>: Exchange WebRTC SDP Offers, Answers, and ICE Candidates inside <code>doc(db, &apos;calls/{'{callId}'}&apos;)</code> and subcollections <code>offerCandidates</code> / <code>answerCandidates</code>, plus a TURN server for symmetric NAT mobile networks.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#E6E2D8]">
              <button
                type="button"
                onClick={() => setShowFirebaseArchModal(false)}
                className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
              >
                {lang === 'ur' ? 'سمجھ گیا' : 'Got It'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
