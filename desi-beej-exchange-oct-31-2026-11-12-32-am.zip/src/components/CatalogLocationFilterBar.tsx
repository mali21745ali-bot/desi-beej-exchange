import React, { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Navigation,
  Loader2,
  X,
  Globe,
  AlertCircle,
  Edit3,
} from 'lucide-react';
import { Language, StructuredLocation } from '../types/seed';
import {
  locationService,
  LocationSuggestion,
  GeolocationError,
} from '../services/locationService';

interface CatalogLocationFilterBarProps {
  lang: Language;
  selectedCity: string;
  activeLocationObj: StructuredLocation | null;
  availableListingCities: string[];
  onSelectLocationFilter: (cityOrQuery: string, structured: StructuredLocation | null) => void;
}

export const CatalogLocationFilterBar: React.FC<CatalogLocationFilterBarProps> = ({
  lang,
  selectedCity,
  activeLocationObj,
  availableListingCities,
  onSelectLocationFilter,
}) => {
  const [locationInput, setLocationInput] = useState('');
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [showManualModal, setShowManualModal] = useState(false);
  const [manualDraft, setManualDraft] = useState<StructuredLocation>({
    country: '',
    state: '',
    city: '',
    area: '',
    address: '',
    source: 'manual',
  });

  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  useEffect(() => {
    const trimmed = locationInput.trim();
    if (trimmed.length < 2) {
      setSuggestions([]);
      setIsSearching(false);
      return;
    }

    const controller = new AbortController();
    setIsSearching(true);

    const timer = setTimeout(async () => {
      try {
        const res = await locationService.searchLocations(
          trimmed,
          lang,
          controller.signal
        );
        setSuggestions(res);
        setIsDropdownOpen(true);
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          setSuggestions([]);
        }
      } finally {
        setIsSearching(false);
      }
    }, 400);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [locationInput, lang]);

  const handleChooseSuggestion = (item: LocationSuggestion) => {
    const loc = item.structured;
    const filterTerm =
      loc.city || loc.area || loc.state || loc.country || item.primaryText;
    onSelectLocationFilter(filterTerm, loc);
    setLocationInput('');
    setSuggestions([]);
    setIsDropdownOpen(false);
    setGpsError(null);
  };

  const handleDetectGps = async () => {
    setIsDetectingGps(true);
    setGpsError(null);
    try {
      const detected = await locationService.detectCurrentLocation(lang);
      const filterTerm =
        detected.city ||
        detected.area ||
        detected.state ||
        detected.country ||
        'GPS';
      onSelectLocationFilter(filterTerm, detected);
      setManualDraft(detected);
    } catch (err: any) {
      if (err instanceof GeolocationError) {
        setGpsError(lang === 'ur' ? err.messageUr : err.messageEn);
      } else {
        setGpsError(
          lang === 'ur'
            ? 'GPS سگنل حاصل نہیں ہو سکا۔ آپ سرچ باکس یا دستی خانے میں اپنا مقام لکھ سکتے ہیں۔'
            : 'Could not detect GPS location. You can type your location in the box or edit manually.'
        );
      }
      setShowManualModal(true);
    } finally {
      setIsDetectingGps(false);
    }
  };

  const handleApplyManualDraft = (e: React.FormEvent) => {
    e.preventDefault();
    const filterTerm =
      manualDraft.city.trim() ||
      manualDraft.area.trim() ||
      manualDraft.state.trim() ||
      manualDraft.country.trim() ||
      manualDraft.address.trim() ||
      'all';
    onSelectLocationFilter(
      filterTerm,
      filterTerm === 'all' ? null : { ...manualDraft, source: 'manual' }
    );
    setShowManualModal(false);
    setGpsError(null);
  };

  return (
    <div ref={wrapperRef} className="space-y-2.5">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        {/* Global Location Autocomplete Input */}
        <div className="relative flex-1">
          <MapPin className="w-4 h-4 text-[#14532D] absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
          <input
            type="text"
            value={locationInput}
            onChange={(e) => {
              setLocationInput(e.target.value);
              setIsDropdownOpen(true);
            }}
            onFocus={() => setIsDropdownOpen(true)}
            placeholder={
              selectedCity === 'all'
                ? lang === 'ur'
                  ? 'دنیا کا کوئی بھی ملک، شہر یا گاؤں تلاش کریں...'
                  : 'Filter by any country, city, or village...'
                : `${lang === 'ur' ? 'منتخب مقام:' : 'Active:'} ${selectedCity}`
            }
            className="w-full ps-9 pe-8 py-2.5 text-xs sm:text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
          />
          {isSearching ? (
            <Loader2 className="w-3.5 h-3.5 text-[#14532D] animate-spin absolute top-1/2 -translate-y-1/2 end-2.5" />
          ) : (locationInput || selectedCity !== 'all') ? (
            <button
              type="button"
              onClick={() => {
                setLocationInput('');
                onSelectLocationFilter('all', null);
                setIsDropdownOpen(false);
              }}
              aria-label="Clear location filter"
              className="p-1 text-[#5C6660] hover:text-[#18241B] absolute top-1/2 -translate-y-1/2 end-2"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : null}

          {/* Dropdown Suggestions + Quick Active Cities */}
          {isDropdownOpen && (
            <div className="absolute z-30 mt-1 w-full sm:w-80 bg-white border border-[#E6E2D8] rounded-xl shadow-lg max-h-72 overflow-y-auto divide-y divide-[#F0EDE6]">
              {/* Option 0: All Worldwide Locations */}
              <button
                type="button"
                onClick={() => {
                  onSelectLocationFilter('all', null);
                  setLocationInput('');
                  setIsDropdownOpen(false);
                }}
                className={`w-full text-start px-3.5 py-2.5 text-xs font-semibold flex items-center justify-between ${
                  selectedCity === 'all'
                    ? 'bg-[#EAF2EC] text-[#14532D]'
                    : 'text-[#18241B] hover:bg-[#FAF8F5]'
                }`}
              >
                <span className="inline-flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-[#14532D]" />
                  {lang === 'ur'
                    ? 'تمام ممالک اور شہر (All Locations)'
                    : 'All Countries & Cities'}
                </span>
              </button>

              {/* Live Global Search Suggestions */}
              {locationInput.trim().length >= 2 ? (
                suggestions.length > 0 ? (
                  suggestions.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleChooseSuggestion(item)}
                      className="w-full text-start px-3.5 py-2.5 hover:bg-[#FAF8F5] flex items-start gap-2"
                    >
                      <MapPin className="w-3.5 h-3.5 text-[#14532D] shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[#18241B] truncate">
                          {item.primaryText}
                        </p>
                        <p className="text-[11px] text-[#5C6660] truncate">
                          {item.secondaryText}
                        </p>
                      </div>
                    </button>
                  ))
                ) : !isSearching ? (
                  <button
                    type="button"
                    onClick={() => {
                      const q = locationInput.trim();
                      onSelectLocationFilter(q, {
                        country: '',
                        state: '',
                        city: q,
                        area: '',
                        address: q,
                        source: 'manual',
                      });
                      setLocationInput('');
                      setIsDropdownOpen(false);
                    }}
                    className="w-full text-start px-3.5 py-2.5 text-xs text-[#14532D] font-semibold hover:bg-[#FAF8F5]"
                  >
                    {lang === 'ur'
                      ? `"${locationInput.trim()}" کے مطابق فلٹر کریں`
                      : `Filter by "${locationInput.trim()}"`}
                  </button>
                ) : null
              ) : (
                /* Quick Active Listing Cities when input is empty */
                <div className="p-2.5 space-y-1.5">
                  <p className="text-[10px] font-semibold text-[#5C6660] px-1">
                    {lang === 'ur'
                      ? 'موجودہ اشتہارات کے شہر (یا اوپر دنیا کا کوئی بھی مقام لکھیں):'
                      : 'Active Listing Locations (or type any global address above):'}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {availableListingCities.map((cityStr) => (
                      <button
                        key={cityStr}
                        type="button"
                        onClick={() => {
                          onSelectLocationFilter(cityStr, null);
                          setIsDropdownOpen(false);
                        }}
                        className={`px-2.5 py-1 text-[11px] font-medium rounded-md border transition-colors ${
                          selectedCity.toLowerCase() === cityStr.toLowerCase()
                            ? 'bg-[#14532D] text-white border-[#14532D]'
                            : 'bg-[#FAF8F5] text-[#18241B] border-[#E6E2D8] hover:border-[#14532D]'
                        }`}
                      >
                        {cityStr}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Use Current Location (GPS) Button */}
        <button
          type="button"
          onClick={handleDetectGps}
          disabled={isDetectingGps}
          title={
            lang === 'ur'
              ? 'GPS کے ذریعے اپنی موجودہ لوکیشن معلوم کریں'
              : 'Detect current location via GPS'
          }
          className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] border border-[#14532D]/20 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isDetectingGps ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Navigation className="w-3.5 h-3.5" />
          )}
          <span>
            {lang === 'ur' ? 'Use Current Location' : 'Use Current Location'}
          </span>
        </button>
      </div>

      {/* GPS Error / Permission Notice */}
      {gpsError && (
        <div className="p-2.5 rounded-lg bg-[#FEF3C7] border border-[#F59E0B]/40 flex items-center justify-between gap-2 text-xs text-[#92400E]">
          <span className="flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            {gpsError}
          </span>
          <button
            type="button"
            onClick={() => setShowManualModal(true)}
            className="underline font-semibold shrink-0"
          >
            {lang === 'ur' ? 'دستی پتہ لکھیں' : 'Manual Entry'}
          </button>
        </div>
      )}

      {/* Active Structured Location Breakdown Pill */}
      {activeLocationObj && (
        <div className="px-3 py-2 rounded-lg bg-[#EAF2EC] border border-[#14532D]/20 flex flex-wrap items-center justify-between gap-2 text-xs text-[#14532D]">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="font-bold inline-flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {lang === 'ur' ? 'آپ کی منتخب لوکیشن:' : 'Your Selected Location:'}
            </span>
            {activeLocationObj.country && (
              <span>
                <strong>{lang === 'ur' ? 'ملک:' : 'Country:'}</strong>{' '}
                {activeLocationObj.country}
              </span>
            )}
            {activeLocationObj.state && (
              <span>
                <strong>{lang === 'ur' ? 'صوبہ:' : 'State:'}</strong>{' '}
                {activeLocationObj.state}
              </span>
            )}
            {activeLocationObj.city && (
              <span>
                <strong>{lang === 'ur' ? 'شہر:' : 'City:'}</strong>{' '}
                {activeLocationObj.city}
              </span>
            )}
            {activeLocationObj.area && (
              <span>
                <strong>{lang === 'ur' ? 'علاقہ:' : 'Area:'}</strong>{' '}
                {activeLocationObj.area}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setManualDraft(activeLocationObj);
                setShowManualModal(true);
              }}
              className="inline-flex items-center gap-1 underline font-semibold"
            >
              <Edit3 className="w-3 h-3" />
              {lang === 'ur' ? 'تبدیل کریں' : 'Edit'}
            </button>
            <button
              type="button"
              onClick={() => onSelectLocationFilter('all', null)}
              className="inline-flex items-center gap-1 text-[#991B1B] hover:underline font-semibold"
            >
              <X className="w-3 h-3" />
              {lang === 'ur' ? 'صاف کریں' : 'Clear'}
            </button>
          </div>
        </div>
      )}

      {/* Manual 5-Field Override Modal for Catalog Location */}
      {showManualModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white border border-[#E6E2D8] rounded-xl max-w-lg w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E2D8] pb-3">
              <h3 className="text-sm font-bold text-[#18241B]">
                {lang === 'ur'
                  ? 'لوکیشن خود درج یا تبدیل کریں (Manual Location Entry)'
                  : 'Enter or Change Your Location Manually'}
              </h3>
              <button
                type="button"
                onClick={() => setShowManualModal(false)}
                className="p-1 text-[#5C6660] hover:text-[#18241B]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleApplyManualDraft} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {lang === 'ur' ? 'ملک (Country)' : 'Country'}
                  </label>
                  <input
                    type="text"
                    value={manualDraft.country}
                    onChange={(e) =>
                      setManualDraft({ ...manualDraft, country: e.target.value })
                    }
                    placeholder={lang === 'ur' ? 'پاکستان' : 'Pakistan'}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {lang === 'ur' ? 'صوبہ / اسٹیٹ (State/Province)' : 'State / Province'}
                  </label>
                  <input
                    type="text"
                    value={manualDraft.state}
                    onChange={(e) =>
                      setManualDraft({ ...manualDraft, state: e.target.value })
                    }
                    placeholder={lang === 'ur' ? 'پنجاب / سندھ' : 'Punjab / Sindh'}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {lang === 'ur' ? 'شہر / ضلع (City)' : 'City / District'}
                  </label>
                  <input
                    type="text"
                    value={manualDraft.city}
                    onChange={(e) =>
                      setManualDraft({ ...manualDraft, city: e.target.value })
                    }
                    placeholder={lang === 'ur' ? 'ساہیوال / ملتان' : 'Sahiwal / Multan'}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {lang === 'ur' ? 'علاقہ / گاؤں (Area)' : 'Area / Village'}
                  </label>
                  <input
                    type="text"
                    value={manualDraft.area}
                    onChange={(e) =>
                      setManualDraft({ ...manualDraft, area: e.target.value })
                    }
                    placeholder={lang === 'ur' ? 'چیچہ وطنی' : 'Chichawatni'}
                    className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A554E] mb-1">
                  {lang === 'ur' ? 'مکمل پتہ (Full Address)' : 'Full Address'}
                </label>
                <input
                  type="text"
                  value={manualDraft.address}
                  onChange={(e) =>
                    setManualDraft({ ...manualDraft, address: e.target.value })
                  }
                  className="w-full px-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowManualModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-[#4A554E] bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                >
                  {lang === 'ur' ? 'منسوخ کریں' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                >
                  {lang === 'ur' ? 'لوکیشن محفوظ کریں' : 'Apply Location'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
