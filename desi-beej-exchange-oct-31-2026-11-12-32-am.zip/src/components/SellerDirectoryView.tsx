import React from 'react';
import {
  MessageCircle,
  MessageSquare,
  MapPin,
  Phone,
  ArrowLeft,
  ArrowRight,
} from 'lucide-react';
import { SellerProfile, SeedListing, Language } from '../types/seed';
import { UI_TEXT, formatWhatsAppUrl } from '../i18n/translations';
import { PAKISTANI_CITIES } from '../data/initialSeeds';
import { SeedCard } from './SeedCard';

interface SellerDirectoryViewProps {
  sellers: SellerProfile[];
  listings: SeedListing[];
  selectedSellerId: string | null;
  lang: Language;
  favorites: string[];
  onSelectSeller: (sellerId: string | null) => void;
  onSelectSeed: (seed: SeedListing) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onStartChatWithSeller: (seller: SellerProfile) => void;
  onStartChatWithSeed: (seed: SeedListing, e: React.MouseEvent) => void;
}

export const SellerDirectoryView: React.FC<SellerDirectoryViewProps> = ({
  sellers,
  listings,
  selectedSellerId,
  lang,
  favorites,
  onSelectSeller,
  onSelectSeed,
  onToggleFavorite,
  onStartChatWithSeller,
  onStartChatWithSeed,
}) => {
  const t = UI_TEXT[lang];

  const activeSeller = selectedSellerId
    ? sellers.find((s) => s.id === selectedSellerId) || null
    : null;

  if (activeSeller) {
    const sellerSeeds = listings.filter(
      (item) =>
        item.sellerId === activeSeller.id ||
        item.sellerNameEn.toLowerCase() === activeSeller.nameEn.toLowerCase()
    );
    const name = lang === 'ur' ? activeSeller.nameUr : activeSeller.nameEn;
    const farm = lang === 'ur' ? activeSeller.farmNameUr : activeSeller.farmNameEn;
    const bio = lang === 'ur' ? activeSeller.bioUr : activeSeller.bioEn;
    const pledge = lang === 'ur' ? activeSeller.seedPledgeUr : activeSeller.seedPledgeEn;
    const location = lang === 'ur' ? activeSeller.locationUr : activeSeller.locationEn;

    const whatsappUrl = formatWhatsAppUrl(
      activeSeller.phone,
      lang === 'ur'
        ? `السلام علیکم ${name} صاحب، میں دیسی بیج ایکسچینج کے ذریعے آپ کے فارم (${farm}) سے دیسی بیجوں کے تبادلے اور خریداری کے لیے رابطہ کر رہا ہوں۔`
        : `Assalam-o-Alaikum ${activeSeller.nameEn}, I am reaching out from Desi Beej Exchange regarding your heirloom seeds at ${activeSeller.farmNameEn}.`
    );

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <button
          type="button"
          onClick={() => onSelectSeller(null)}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#4A554E] hover:text-[#14532D]"
        >
          {lang === 'ur' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          <span>{lang === 'ur' ? 'تمام کسانوں کی فہرست پر واپس جائیں' : 'Back to All Farmers'}</span>
        </button>

        {/* Farmer Profile Header Card */}
        <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 sm:p-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
            <div className="space-y-3 max-w-3xl">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                <span className="font-semibold text-[#14532D]">{farm}</span>
                <span aria-hidden="true">·</span>
                <span>
                  {lang === 'ur' ? activeSeller.provinceUr : activeSeller.provinceEn}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-num">
                  {activeSeller.experienceYears} {t.yearsExperience}
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">{name}</h1>

              <div className="flex items-center gap-2 text-sm text-[#4A554E]">
                <MapPin className="w-4 h-4 text-[#14532D] shrink-0" />
                <span>{location}</span>
              </div>

              <p className="text-base text-[#36403A] leading-relaxed pt-2">{bio}</p>

              <div className="pt-3 text-xs text-[#4A554E]">
                <span className="font-semibold text-[#18241B]">
                  {lang === 'ur' ? 'دیسی بیج عہد: ' : 'Seed Purity Pledge: '}
                </span>
                <span>{pledge}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row lg:flex-col gap-3 shrink-0 min-w-[230px]">
              <button
                type="button"
                onClick={() => onStartChatWithSeller(activeSeller)}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{t.chatWithFarmer}</span>
              </button>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.contactViaWhatsApp}</span>
              </a>
              <div className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs font-medium text-[#18241B] bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg font-mono-num">
                <Phone className="w-3.5 h-3.5 text-[#14532D]" />
                <span>{activeSeller.phone}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Farmer's Active Seed Listings */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-[#18241B]">
            {lang === 'ur'
              ? `${name} کے دستیاب دیسی بیج (${sellerSeeds.length})`
              : `Seeds Listed by ${activeSeller.nameEn} (${sellerSeeds.length})`}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sellerSeeds.map((seed) => (
              <SeedCard
                key={seed.id}
                seed={seed}
                lang={lang}
                isFavorite={favorites.includes(seed.id)}
                onToggleFavorite={onToggleFavorite}
                onSelectSeed={onSelectSeed}
                onSelectSeller={() => {}}
                onStartChat={onStartChatWithSeed}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      <div className="max-w-2xl">
        <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">
          {lang === 'ur'
            ? 'پاکستان کے روایتی بیج محافظ کسان (سیڈ گارڈینز)'
            : 'Verified Pakistani Seed Guardians & Traditional Farmers'}
        </h1>
        <p className="text-sm text-[#4A554E] mt-2 leading-relaxed">
          {lang === 'ur'
            ? 'پنجاب اور سندھ کے ان تجربہ کار کاشتکاروں سے براہ راست چیٹ، وائس کال یا واٹس ایپ پر رابطہ کریں جو دہائیوں سے خالص دیسی بیجوں کی حفاظت اور تبادلہ کر رہے ہیں۔'
            : 'Connect via in-app Farmer Chat, live WebRTC Voice Call, or WhatsApp with multi-generational seed keepers across Punjab and Sindh.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sellers.map((seller) => {
          const name = lang === 'ur' ? seller.nameUr : seller.nameEn;
          const farm = lang === 'ur' ? seller.farmNameUr : seller.farmNameEn;
          const bio = lang === 'ur' ? seller.bioUr : seller.bioEn;
          const cityObj = PAKISTANI_CITIES.find(
            (c) => c.id.toLowerCase() === seller.city.toLowerCase()
          );
          const cityLabel = cityObj ? (lang === 'ur' ? cityObj.nameUr : cityObj.nameEn) : seller.city;
          const seedCount = listings.filter((l) => l.sellerId === seller.id).length;

          const whatsappUrl = formatWhatsAppUrl(
            seller.phone,
            `Assalam-o-Alaikum ${seller.nameEn}, I found your profile on Desi Beej Exchange.`
          );

          return (
            <div
              key={seller.id}
              className="bg-white border border-[#E6E2D8] rounded-xl p-6 flex flex-col justify-between gap-5"
            >
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#5C6660]">
                  <span className="font-semibold text-[#14532D]">{cityLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">
                    {seller.experienceYears} {t.yearsExperience}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num">
                    {seller.totalExchanges} {t.completedExchanges}
                  </span>
                </div>

                <div>
                  <h2 className="text-lg font-bold text-[#18241B]">{name}</h2>
                  <p className="text-xs font-medium text-[#4A554E] mt-0.5">{farm}</p>
                </div>

                <p className="text-sm text-[#36403A] leading-relaxed line-clamp-3">{bio}</p>
              </div>

              <div className="pt-4 border-t border-[#F0EDE6] flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => onSelectSeller(seller.id)}
                  className="text-xs font-semibold text-[#14532D] hover:underline"
                >
                  {t.viewFullSellerProfile} ({seedCount}) →
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onStartChatWithSeller(seller)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{t.chatWithFarmer}</span>
                  </button>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>{t.whatsappSeller}</span>
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
