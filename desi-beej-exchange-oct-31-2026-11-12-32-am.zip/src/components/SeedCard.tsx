import React from 'react';
import { Heart, MessageCircle, MessageSquare, ArrowUpRight, MapPin } from 'lucide-react';
import { SeedListing, Language } from '../types/seed';
import { CATEGORY_LABELS, EXCHANGE_LABELS, UI_TEXT, formatPKR, formatWhatsAppUrl } from '../i18n/translations';
import { PAKISTANI_CITIES } from '../data/initialSeeds';
import { SeedImage } from './SeedImage';
import { locationService } from '../services/locationService';

interface SeedCardProps {
  seed: SeedListing;
  lang: Language;
  isFavorite: boolean;
  distanceKm?: number | null;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onSelectSeed: (seed: SeedListing) => void;
  onSelectSeller: (sellerId: string, e: React.MouseEvent) => void;
  onStartChat?: (seed: SeedListing, e: React.MouseEvent) => void;
}

export const SeedCard: React.FC<SeedCardProps> = ({
  seed,
  lang,
  isFavorite,
  distanceKm,
  onToggleFavorite,
  onSelectSeed,
  onSelectSeller,
  onStartChat,
}) => {
  const t = UI_TEXT[lang];
  const title = lang === 'ur' ? seed.nameUr || seed.nameEn : seed.nameEn;
  const secondaryTitle = lang === 'ur' ? seed.nameEn : seed.nameUr;
  const categoryLabel = CATEGORY_LABELS[seed.category][lang];
  const structuredLoc = locationService.resolveSeedStructuredLocation(seed, lang);
  const cityObj = PAKISTANI_CITIES.find((c) => c.id.toLowerCase() === seed.city.toLowerCase());
  const cityLabel =
    structuredLoc.city && structuredLoc.country && structuredLoc.country !== 'Pakistan' && structuredLoc.country !== 'پاکستان'
      ? `${structuredLoc.city}, ${structuredLoc.country}`
      : cityObj
        ? lang === 'ur'
          ? cityObj.nameUr
          : cityObj.nameEn
        : structuredLoc.city || seed.city;
  const exchangeLabel = EXCHANGE_LABELS[seed.exchangeType][lang];
  const quantityText = lang === 'ur' ? seed.quantityUr || seed.quantityEn : seed.quantityEn;
  const sellerName = lang === 'ur' ? seed.sellerNameUr || seed.sellerNameEn : seed.sellerNameEn;

  const whatsappMessage =
    lang === 'ur'
      ? `السلام علیکم ${seed.sellerNameUr || seed.sellerNameEn} صاحب، میں دیسی بیج ایکسچینج پر آپ کے بیج "${seed.nameUr || seed.nameEn}" (${seed.city}) کے بارے میں معلومات لینا چاہتا ہوں۔`
      : `Assalam-o-Alaikum ${seed.sellerNameEn}, I found your "${seed.nameEn}" (${seed.city}) listing on Desi Beej Exchange and would like to inquire about purchasing or exchanging seeds.`;

  const whatsappHref = formatWhatsAppUrl(seed.sellerPhone, whatsappMessage);

  return (
    <article
      onClick={() => onSelectSeed(seed)}
      className="group bg-white border border-[#E6E2D8] rounded-xl overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5 cursor-pointer"
    >
      <div>
        {/* 4:3 Lead Product Image */}
        <div className="relative aspect-4/3 w-full bg-[#F4F1EA] overflow-hidden">
          <SeedImage
            src={seed.image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <button
            type="button"
            onClick={(e) => onToggleFavorite(seed.id, e)}
            aria-label={isFavorite ? t.savedInFavorites : t.saveToFavorites}
            className={`absolute top-3 end-3 w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
              isFavorite
                ? 'bg-[#14532D] text-white'
                : 'bg-white/90 text-[#18241B] hover:bg-white'
            }`}
          >
            <Heart className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>

        {/* Card Content with Zero-Pill Metadata Discipline */}
        <div className="p-5">
          {/* Unboxed Metadata Line */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#5C6660] mb-2">
            <span className="font-medium text-[#14532D]">{categoryLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1">
              <MapPin className="w-3 h-3 text-[#14532D]" />
              {cityLabel}
            </span>
            {typeof distanceKm === 'number' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-semibold text-[#14532D] font-mono-num">
                  {distanceKm} km
                </span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>{exchangeLabel}</span>
          </div>

          {/* Primary Seed Title */}
          <h3 className="text-base font-semibold text-[#18241B] group-hover:text-[#14532D] transition-colors line-clamp-2 leading-snug">
            {title}
          </h3>

          {/* Bilingual Cross-Reference Subtitle */}
          {secondaryTitle && (
            <p className="text-xs text-[#6E7872] mt-1 line-clamp-1">
              {secondaryTitle}
            </p>
          )}

          {/* Description Excerpt */}
          <p className="text-sm text-[#4A554E] mt-2.5 line-clamp-2 leading-relaxed">
            {lang === 'ur' ? seed.descriptionUr || seed.descriptionEn : seed.descriptionEn}
          </p>
        </div>
      </div>

      {/* Price, Seller Link & Direct Actions Footer */}
      <div className="px-5 pb-5 pt-3 border-t border-[#F0EDE6] flex flex-col gap-3">
        <div className="flex items-baseline justify-between gap-2">
          <div>
            <span className="text-base font-semibold text-[#18241B] font-mono-num">
              {formatPKR(seed.pricePKR, lang)}
            </span>
            <span className="text-xs text-[#5C6660] ms-1.5">
              / {quantityText}
            </span>
          </div>
          <span className="text-xs text-[#5C6660] font-mono-num">
            {seed.germinationRate}% {lang === 'ur' ? 'اگاؤ' : 'Germ.'}
          </span>
        </div>

        <div className="flex items-center justify-between gap-2 pt-1">
          <button
            type="button"
            onClick={(e) => onSelectSeller(seed.sellerId, e)}
            className="text-xs text-[#4A554E] hover:text-[#14532D] underline-offset-4 hover:underline truncate text-start"
          >
            {sellerName} ({cityLabel})
          </button>

          <div className="flex items-center gap-1.5 shrink-0">
            {onStartChat && (
              <button
                type="button"
                onClick={(e) => onStartChat(seed, e)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>{lang === 'ur' ? 'چیٹ' : 'Chat'}</span>
              </button>
            )}
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>{t.whatsappSeller}</span>
            </a>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onSelectSeed(seed);
              }}
              aria-label={t.viewDetails}
              className="p-1.5 text-[#4A554E] hover:text-[#18241B] rounded-lg border border-[#E6E2D8] hover:border-[#18241B] transition-colors"
            >
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </article>
  );
};
