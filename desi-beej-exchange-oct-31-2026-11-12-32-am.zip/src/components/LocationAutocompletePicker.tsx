import React, { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Navigation,
  Search,
  Loader2,
  Edit3,
  AlertCircle,
  CheckCircle2,
  X,
  Globe,
} from 'lucide-react';
import { Language, StructuredLocation } from '../types/seed';
import {
  locationService,
  LocationSuggestion,
  GeolocationError,
} from '../services/locationService';

interface LocationAutocompletePickerProps {
  lang: Language;
  value: StructuredLocation;
  onChange: (nextLocation: StructuredLocation) => void;
  compact?: boolean;
  required?: boolean;
  labelEn?: string;
  labelUr?: string;
}

export const LocationAutocompletePicker: React.FC<LocationAutocompletePickerProps> = ({
  lang,
  value,
  onChange,
  compact = false,
  required = true,
  labelEn = 'Farm / Seed Location (Global Search or GPS)',
  labelUr = 'بیج یا فارم کا مقام (خودکار سرچ یا GPS لوکیشن)',
}) => {
  const [searchText, setSearchText] = useState('');
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);

  const [isDetectingGps, setIsDetectingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gpsSuccessBanner, setGpsSuccessBanner] = useState(false);
  const [isManualExpanded, setIsManualExpanded] = useState(!compact);

  const containerRef = useRef<HTMLDivElement>(null);

  // Close autocomplete dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced live address search (400ms)
  useEffect(() => {
    const trimmed = searchText.trim();
    if (trimmed.length < 2) {
      setSuggestions([]);
      setIsSearching(false);
      return;
    }

    const controller = new AbortController();
    setIsSearching(true);

    const timer = setTimeout(async () => {
      try {
        const results = await locationService.searchLocations(
          trimmed,
          lang,
          controller.signal
        );
        setSuggestions(results);
        setIsDropdownOpen(true);
        setActiveIndex(-1);
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          setSuggestions([]);
        }
      } finally {
        setIsSearching(false);
      }
    }, 400);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [searchText, lang]);

  const handleSelectSuggestion = (suggestion: LocationSuggestion) => {
    const loc = suggestion.structured;
    onChange({
      country: loc.country,
      state: loc.state,
      city: loc.city || suggestion.primaryText,
      area: loc.area,
      address: loc.address || [suggestion.primaryText, suggestion.secondaryText].filter(Boolean).join(', '),
      latitude: loc.latitude,
      longitude: loc.longitude,
      source: 'autocomplete',
      formattedAddress: loc.formattedAddress,
    });
    setSearchText('');
    setSuggestions([]);
    setIsDropdownOpen(false);
    setGpsError(null);
    setIsManualExpanded(true);
  };

  const handleUseCurrentLocation = async () => {
    setIsDetectingGps(true);
    setGpsError(null);
    setGpsSuccessBanner(false);

    try {
      const detected = await locationService.detectCurrentLocation(lang);
      onChange(detected);
      setGpsSuccessBanner(true);
      setIsManualExpanded(true);
      setTimeout(() => setGpsSuccessBanner(false), 4000);
    } catch (err: any) {
      if (err instanceof GeolocationError) {
        setGpsError(lang === 'ur' ? err.messageUr : err.messageEn);
      } else {
        setGpsError(
          lang === 'ur'
            ? 'GPS لوکیشن معلوم نہیں ہو سکی۔ براہِ کرم نیچے دستی طور پر اپنا پتہ لکھیں۔'
            : 'Could not detect GPS location. Please enter your address manually below.'
        );
      }
      // Automatically open manual fields when GPS permission is denied or fails
      setIsManualExpanded(true);
    } finally {
      setIsDetectingGps(false);
    }
  };

  const handleFieldChange = (
    field: keyof Pick<
      StructuredLocation,
      'country' | 'state' | 'city' | 'area' | 'address'
    >,
    fieldValue: string
  ) => {
    onChange({
      ...value,
      [field]: fieldValue,
      source: value.source || 'manual',
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isDropdownOpen || suggestions.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((prev) => (prev > 0 ? prev - 1 : suggestions.length - 1));
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      e.preventDefault();
      handleSelectSuggestion(suggestions[activeIndex]);
    } else if (e.key === 'Escape') {
      setIsDropdownOpen(false);
    }
  };

  const hasStructuredSelection = Boolean(
    value.country || value.state || value.city || value.area || value.address
  );

  return (
    <div
      ref={containerRef}
      className="bg-[#FAF8F5] border border-[#E6E2D8] rounded-xl p-4 space-y-4"
    >
      {/* Header Row + Use Current Location (GPS) Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div>
          <label className="block text-xs font-semibold text-[#18241B]">
            {lang === 'ur' ? labelUr : labelEn} {required ? '*' : ''}
          </label>
          <p className="text-[11px] text-[#5C6660] mt-0.5">
            {lang === 'ur'
              ? 'دنیا بھر کے کسی بھی ملک، صوبے، شہر، گاؤں یا علاقے کا نام لکھیں یا GPS استعمال کریں'
              : 'Search any country, state, city, village, or street address worldwide, or detect via GPS'}
          </p>
        </div>

        <button
          type="button"
          onClick={handleUseCurrentLocation}
          disabled={isDetectingGps}
          className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          {isDetectingGps ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>
                {lang === 'ur'
                  ? 'لوکیشن معلوم کی جا رہی ہے...'
                  : 'Detecting GPS...'}
              </span>
            </>
          ) : (
            <>
              <Navigation className="w-3.5 h-3.5" />
              <span>
                {lang === 'ur'
                  ? 'Use Current Location (موجودہ لوکیشن)'
                  : 'Use Current Location (GPS)'}
              </span>
            </>
          )}
        </button>
      </div>

      {/* Autocomplete Search Box */}
      <div className="relative">
        <div className="relative flex items-center">
          <Search className="w-4 h-4 text-[#5C6660] absolute start-3.5 pointer-events-none" />
          <input
            type="text"
            value={searchText}
            onChange={(e) => {
              setSearchText(e.target.value);
              setIsDropdownOpen(true);
            }}
            onFocus={() => {
              if (suggestions.length > 0) setIsDropdownOpen(true);
            }}
            onKeyDown={handleKeyDown}
            placeholder={
              lang === 'ur'
                ? 'شہر، گاؤں، چک، علاقہ یا ملک تلاش کریں (مثلاً: ساہیوال، ملتان، چک، لاہور، ریاض، لندن)...'
                : 'Type city, village, area, or full address (e.g., Sahiwal, Chak, Multan, Lahore, Dubai, London)...'
            }
            className="w-full ps-10 pe-9 py-2.5 text-sm bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
          />
          {isSearching ? (
            <Loader2 className="w-4 h-4 text-[#14532D] animate-spin absolute end-3" />
          ) : searchText ? (
            <button
              type="button"
              onClick={() => {
                setSearchText('');
                setSuggestions([]);
                setIsDropdownOpen(false);
              }}
              className="p-1 text-[#5C6660] hover:text-[#18241B] absolute end-2.5"
              aria-label="Clear search"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          ) : null}
        </div>

        {/* Live Suggestions Dropdown */}
        {isDropdownOpen && searchText.trim().length >= 2 && (
          <div className="absolute z-30 mt-1 w-full bg-white border border-[#E6E2D8] rounded-xl shadow-lg max-h-64 overflow-y-auto divide-y divide-[#F0EDE6]">
            {isSearching && suggestions.length === 0 ? (
              <div className="p-3.5 text-xs text-[#5C6660] flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#14532D]" />
                <span>
                  {lang === 'ur'
                    ? 'عالمی نقشے سے پتے تلاش کیے جا رہے ہیں...'
                    : 'Searching global addresses and villages...'}
                </span>
              </div>
            ) : suggestions.length > 0 ? (
              suggestions.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleSelectSuggestion(item)}
                  className={`w-full text-start px-3.5 py-2.5 flex items-start gap-2.5 transition-colors ${
                    index === activeIndex
                      ? 'bg-[#EAF2EC]'
                      : 'hover:bg-[#FAF8F5]'
                  }`}
                >
                  <MapPin className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold text-[#18241B] truncate">
                      {item.primaryText}
                    </p>
                    {item.secondaryText && (
                      <p className="text-[11px] text-[#5C6660] truncate mt-0.5">
                        {item.secondaryText}
                      </p>
                    )}
                    <div className="flex flex-wrap items-center gap-1.5 mt-1 text-[10px] text-[#14532D]">
                      {item.structured.country && (
                        <span>
                          {lang === 'ur' ? 'ملک:' : 'Country:'} {item.structured.country}
                        </span>
                      )}
                      {item.structured.state && (
                        <span>
                          · {lang === 'ur' ? 'صوبہ:' : 'State:'} {item.structured.state}
                        </span>
                      )}
                      {item.structured.city && (
                        <span>
                          · {lang === 'ur' ? 'شہر:' : 'City:'} {item.structured.city}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              ))
            ) : (
              <div className="p-3.5 space-y-2">
                <p className="text-xs text-[#5C6660]">
                  {lang === 'ur'
                    ? 'کوئی خودکار تجویز نہیں ملی۔ آپ نیچے دیے گئے بٹن سے اسی نام کو بطور پتہ استعمال کر سکتے ہیں:'
                    : 'No automatic match found. You can apply this text directly or fill the manual fields below:'}
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onChange({
                      ...value,
                      city: value.city || searchText.trim(),
                      address: searchText.trim(),
                      source: 'manual',
                    });
                    setSearchText('');
                    setIsDropdownOpen(false);
                    setIsManualExpanded(true);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] rounded-lg"
                >
                  {lang === 'ur'
                    ? `"${searchText.trim()}" بطور پتہ محفوظ کریں`
                    : `Use "${searchText.trim()}" as Manual Address`}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* GPS Detection Success Notice */}
      {gpsSuccessBanner && (
        <div className="p-2.5 rounded-lg bg-[#EAF2EC] border border-[#14532D]/25 flex items-center gap-2 text-xs text-[#14532D]">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>
            {lang === 'ur'
              ? 'GPS کے ذریعے آپ کا موجودہ مقام کامیابی سے حاصل کر لیا گیا ہے۔ آپ نیچے تفصیلات دیکھ یا تبدیل کر سکتے ہیں۔'
              : 'Current GPS location detected and structured fields populated. You can review or edit any field below.'}
          </span>
        </div>
      )}

      {/* GPS Permission Denied / Unavailable Fallback Notice */}
      {gpsError && (
        <div className="p-3 rounded-lg bg-[#FEF3C7] border border-[#F59E0B]/40 flex items-start gap-2.5 text-xs text-[#92400E]">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold">
              {lang === 'ur'
                ? 'GPS لوکیشن کی اطلاع (دستی اندراج فعال ہے)'
                : 'GPS Location Notice — Manual Entry Enabled'}
            </p>
            <p>{gpsError}</p>
          </div>
        </div>
      )}

      {/* Active Selected Location Summary Bar & Toggle Manual Edit */}
      {hasStructuredSelection && (
        <div className="bg-white border border-[#E6E2D8] rounded-lg px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-start gap-2 min-w-0">
            <Globe className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
            <div className="min-w-0">
              <p className="text-xs font-semibold text-[#18241B] truncate">
                {locationService.formatDisplayLocation(value)}
              </p>
              <p className="text-[11px] text-[#5C6660] truncate">
                {value.address || locationService.formatDisplayLocation(value)}
                {typeof value.latitude === 'number' &&
                  typeof value.longitude === 'number' && (
                    <span className="font-mono-num ms-1.5 text-[#14532D]">
                      ({value.latitude.toFixed(4)}, {value.longitude.toFixed(4)})
                    </span>
                  )}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsManualExpanded(!isManualExpanded)}
            className="inline-flex items-center gap-1 text-xs font-semibold text-[#14532D] hover:underline shrink-0"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>
              {isManualExpanded
                ? lang === 'ur'
                  ? 'تفصیلی خانے چھپائیں'
                  : 'Hide Fields'
                : lang === 'ur'
                  ? 'لوکیشن تبدیل / دستی درج کریں'
                  : 'Change / Edit Manually'}
            </span>
          </button>
        </div>
      )}

      {/* 5 Separate Structured Fields (Country, State/Province, City, Area, Full Address) */}
      {isManualExpanded && (
        <div className="pt-2 border-t border-[#E6E2D8] space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-[#4A554E]">
              {lang === 'ur'
                ? 'منتخب مقام کی الگ الگ تفصیلات (آپ خود بھی تبدیل یا درج کر سکتے ہیں):'
                : 'Structured Location Fields (Saved separately — editable manually):'}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {/* 1. Country */}
            <div>
              <label className="block text-[11px] font-medium text-[#4A554E] mb-1">
                {lang === 'ur' ? 'ملک (Country) *' : 'Country *'}
              </label>
              <input
                type="text"
                required={required}
                value={value.country}
                onChange={(e) => handleFieldChange('country', e.target.value)}
                placeholder={lang === 'ur' ? 'مثلاً: پاکستان' : 'e.g., Pakistan'}
                className="w-full px-3 py-2 text-xs bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>

            {/* 2. State / Province */}
            <div>
              <label className="block text-[11px] font-medium text-[#4A554E] mb-1">
                {lang === 'ur' ? 'صوبہ / اسٹیٹ (State/Province) *' : 'State / Province *'}
              </label>
              <input
                type="text"
                required={required}
                value={value.state}
                onChange={(e) => handleFieldChange('state', e.target.value)}
                placeholder={lang === 'ur' ? 'مثلاً: پنجاب / سندھ' : 'e.g., Punjab / Sindh'}
                className="w-full px-3 py-2 text-xs bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>

            {/* 3. City / District */}
            <div>
              <label className="block text-[11px] font-medium text-[#4A554E] mb-1">
                {lang === 'ur' ? 'شہر / ضلع (City) *' : 'City / District *'}
              </label>
              <input
                type="text"
                required={required}
                value={value.city}
                onChange={(e) => handleFieldChange('city', e.target.value)}
                placeholder={lang === 'ur' ? 'مثلاً: ساہیوال / ملتان' : 'e.g., Sahiwal / Multan'}
                className="w-full px-3 py-2 text-xs bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>

            {/* 4. Area / Village / Tehsil */}
            <div>
              <label className="block text-[11px] font-medium text-[#4A554E] mb-1">
                {lang === 'ur' ? 'علاقہ / گاؤں / تحصیل (Area)' : 'Area / Village / Tehsil'}
              </label>
              <input
                type="text"
                value={value.area}
                onChange={(e) => handleFieldChange('area', e.target.value)}
                placeholder={
                  lang === 'ur' ? 'مثلاً: چیچہ وطنی / چک 89' : 'e.g., Chichawatni / Chak 89'
                }
                className="w-full px-3 py-2 text-xs bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
          </div>

          {/* 5. Full Street / Mandi Address */}
          <div>
            <label className="block text-[11px] font-medium text-[#4A554E] mb-1">
              {lang === 'ur'
                ? 'مکمل پتہ (Full Address / Mandi / Village Details) *'
                : 'Full Address (Village, Chak, Mandi or Street Address) *'}
            </label>
            <input
              type="text"
              required={required}
              value={value.address}
              onChange={(e) => handleFieldChange('address', e.target.value)}
              placeholder={
                lang === 'ur'
                  ? 'مثلاً: چک 89/6-R، ہڑپہ روڈ، ساہیوال، پنجاب، پاکستان'
                  : 'e.g., Chak 89/6-R, Harrappa Road, Sahiwal, Punjab, Pakistan'
              }
              className="w-full px-3 py-2 text-xs bg-white border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
            />
          </div>
        </div>
      )}
    </div>
  );
};
