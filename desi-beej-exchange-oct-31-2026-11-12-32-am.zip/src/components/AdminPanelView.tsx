import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  LogOut,
  Users,
  Sprout,
  AlertTriangle,
  Flag,
  Settings,
  Activity,
  CheckCircle2,
  XCircle,
  Trash2,
  Ban,
  Unlock,
  Search,
  Download,
  Lock,
  Info,
  Eye,
  Globe,
} from 'lucide-react';
import {
  Language,
  SeedListing,
  SellerProfile,
  UserReport,
  AdminActivityLog,
  PlatformSettings,
  AdminSession,
  ListingApprovalStatus,
} from '../types/seed';
import { adminService } from '../services/adminService';
import { CATEGORY_LABELS, EXCHANGE_LABELS, formatPKR } from '../i18n/translations';
import { SeedImage } from './SeedImage';

interface AdminPanelViewProps {
  lang: Language;
  allListings: SeedListing[];
  users: SellerProfile[];
  reports: UserReport[];
  activityLogs: AdminActivityLog[];
  platformSettings: PlatformSettings;
  adminSession: AdminSession | null;
  onAdminLoginSuccess: (session: AdminSession) => void;
  onAdminLogout: () => void;
  onToggleBlockUser: (userId: string) => void;
  onUpdateListingApproval: (seedId: string, status: ListingApprovalStatus) => void;
  onUpdateListingFakeFlag: (
    seedId: string,
    isFake: boolean,
    reasonEn?: string,
    reasonUr?: string
  ) => void;
  onDeleteListing: (seedId: string) => void;
  onUpdateReportStatus: (
    reportId: string,
    status: 'open' | 'investigating' | 'resolved' | 'dismissed',
    note?: string
  ) => void;
  onSaveSettings: (newSettings: PlatformSettings) => void;
  onInspectSeed: (seed: SeedListing) => void;
  onExitAdmin: () => void;
  onChangeLanguage?: (nextLang: Language) => void;
}

type AdminTab =
  | 'overview'
  | 'users'
  | 'listings'
  | 'fraud'
  | 'reports'
  | 'settings'
  | 'logs';

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  lang,
  allListings,
  users,
  reports,
  activityLogs,
  platformSettings,
  adminSession,
  onAdminLoginSuccess,
  onAdminLogout,
  onToggleBlockUser,
  onUpdateListingApproval,
  onUpdateListingFakeFlag,
  onDeleteListing,
  onUpdateReportStatus,
  onSaveSettings,
  onInspectSeed,
  onExitAdmin,
  onChangeLanguage,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [adminEmailInput, setAdminEmailInput] = useState('admin@desibeej.pk');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [userSearch, setUserSearch] = useState('');
  const [listingFilter, setListingFilter] = useState<
    'all' | 'approved' | 'pending' | 'rejected'
  >('all');
  const [listingSearch, setListingSearch] = useState('');
  const [reportFilter, setReportFilter] = useState<'all' | 'open' | 'resolved'>('all');

  // Settings Form State
  const [settingsDraft, setSettingsDraft] = useState<PlatformSettings>(platformSettings);
  const [settingsSavedMsg, setSettingsSavedMsg] = useState(false);

  const isFirebaseConfigured = adminService.isFirebaseConfigured();

  // =========================================================================
  // COMPUTED METRICS & FRAUD SCANS (Unconditional hooks before early return)
  // =========================================================================
  const totalUsers = users.length;
  const blockedUsersCount = users.filter((u) => u.status === 'blocked').length;
  const totalListings = allListings.length;
  const saleListingsCount = allListings.filter(
    (l) => l.exchangeType === 'sale' || l.exchangeType === 'both'
  ).length;
  const exchangeListingsCount = allListings.filter(
    (l) => l.exchangeType === 'exchange' || l.exchangeType === 'both'
  ).length;
  const pendingListingsCount = allListings.filter(
    (l) => l.approvalStatus === 'pending'
  ).length;
  const openReportsCount = reports.filter((r) => r.status === 'open').length;

  const fraudScans = useMemo(() => {
    return allListings.map((listing) => ({
      listing,
      assessment: adminService.analyzeListingFraud(listing, reports),
    }));
  }, [allListings, reports]);

  const suspectedFakeList = useMemo(
    () => fraudScans.filter((item) => item.assessment.isSuspect),
    [fraudScans]
  );

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    if (!q) return users;
    return users.filter(
      (u) =>
        u.nameEn.toLowerCase().includes(q) ||
        u.nameUr.toLowerCase().includes(q) ||
        u.city.toLowerCase().includes(q) ||
        u.phone.toLowerCase().includes(q)
    );
  }, [users, userSearch]);

  const filteredListings = useMemo(() => {
    const q = listingSearch.trim().toLowerCase();
    return allListings.filter((item) => {
      if (
        listingFilter !== 'all' &&
        (item.approvalStatus || 'approved') !== listingFilter
      ) {
        return false;
      }
      if (!q) return true;
      return (
        item.nameEn.toLowerCase().includes(q) ||
        (item.nameUr || '').toLowerCase().includes(q) ||
        item.sellerNameEn.toLowerCase().includes(q) ||
        item.city.toLowerCase().includes(q)
      );
    });
  }, [allListings, listingFilter, listingSearch]);

  const filteredReports = useMemo(() => {
    if (reportFilter === 'all') return reports;
    if (reportFilter === 'open') {
      return reports.filter(
        (r) => r.status === 'open' || r.status === 'investigating'
      );
    }
    return reports.filter(
      (r) => r.status === 'resolved' || r.status === 'dismissed'
    );
  }, [reports, reportFilter]);

  // =========================================================================
  // 1. SECURE ADMIN LOGIN GATE (Visible only before authorized session)
  // =========================================================================
  if (!adminSession) {
    const handleStartDemoAdmin = async (e: React.FormEvent) => {
      e.preventDefault();
      setLoginError(null);
      const session = await adminService.startDemoPreviewAdminSession(adminEmailInput);
      onAdminLoginSuccess(session);
    };

    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E6E2D8] pb-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-[#14532D] text-white flex items-center justify-center shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-[#18241B]">
                  {lang === 'ur'
                    ? 'محفوظ ایڈمن لاگ ان (Admin Portal)'
                    : 'Authorized Admin Portal Login'}
                </h1>
                <p className="text-xs text-[#5C6660]">
                  {lang === 'ur'
                    ? 'یہ کنٹرول پینل صرف مجاز ایڈمنسٹریٹرز کے لیے مخصوص ہے۔'
                    : 'Restricted to authorized Desi Beej Exchange administrators.'}
                </p>
              </div>
            </div>

            {onChangeLanguage && (
              <div
                className="inline-flex items-center gap-1 bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg p-1 shrink-0"
                role="group"
                aria-label="Admin Panel Language Toggle"
              >
                <Globe className="w-3.5 h-3.5 text-[#14532D] ms-1.5 me-0.5" />
                <button
                  type="button"
                  onClick={() => onChangeLanguage('en')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    lang === 'en'
                      ? 'bg-[#14532D] text-white'
                      : 'text-[#4A554E] hover:text-[#18241B]'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => onChangeLanguage('ur')}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                    lang === 'ur'
                      ? 'bg-[#14532D] text-white'
                      : 'text-[#4A554E] hover:text-[#18241B]'
                  }`}
                >
                  اردو
                </button>
              </div>
            )}
          </div>

          {/* Transparent Security & Firebase Configuration Notice */}
          <div className="p-4 rounded-xl bg-[#F3EFE6] border border-[#E6E2D8] space-y-2 text-xs text-[#36403A] leading-relaxed">
            <div className="flex items-center gap-2 font-bold text-[#14532D]">
              <Info className="w-4 h-4 shrink-0" />
              <span>
                {isFirebaseConfigured
                  ? lang === 'ur'
                    ? 'فائر بیس سکیورٹی فعال ہے'
                    : 'Firebase Authentication Configured'
                  : lang === 'ur'
                    ? 'پریویو ڈیمو موڈ (Firebase کنفیگریشن موجود نہیں ہے)'
                    : 'Preview Demo Mode Active (Firebase Not Configured Yet)'}
              </span>
            </div>
            <p>
              {lang === 'ur'
                ? 'سکیورٹی اصولوں کے مطابق کسی بھی قسم کا ایڈمن پاس ورڈ یا پن (PIN) ایچ ٹی ایم ایل یا جاوا اسکرپٹ کوڈ میں ہارڈ کوڈ (Hardcode) نہیں کیا گیا۔ پروڈکشن میں فائر بیس آتھینٹیکیشن (Firebase Auth) اور firestore.rules کے ذریعے ایڈمن کی تصدیق ہوتی ہے۔ اس وقت فائر بیس منسلک نہ ہونے کی وجہ سے آپ نیچے دیے گئے بٹن سے محفوظ "پریویو ڈیمو ایڈمن سیشن" چلا کر تمام فیچرز ٹیسٹ کر سکتے ہیں۔'
                : 'For strict security compliance, no Admin password or PIN is hardcoded in HTML or client-side JavaScript. Production deployments enforce Firebase Auth custom claims and firestore.rules RBAC. Because Firebase is not configured in this preview environment yet, you can launch an ephemeral Preview Demo Admin Session below to test all moderation, user blocking, fraud detection, and audit features.'}
            </p>
          </div>

          {loginError && (
            <div className="p-3 rounded-lg bg-[#FEF2F2] border border-[#FECACA] text-xs text-[#991B1B]">
              {loginError}
            </div>
          )}

          <form onSubmit={handleStartDemoAdmin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {lang === 'ur'
                  ? 'ایڈمن شناختی ای میل (آڈٹ لاگ کے لیے)'
                  : 'Admin Identifier Email (Recorded in Activity Audit Log)'}
              </label>
              <input
                type="email"
                required
                value={adminEmailInput}
                onChange={(e) => setAdminEmailInput(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D] font-mono-num"
              />
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <button
                type="submit"
                className="w-full sm:flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>
                  {lang === 'ur'
                    ? 'پریویو ڈیمو ایڈمن سیشن شروع کریں'
                    : 'Sign In (Preview Demo Admin Mode)'}
                </span>
              </button>

              <button
                type="button"
                onClick={onExitAdmin}
                className="w-full sm:w-auto px-4 py-3 text-xs font-medium text-[#4A554E] hover:text-[#18241B] bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
              >
                {lang === 'ur' ? 'واپس مارکیٹ پلیس' : 'Back to App'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  const handleExportLogs = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(activityLogs, null, 2));
    const anchor = document.createElement('a');
    anchor.setAttribute('href', dataStr);
    anchor.setAttribute('download', 'desi-beej-admin-activity-logs.json');
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
  };

  const handleSettingsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(settingsDraft);
    setSettingsSavedMsg(true);
    setTimeout(() => setSettingsSavedMsg(false), 2500);
  };

  const navItems: { id: AdminTab; labelEn: string; labelUr: string; icon: any; count?: number }[] = [
    {
      id: 'overview',
      labelEn: 'Overview Dashboard',
      labelUr: 'ڈیش بورڈ خلاصہ',
      icon: ShieldCheck,
    },
    {
      id: 'users',
      labelEn: 'Users & Accounts',
      labelUr: 'صارفین (Block/Unblock)',
      icon: Users,
      count: totalUsers,
    },
    {
      id: 'listings',
      labelEn: 'Seed Moderation',
      labelUr: 'بیج اشتہارات کی منظوری',
      icon: Sprout,
      count: totalListings,
    },
    {
      id: 'fraud',
      labelEn: 'Fake Listing Scanner',
      labelUr: 'جعلی اشتہارات کی شناخت',
      icon: AlertTriangle,
      count: suspectedFakeList.length,
    },
    {
      id: 'reports',
      labelEn: 'User Complaints',
      labelUr: 'صارفین کی شکایات',
      icon: Flag,
      count: openReportsCount,
    },
    {
      id: 'settings',
      labelEn: 'Platform Settings',
      labelUr: 'ایپ سیٹنگز اور زبان',
      icon: Settings,
    },
    {
      id: 'logs',
      labelEn: 'Activity Audit Log',
      labelUr: 'ایڈمن ایکٹیویٹی لاگ',
      icon: Activity,
      count: activityLogs.length,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Admin Bar */}
      <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2 text-xs text-[#14532D] font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>
              {lang === 'ur'
                ? 'دیسی بیج ایکسچینج · ایڈمنسٹریٹر کنٹرول پینل'
                : 'DESI BEEJ EXCHANGE · ADMINISTRATOR CONSOLE'}
            </span>
            <span>·</span>
            <span className="font-mono-num text-[#5C6660]">
              {adminSession.email}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-[#18241B]">
            {lang === 'ur'
              ? 'ایڈمن پینل اور پلیٹ فارم مینجمنٹ'
              : 'Admin Moderation, Security & Governance Panel'}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          {onChangeLanguage && (
            <div
              className="inline-flex items-center gap-1 bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg p-1"
              role="group"
              aria-label="Admin Panel Language Toggle"
            >
              <Globe className="w-3.5 h-3.5 text-[#14532D] ms-1.5 me-0.5" />
              <button
                type="button"
                onClick={() => onChangeLanguage('en')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'en'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => onChangeLanguage('ur')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'ur'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                اردو
              </button>
            </div>
          )}
          <button
            type="button"
            onClick={onExitAdmin}
            className="px-3.5 py-2 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg whitespace-nowrap"
          >
            {lang === 'ur' ? 'مارکیٹ پلیس دیکھیں' : 'View Public App'}
          </button>
          <button
            type="button"
            onClick={onAdminLogout}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded-lg transition-colors whitespace-nowrap"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{lang === 'ur' ? 'ایڈمن لاگ آؤٹ' : 'Admin Logout'}</span>
          </button>
        </div>
      </div>

      {/* Explicit Demo Mode vs Firebase Production Security Disclosure */}
      <div className="bg-[#F3EFE6] border border-[#E6E2D8] rounded-xl p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#14532D] shrink-0 mt-0.5" />
        <div className="text-xs text-[#36403A] leading-relaxed">
          <span className="font-bold text-[#18241B]">
            {lang === 'ur'
              ? 'ڈیمو موڈ بمقابلہ فائر بیس ڈیٹا بیس سکیورٹی اسٹیٹس: '
              : 'Demo Preview Mode vs. Firebase Database Security Status: '}
          </span>
          {lang === 'ur'
            ? 'چونکہ اس وقت فائر بیس کنفیگریشن (.env میں VITE_FIREBASE_PROJECT_ID) منسلک نہیں ہے، اس لیے تمام ایڈمن ایکشنز (صارف کو بلاک/ان بلاک کرنا، بیج منظور یا مسترد کرنا، جعلی اشتہارات ہٹانا، شکایات کا فیصلہ اور ایکٹیویٹی لاگ) آپ کے براؤزر میں پریویو ڈیمو موڈ کے تحت فوری طور پر کام کر رہے ہیں۔ پروڈکشن کے لیے "/firestore.rules" فائل تیار کر دی گئی ہے جو صرف تصدیق شدہ ایڈمن کو ڈیٹا بیس میں تبدیلی کی اجازت دیتی ہے۔'
            : 'Because Firebase configuration is not connected yet, all Admin actions (blocking/unblocking users, approving/rejecting/deleting seed listings, fake listing enforcement, complaint resolution, settings, and activity logs) operate locally in Preview Demo Mode and immediately update the live app preview. Production database security rules are ready in /firestore.rules.'}
        </div>
      </div>

      {/* Workspace Grid: Left Sidebar Navigation + Main Viewport */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Sidebar Navigation (3 cols) */}
        <aside className="lg:col-span-3 bg-white border border-[#E6E2D8] rounded-xl p-2.5 flex lg:flex-col gap-1 overflow-x-auto">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center justify-between gap-2.5 px-3.5 py-2.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:bg-[#FAF8F5] hover:text-[#18241B]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{lang === 'ur' ? item.labelUr : item.labelEn}</span>
                </div>
                {item.count !== undefined && (
                  <span
                    className={`font-mono-num text-[11px] ${
                      isActive ? 'text-white/90' : 'text-[#5C6660]'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </aside>

        {/* Main Admin Content Area (9 cols) */}
        <div className="lg:col-span-9 space-y-6">
          {/* ===============================================================
              TAB 1: OVERVIEW DASHBOARD METRICS
              =============================================================== */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Primary 4 Required KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur' ? 'کل صارفین (کسان)' : 'Total Registered Users'}
                  </p>
                  <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
                    {totalUsers}
                  </p>
                  <p className="text-[11px] text-[#5C6660] mt-1 font-mono-num">
                    {totalUsers - blockedUsersCount}{' '}
                    {lang === 'ur' ? 'فعال' : 'Active'} · {blockedUsersCount}{' '}
                    {lang === 'ur' ? 'بلاک' : 'Blocked'}
                  </p>
                </div>

                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur' ? 'کل بیج اشتہارات' : 'Total Seed Listings'}
                  </p>
                  <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
                    {totalListings}
                  </p>
                  <p className="text-[11px] text-[#14532D] mt-1 font-mono-num">
                    {pendingListingsCount}{' '}
                    {lang === 'ur' ? 'منظوری کے منتظر' : 'Pending Approval'}
                  </p>
                </div>

                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur' ? 'فروخت کے اشتہارات (PKR)' : 'Sale Listings (PKR)'}
                  </p>
                  <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
                    {saleListingsCount}
                  </p>
                  <p className="text-[11px] text-[#5C6660] mt-1">
                    {lang === 'ur' ? 'نقد اور مشترکہ فروخت' : 'Direct & hybrid sale'}
                  </p>
                </div>

                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur'
                      ? 'تبادلے (بارٹر) کے اشتہارات'
                      : 'Seed Exchange Listings'}
                  </p>
                  <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
                    {exchangeListingsCount}
                  </p>
                  <p className="text-[11px] text-[#5C6660] mt-1">
                    {lang === 'ur' ? 'بیج کے بدلے بیج' : 'Farmer-to-farmer barter'}
                  </p>
                </div>
              </div>

              {/* Actionable Moderation Queues Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-bold text-[#18241B]">
                        {lang === 'ur'
                          ? 'جعلی اور مشکوک اشتہارات کا الرٹ'
                          : 'Suspected Fake Listings Alert'}
                      </h2>
                      <span className="text-sm font-bold text-[#991B1B] font-mono-num">
                        {suspectedFakeList.length}
                      </span>
                    </div>
                    <p className="text-xs text-[#4A554E] mt-1 leading-relaxed">
                      {lang === 'ur'
                        ? 'خودکار اسکینر نے غیر فطری کم قیمت اور ایڈوانس رقم مانگنے والے مشکوک اشتہارات کی نشاندہی کی ہے۔'
                        : 'Automated scanner detected listings with abnormal pricing or advance-payment scam indicators.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('fraud')}
                    className="self-start px-4 py-2 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                  >
                    {lang === 'ur'
                      ? 'مشکوک اشتہارات کا معائنہ کریں ←'
                      : 'Inspect Flagged Listings →'}
                  </button>
                </div>

                <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 flex flex-col justify-between space-y-4">
                  <div>
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-bold text-[#18241B]">
                        {lang === 'ur'
                          ? 'صارفین کی کھلی شکایات (Reports)'
                          : 'Open Farmer Complaints'}
                      </h2>
                      <span className="text-sm font-bold text-[#B45309] font-mono-num">
                        {openReportsCount}
                      </span>
                    </div>
                    <p className="text-xs text-[#4A554E] mt-1 leading-relaxed">
                      {lang === 'ur'
                        ? 'کسانوں کی طرف سے درج کرائی گئی شکایات پر فوری کارروائی کریں۔'
                        : 'Review community-submitted seed quality and seller behavior reports.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveTab('reports')}
                    className="self-start px-4 py-2 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] rounded-lg"
                  >
                    {lang === 'ur' ? 'شکایات دیکھیں ←' : 'Review Complaints →'}
                  </button>
                </div>
              </div>

              {/* Recent Admin Activity Preview */}
              <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-base font-bold text-[#18241B]">
                    {lang === 'ur'
                      ? 'حالیہ ایڈمن کارروائیاں (Activity Log)'
                      : 'Recent Admin Activity Log'}
                  </h2>
                  <button
                    type="button"
                    onClick={() => setActiveTab('logs')}
                    className="text-xs font-semibold text-[#14532D] hover:underline"
                  >
                    {lang === 'ur' ? 'مکمل ریکارڈ دیکھیں' : 'View Full Log'}
                  </button>
                </div>
                <div className="divide-y divide-[#F0EDE6]">
                  {activityLogs.slice(0, 4).map((log) => (
                    <div
                      key={log.id}
                      className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <span className="text-[#18241B]">
                        {lang === 'ur' ? log.actionUr : log.actionEn}
                      </span>
                      <span className="text-[#5C6660] font-mono-num shrink-0">
                        {log.timestamp}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ===============================================================
              TAB 2: USERS MANAGEMENT (Block / Unblock Accounts)
              =============================================================== */}
          {activeTab === 'users' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#18241B]">
                    {lang === 'ur'
                      ? 'تمام صارفین اور کسان اکاؤنٹس کا انتظام'
                      : 'All Registered Farmers & User Accounts'}
                  </h2>
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur'
                      ? 'کسی بھی مشکوک صارف کو بلاک کرنے سے اس کے اشتہارات عوامی کیٹلاگ سے ہٹ جاتے ہیں۔'
                      : 'Blocking a user immediately hides their seed listings from the public marketplace.'}
                  </p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-[#5C6660] absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
                  <input
                    type="search"
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder={
                      lang === 'ur'
                        ? 'نام، شہر یا فون نمبر تلاش کریں...'
                        : 'Search name, city, or phone...'
                    }
                    className="w-full ps-9 pe-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-start border-collapse">
                  <thead>
                    <tr className="border-b border-[#E6E2D8] bg-[#FAF8F5] text-xs font-semibold text-[#4A554E]">
                      <th className="py-3 px-4 text-start">
                        {lang === 'ur' ? 'صارف / فارم کا نام' : 'Farmer & Farm Name'}
                      </th>
                      <th className="py-3 px-4 text-start">
                        {lang === 'ur' ? 'شہر · فون نمبر' : 'City · Phone'}
                      </th>
                      <th className="py-3 px-4 text-start">
                        {lang === 'ur' ? 'اکاؤنٹ اسٹیٹس' : 'Account Status'}
                      </th>
                      <th className="py-3 px-4 text-end">
                        {lang === 'ur' ? 'کارروائی' : 'Action'}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F0EDE6] text-sm">
                    {filteredUsers.map((user) => {
                      const isBlocked = user.status === 'blocked';
                      const userListingsCount = allListings.filter(
                        (l) => l.sellerId === user.id
                      ).length;

                      return (
                        <tr
                          key={user.id}
                          className="hover:bg-[#FAF8F5] transition-colors"
                        >
                          <td className="py-3.5 px-4">
                            <p className="font-semibold text-[#18241B]">
                              {lang === 'ur' ? user.nameUr : user.nameEn}
                            </p>
                            <p className="text-xs text-[#5C6660]">
                              {lang === 'ur' ? user.farmNameUr : user.farmNameEn} ·{' '}
                              <span className="font-mono-num">
                                {userListingsCount}{' '}
                                {lang === 'ur' ? 'اشتہارات' : 'listings'}
                              </span>
                            </p>
                          </td>
                          <td className="py-3.5 px-4 text-xs text-[#4A554E]">
                            <span>{user.city}</span>
                            <span className="mx-1.5">·</span>
                            <span className="font-mono-num">{user.phone}</span>
                          </td>
                          <td className="py-3.5 px-4 text-xs font-semibold">
                            {isBlocked ? (
                              <span className="text-[#991B1B]">
                                {lang === 'ur' ? 'بلاک شدہ (Blocked)' : 'Blocked'}
                              </span>
                            ) : (
                              <span className="text-[#14532D]">
                                {lang === 'ur' ? 'فعال (Active)' : 'Active'}
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-end">
                            <button
                              type="button"
                              onClick={() => onToggleBlockUser(user.id)}
                              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                                isBlocked
                                  ? 'bg-[#EAF2EC] text-[#14532D] hover:bg-[#DCE9E0]'
                                  : 'bg-[#FEF2F2] text-[#991B1B] hover:bg-[#FEE2E2]'
                              }`}
                            >
                              {isBlocked ? (
                                <>
                                  <Unlock className="w-3.5 h-3.5" />
                                  <span>
                                    {lang === 'ur' ? 'ان بلاک کریں' : 'Unblock User'}
                                  </span>
                                </>
                              ) : (
                                <>
                                  <Ban className="w-3.5 h-3.5" />
                                  <span>
                                    {lang === 'ur' ? 'بلاک کریں' : 'Block User'}
                                  </span>
                                </>
                              )}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ===============================================================
              TAB 3: SEED LISTINGS MODERATION (Approve, Reject, Delete)
              =============================================================== */}
          {activeTab === 'listings' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#18241B]">
                    {lang === 'ur'
                      ? 'تمام بیجوں کے اشتہارات کی منظوری اور نگرانی'
                      : 'All Seed Listings Moderation Queue'}
                  </h2>
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur'
                      ? 'اشتہارات کو دیکھیں، منظور کریں، مسترد کریں یا مستقل طور پر حذف کریں۔'
                      : 'Inspect, approve, reject, or permanently delete any seed listing.'}
                  </p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 text-[#5C6660] absolute top-1/2 -translate-y-1/2 start-3 pointer-events-none" />
                  <input
                    type="search"
                    value={listingSearch}
                    onChange={(e) => setListingSearch(e.target.value)}
                    placeholder={
                      lang === 'ur'
                        ? 'بیج یا کسان کا نام تلاش کریں...'
                        : 'Search seed or seller...'
                    }
                    className="w-full ps-9 pe-3 py-2 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                  />
                </div>
              </div>

              {/* Filter Buttons */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                {(['all', 'approved', 'pending', 'rejected'] as const).map(
                  (st) => {
                    const active = listingFilter === st;
                    const labels = {
                      all: lang === 'ur' ? 'تمام اشتہارات' : 'All Listings',
                      approved: lang === 'ur' ? 'منظور شدہ (Approved)' : 'Approved',
                      pending: lang === 'ur' ? 'زیرِ التواء (Pending)' : 'Pending',
                      rejected: lang === 'ur' ? 'مسترد شدہ (Rejected)' : 'Rejected',
                    };
                    return (
                      <button
                        key={st}
                        type="button"
                        onClick={() => setListingFilter(st)}
                        className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                          active
                            ? 'bg-[#14532D] text-white'
                            : 'bg-[#FAF8F5] text-[#4A554E] border border-[#E6E2D8]'
                        }`}
                      >
                        {labels[st]}
                      </button>
                    );
                  }
                )}
              </div>

              <div className="divide-y divide-[#F0EDE6]">
                {filteredListings.map((item) => {
                  const status = item.approvalStatus || 'approved';
                  const title = lang === 'ur' ? item.nameUr || item.nameEn : item.nameEn;

                  return (
                    <div
                      key={item.id}
                      className="py-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="w-16 h-12 rounded-lg overflow-hidden bg-[#EFECE6] shrink-0">
                          <SeedImage
                            src={item.image}
                            alt={title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                            <span
                              className={`font-bold ${
                                status === 'approved'
                                  ? 'text-[#14532D]'
                                  : status === 'rejected'
                                    ? 'text-[#991B1B]'
                                    : 'text-[#B45309]'
                              }`}
                            >
                              {status === 'approved'
                                ? lang === 'ur'
                                  ? 'منظور شدہ'
                                  : 'Approved'
                                : status === 'rejected'
                                  ? lang === 'ur'
                                    ? 'مسترد شدہ'
                                    : 'Rejected'
                                  : lang === 'ur'
                                    ? 'منظوری کا منتظر'
                                    : 'Pending Approval'}
                            </span>
                            <span>·</span>
                            <span>{CATEGORY_LABELS[item.category][lang]}</span>
                            <span>·</span>
                            <span>{EXCHANGE_LABELS[item.exchangeType][lang]}</span>
                            <span>·</span>
                            <span className="font-mono-num font-semibold text-[#18241B]">
                              {formatPKR(item.pricePKR, lang)}
                            </span>
                          </div>

                          <h3 className="text-sm font-bold text-[#18241B]">
                            {title}
                          </h3>

                          <p className="text-xs text-[#4A554E]">
                            {lang === 'ur' ? item.sellerNameUr : item.sellerNameEn} ·{' '}
                            {item.city} ·{' '}
                            <span className="font-mono-num">{item.sellerPhone}</span>
                          </p>
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => onInspectSeed(item)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{lang === 'ur' ? 'دیکھیں' : 'Inspect'}</span>
                        </button>

                        {status !== 'approved' && (
                          <button
                            type="button"
                            onClick={() => onUpdateListingApproval(item.id, 'approved')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{lang === 'ur' ? 'منظور کریں' : 'Approve'}</span>
                          </button>
                        )}

                        {status !== 'rejected' && (
                          <button
                            type="button"
                            onClick={() => onUpdateListingApproval(item.id, 'rejected')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#B45309] bg-[#FEF3C7] hover:bg-[#FDE68A] rounded-lg"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>{lang === 'ur' ? 'مسترد کریں' : 'Reject'}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onDeleteListing(item.id)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#991B1B] bg-[#FEF2F2] hover:bg-[#FEE2E2] rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{lang === 'ur' ? 'حذف کریں' : 'Delete'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ===============================================================
              TAB 4: FAKE LISTING DETECTION & ACTION
              =============================================================== */}
          {activeTab === 'fraud' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-5">
              <div>
                <h2 className="text-lg font-bold text-[#18241B]">
                  {lang === 'ur'
                    ? 'جعلی اور مشکوک اشتہارات کی شناخت اور کارروائی'
                    : 'Automated Fake Listing Detection & Enforcement'}
                </h2>
                <p className="text-xs text-[#5C6660] mt-1">
                  {lang === 'ur'
                    ? 'سسٹم قیمتوں کے غیر معمولی فرق، ایڈوانس رقم کے مطالبے اور صارفین کی شکایات کی بنیاد پر مشکوک اشتہارات کی نشاندہی کرتا ہے۔'
                    : 'Analyzes price anomalies, advance-payment scam keywords, GMO/hybrid mislabeling, and farmer reports.'}
                </p>
              </div>

              {suspectedFakeList.length === 0 ? (
                <div className="p-8 text-center bg-[#FAF8F5] rounded-xl border border-[#E6E2D8]">
                  <p className="text-sm font-semibold text-[#14532D]">
                    {lang === 'ur'
                      ? 'اس وقت کوئی مشکوک یا جعلی اشتہار موجود نہیں ہے۔'
                      : 'No suspected fake listings detected right now.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {suspectedFakeList.map(({ listing, assessment }) => {
                    const title =
                      lang === 'ur' ? listing.nameUr || listing.nameEn : listing.nameEn;
                    const reasons =
                      lang === 'ur' ? assessment.reasonsUr : assessment.reasonsEn;

                    return (
                      <div
                        key={listing.id}
                        className="p-5 rounded-xl border border-[#FECACA] bg-[#FEF2F2]/50 space-y-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2 text-xs font-bold text-[#991B1B]">
                            <AlertTriangle className="w-4 h-4" />
                            <span>
                              {lang === 'ur'
                                ? `مشکوک/جعلی الرٹ · رسک لیول: ${assessment.riskScore}%`
                                : `SUSPECTED FAKE LISTING · RISK SCORE: ${assessment.riskScore}%`}
                            </span>
                          </div>
                          <span className="text-xs font-mono-num text-[#5C6660]">
                            ID: {listing.id} · {formatPKR(listing.pricePKR, lang)}
                          </span>
                        </div>

                        <div>
                          <h3 className="text-base font-bold text-[#18241B]">
                            {title}
                          </h3>
                          <p className="text-xs text-[#4A554E] mt-0.5">
                            {lang === 'ur' ? 'فروخت کنندہ: ' : 'Seller: '}
                            {lang === 'ur'
                              ? listing.sellerNameUr
                              : listing.sellerNameEn}{' '}
                            ({listing.city} · {listing.sellerPhone})
                          </p>
                        </div>

                        <ul className="space-y-1 text-xs text-[#991B1B] list-disc ps-5">
                          {reasons.map((r, i) => (
                            <li key={i}>{r}</li>
                          ))}
                        </ul>

                        <div className="pt-3 border-t border-[#FECACA] flex flex-wrap items-center gap-2.5">
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateListingFakeFlag(
                                listing.id,
                                true,
                                'Confirmed fake by Admin',
                                'ایڈمن کی جانب سے جعلی قرار دے کر مسترد کیا گیا'
                              )
                            }
                            className="px-3.5 py-2 text-xs font-semibold text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'جعلی قرار دے کر مسترد کریں'
                              : 'Confirm Fake & Reject Listing'}
                          </button>

                          <button
                            type="button"
                            onClick={() => onToggleBlockUser(listing.sellerId)}
                            className="px-3.5 py-2 text-xs font-semibold text-[#991B1B] bg-white border border-[#FECACA] hover:bg-[#FEE2E2] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'فروخت کنندہ کا اکاؤنٹ بلاک کریں'
                              : 'Block Seller Account'}
                          </button>

                          <button
                            type="button"
                            onClick={() => onDeleteListing(listing.id)}
                            className="px-3.5 py-2 text-xs font-semibold text-[#991B1B] bg-white border border-[#FECACA] hover:bg-[#FEE2E2] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'اشتہار مستقل حذف کریں'
                              : 'Delete Permanently'}
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateListingFakeFlag(listing.id, false)
                            }
                            className="px-3.5 py-2 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'تصدیق کر کے بحال کریں (Clear Flag)'
                              : 'Verify & Clear Fake Flag'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ===============================================================
              TAB 5: USER COMPLAINTS & REPORT SYSTEM
              =============================================================== */}
          {activeTab === 'reports' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#18241B]">
                    {lang === 'ur'
                      ? 'صارفین کی شکایات اور رپورٹ سسٹم'
                      : 'Farmer Complaints & Abuse Reports'}
                  </h2>
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur'
                      ? 'کسان کسی بھی بیج کے صفحے پر "شکایت درج کریں" کے بٹن سے رپورٹ بھیج سکتے ہیں۔'
                      : 'Farmers can submit reports from any seed detail page; manage and resolve them here.'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {(['all', 'open', 'resolved'] as const).map((rf) => (
                    <button
                      key={rf}
                      type="button"
                      onClick={() => setReportFilter(rf)}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-lg ${
                        reportFilter === rf
                          ? 'bg-[#14532D] text-white'
                          : 'bg-[#FAF8F5] text-[#4A554E] border border-[#E6E2D8]'
                      }`}
                    >
                      {rf === 'all'
                        ? lang === 'ur'
                          ? 'تمام شکایات'
                          : 'All'
                        : rf === 'open'
                          ? lang === 'ur'
                            ? 'کھلی شکایات'
                            : 'Open'
                          : lang === 'ur'
                            ? 'حل شدہ'
                            : 'Resolved'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                {filteredReports.map((rep) => {
                  const isOpen =
                    rep.status === 'open' || rep.status === 'investigating';
                  return (
                    <div
                      key={rep.id}
                      className="p-5 rounded-xl border border-[#E6E2D8] bg-[#FAF8F5] space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                        <span
                          className={`font-bold ${
                            isOpen ? 'text-[#B45309]' : 'text-[#14532D]'
                          }`}
                        >
                          {isOpen
                            ? lang === 'ur'
                              ? 'کھلی شکایت (Open Report)'
                              : 'Open Report'
                            : lang === 'ur'
                              ? 'حل شدہ (Resolved)'
                              : 'Resolved'}
                        </span>
                        <span className="font-mono-num text-[#5C6660]">
                          {rep.createdAt}
                        </span>
                      </div>

                      <div>
                        <h3 className="text-sm font-bold text-[#18241B]">
                          {lang === 'ur' ? 'رپورٹ شدہ اشتہار: ' : 'Reported Seed: '}
                          {lang === 'ur'
                            ? rep.targetSeedNameUr
                            : rep.targetSeedNameEn}
                        </h3>
                        <p className="text-xs text-[#5C6660] mt-0.5">
                          {lang === 'ur' ? 'شکایت کنندہ: ' : 'Reporter: '}
                          {rep.reporterName} ({rep.reporterCity} ·{' '}
                          <span className="font-mono-num">{rep.reporterPhone}</span>)
                        </p>
                      </div>

                      <p className="text-xs text-[#18241B] bg-white p-3 rounded-lg border border-[#E6E2D8] leading-relaxed">
                        {lang === 'ur'
                          ? rep.detailsUr || rep.detailsEn
                          : rep.detailsEn}
                      </p>

                      {isOpen && (
                        <div className="flex flex-wrap items-center gap-2 pt-2">
                          <button
                            type="button"
                            onClick={() => {
                              onUpdateListingApproval(
                                rep.targetSeedId,
                                'rejected'
                              );
                              onUpdateReportStatus(
                                rep.id,
                                'resolved',
                                'Listing rejected by Admin'
                              );
                            }}
                            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#991B1B] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'اشتہار مسترد کریں اور شکایت حل کریں'
                              : 'Reject Listing & Resolve Report'}
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              onToggleBlockUser(rep.targetSellerId);
                              onUpdateReportStatus(
                                rep.id,
                                'resolved',
                                'Seller blocked by Admin'
                              );
                            }}
                            className="px-3.5 py-1.5 text-xs font-semibold text-[#991B1B] bg-[#FEF2F2] border border-[#FECACA] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'فروخت کنندہ کو بلاک کریں'
                              : 'Block Reported Seller'}
                          </button>

                          <button
                            type="button"
                            onClick={() =>
                              onUpdateReportStatus(
                                rep.id,
                                'resolved',
                                'Reviewed and resolved'
                              )
                            }
                            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                          >
                            {lang === 'ur'
                              ? 'شکایت حل شدہ نشان زد کریں'
                              : 'Mark Resolved'}
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ===============================================================
              TAB 6: APP LANGUAGE, BASIC INFO & PLATFORM SETTINGS
              =============================================================== */}
          {activeTab === 'settings' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 space-y-5">
              <div>
                <h2 className="text-lg font-bold text-[#18241B]">
                  {lang === 'ur'
                    ? 'ایپ کی زبان، بنیادی معلومات اور دیگر سیٹنگز'
                    : 'App Language, Basic Information & Platform Settings'}
                </h2>
                <p className="text-xs text-[#5C6660] mt-1">
                  {lang === 'ur'
                    ? 'یہاں کی گئی تبدیلیاں فوری طور پر پوری ایپ پر لاگو ہو جائیں گی۔'
                    : 'Changes saved here immediately update the live application.'}
                </p>
              </div>

              {settingsSavedMsg && (
                <div className="p-3 rounded-lg bg-[#EAF2EC] text-[#14532D] text-xs font-semibold">
                  {lang === 'ur'
                    ? 'سیٹنگز کامیابی کے ساتھ محفوظ ہو گئیں اور ایکٹیویٹی لاگ میں درج کر لی گئیں!'
                    : 'Settings saved and recorded in the Admin Activity Log!'}
                </div>
              )}

              <form onSubmit={handleSettingsSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur' ? 'ایپ کا نام (انگریزی)' : 'App Name (English)'}
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.appNameEn}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          appNameEn: e.target.value,
                        })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur' ? 'ایپ کا نام (اردو)' : 'App Name (Urdu)'}
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.appNameUr}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          appNameUr: e.target.value,
                        })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur'
                        ? 'ایپ کی بنیادی زبان (Default Language)'
                        : 'Default App Language'}
                    </label>
                    <select
                      value={settingsDraft.defaultLanguage}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          defaultLanguage: e.target.value as Language,
                        })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                    >
                      <option value="ur">اردو (RTL)</option>
                      <option value="en">English (LTR)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur'
                        ? 'کسان ہیلپ لائن نمبر'
                        : 'Farmer Support Helpline'}
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.helplinePhone}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          helplinePhone: e.target.value,
                        })
                      }
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg font-mono-num"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur'
                        ? 'اعلان بینر (انگریزی — اختیاری)'
                        : 'Announcement Banner (English — Optional)'}
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.announcementBannerEn}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          announcementBannerEn: e.target.value,
                        })
                      }
                      placeholder="e.g., Rabi Wheat Seed Exchange Mela Open!"
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {lang === 'ur'
                        ? 'اعلان بینر (اردو — اختیاری)'
                        : 'Announcement Banner (Urdu — Optional)'}
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.announcementBannerUr}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          announcementBannerUr: e.target.value,
                        })
                      }
                      placeholder="مثلاً: ربیع گندم کے دیسی بیجوں کے تبادلے کا آغاز ہو چکا ہے!"
                      className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                    />
                  </div>
                </div>

                <div className="pt-3 border-t border-[#E6E2D8] space-y-3">
                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settingsDraft.requireListingApproval}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          requireListingApproval: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-[#14532D]"
                    />
                    <span className="text-sm text-[#18241B]">
                      {lang === 'ur'
                        ? 'نئے شامل کیے جانے والے بیج اشتہارات کے لیے ایڈمن منظوری لازمی قرار دیں'
                        : 'Require Admin Approval before new seed listings appear publicly'}
                    </span>
                  </label>

                  <label className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settingsDraft.enableBarterExchange}
                      onChange={(e) =>
                        setSettingsDraft({
                          ...settingsDraft,
                          enableBarterExchange: e.target.checked,
                        })
                      }
                      className="w-4 h-4 accent-[#14532D]"
                    />
                    <span className="text-sm text-[#18241B]">
                      {lang === 'ur'
                        ? 'کسان سے کسان بیج کے تبادلے (Barter Exchange) کی سہولت فعال رکھیں'
                        : 'Enable Farmer-to-Farmer Seed Barter Exchange mode'}
                    </span>
                  </label>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg"
                  >
                    {lang === 'ur' ? 'سیٹنگز محفوظ کریں' : 'Save Platform Settings'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* ===============================================================
              TAB 7: ADMIN ACTIVITY LOG (Audit Trail)
              =============================================================== */}
          {activeTab === 'logs' && (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-[#18241B]">
                    {lang === 'ur'
                      ? 'ایڈمن ایکٹیویٹی لاگ (تمام کارروائیوں کا ریکارڈ)'
                      : 'Immutable Admin Activity Audit Log'}
                  </h2>
                  <p className="text-xs text-[#5C6660]">
                    {lang === 'ur'
                      ? 'ہر ایڈمن لاگ ان، بلاک/ان بلاک، اشتہار کی منظوری یا مستردگی اور سیٹنگز کی تبدیلی کا مکمل ریکارڈ۔'
                      : 'Every admin login, user block, seed moderation, fraud removal, and setting update is recorded.'}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2 self-start">
                  {onChangeLanguage && (
                    <div
                      className="inline-flex items-center gap-1 bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg p-1"
                      role="group"
                      aria-label="Activity Log Language Toggle"
                    >
                      <Globe className="w-3.5 h-3.5 text-[#14532D] ms-1.5 me-0.5" />
                      <button
                        type="button"
                        onClick={() => onChangeLanguage('en')}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                          lang === 'en'
                            ? 'bg-[#14532D] text-white'
                            : 'text-[#4A554E] hover:text-[#18241B]'
                        }`}
                      >
                        English
                      </button>
                      <button
                        type="button"
                        onClick={() => onChangeLanguage('ur')}
                        className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                          lang === 'ur'
                            ? 'bg-[#14532D] text-white'
                            : 'text-[#4A554E] hover:text-[#18241B]'
                        }`}
                      >
                        اردو
                      </button>
                    </div>
                  )}
                  <button
                    type="button"
                    onClick={handleExportLogs}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>
                      {lang === 'ur' ? 'لاگ ڈاؤن لوڈ کریں (JSON)' : 'Export Audit Log'}
                    </span>
                  </button>
                </div>
              </div>

              <div className="divide-y divide-[#F0EDE6]">
                {activityLogs.map((log) => {
                  const categoryLabelMap: Record<
                    AdminActivityLog['category'],
                    { en: string; ur: string }
                  > = {
                    auth: { en: 'Authentication', ur: 'تصدیق و لاگ ان' },
                    user: { en: 'User Account', ur: 'صارف اکاؤنٹ' },
                    listing: { en: 'Seed Listing', ur: 'بیج اشتہار' },
                    report: { en: 'Complaint / Report', ur: 'شکایت و رپورٹ' },
                    settings: { en: 'Platform Settings', ur: 'ایپ سیٹنگز' },
                  };
                  const authModeLabel =
                    log.authMode === 'firebase_production'
                      ? lang === 'ur'
                        ? 'فائر بیس پروڈکشن'
                        : 'Firebase Production'
                      : lang === 'ur'
                        ? 'ڈیمو پریویو موڈ'
                        : 'Demo Preview Mode';
                  const catLabel =
                    categoryLabelMap[log.category]?.[lang] || log.category;

                  return (
                    <div
                      key={log.id}
                      className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="space-y-1">
                        <p className="font-semibold text-[#18241B]">
                          {lang === 'ur' ? log.actionUr : log.actionEn}
                        </p>
                        <p className="text-[11px] text-[#6E7872]">
                          {lang === 'ur' ? log.actionEn : log.actionUr}
                        </p>
                        <p className="text-[#5C6660] font-mono-num">
                          {log.adminEmail} · {catLabel} · {authModeLabel}
                        </p>
                      </div>
                      <span className="font-mono-num text-[#5C6660] shrink-0">
                        {log.timestamp}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
