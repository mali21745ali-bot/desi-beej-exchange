import React, { useState } from 'react';
import { X, Upload, Check } from 'lucide-react';
import {
  SeedListing,
  SeedCategory,
  ExchangeType,
  Language,
  StructuredLocation,
} from '../types/seed';
import { CATEGORY_LABELS, EXCHANGE_LABELS, UI_TEXT } from '../i18n/translations';
import { SEED_IMAGE_PRESETS } from '../data/initialSeeds';
import { SeedImage } from './SeedImage';
import { LocationAutocompletePicker } from './LocationAutocompletePicker';
import { locationService } from '../services/locationService';

interface AddSeedModalProps {
  lang: Language;
  initialListing?: SeedListing | null;
  onClose: () => void;
  onSave: (listing: SeedListing) => void;
}

export const AddSeedModal: React.FC<AddSeedModalProps> = ({
  lang,
  initialListing,
  onClose,
  onSave,
}) => {
  const t = UI_TEXT[lang];

  const [nameEn, setNameEn] = useState(initialListing?.nameEn || '');
  const [nameUr, setNameUr] = useState(initialListing?.nameUr || '');
  const [category, setCategory] = useState<SeedCategory>(initialListing?.category || 'wheat');
  const [pricePKR, setPricePKR] = useState<string>(
    initialListing ? String(initialListing.pricePKR) : '3500'
  );
  const [quantityEn, setQuantityEn] = useState(initialListing?.quantityEn || '40 kg (1 Maund Bag)');
  const [availableStockEn, setAvailableStockEn] = useState(
    initialListing?.availableStockEn || '20 Maunds Available'
  );
  const [structuredLocation, setStructuredLocation] = useState<StructuredLocation>(() => {
    if (initialListing) {
      return locationService.resolveSeedStructuredLocation(initialListing, lang);
    }
    return {
      country: '',
      state: '',
      city: '',
      area: '',
      address: '',
      source: 'manual',
    };
  });
  const [exchangeType, setExchangeType] = useState<ExchangeType>(
    initialListing?.exchangeType || 'both'
  );
  const [exchangeNotesEn, setExchangeNotesEn] = useState(
    initialListing?.exchangeNotesEn ||
      'Open to direct cash sale or seed-for-seed barter with local farmers.'
  );
  const [sowingSeasonEn, setSowingSeasonEn] = useState(
    initialListing?.sowingSeasonEn || 'Rabi (November – December)'
  );
  const [germinationRate, setGerminationRate] = useState<string>(
    initialListing ? String(initialListing.germinationRate) : '92'
  );
  const [descriptionEn, setDescriptionEn] = useState(initialListing?.descriptionEn || '');
  const [sellerNameEn, setSellerNameEn] = useState(
    initialListing?.sellerNameEn || 'Malik Allah Yar Tiwana'
  );
  const [sellerFarmEn, setSellerFarmEn] = useState(
    initialListing?.sellerFarmEn || 'Thal Desi Seed Farm'
  );
  const [sellerPhone, setSellerPhone] = useState(initialListing?.sellerPhone || '0300-7654321');
  const [selectedImage, setSelectedImage] = useState(
    initialListing?.image || SEED_IMAGE_PRESETS[0].url
  );
  const [customImageUrl, setCustomImageUrl] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedImage(reader.result);
        setCustomImageUrl('');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameEn.trim() || !sellerPhone.trim()) return;

    const finalImage = customImageUrl.trim() ? customImageUrl.trim() : selectedImage;
    const parsedPrice = Math.max(50, Number(pricePKR) || 1500);
    const parsedGerm = Math.min(99, Math.max(50, Number(germinationRate) || 90));

    const cleanLocation: StructuredLocation = {
      country: structuredLocation.country.trim(),
      state: structuredLocation.state.trim(),
      city: structuredLocation.city.trim(),
      area: structuredLocation.area.trim(),
      address: structuredLocation.address.trim(),
      latitude: structuredLocation.latitude,
      longitude: structuredLocation.longitude,
      source: structuredLocation.source || 'manual',
      formattedAddress:
        structuredLocation.formattedAddress ||
        locationService.formatDisplayLocation(structuredLocation),
    };

    const primaryCity =
      cleanLocation.city ||
      cleanLocation.area ||
      cleanLocation.state ||
      cleanLocation.country ||
      'Pakistan';

    const displayAddr =
      cleanLocation.address || locationService.formatDisplayLocation(cleanLocation) || primaryCity;

    const newListing: SeedListing = {
      id: initialListing?.id || `seed-user-${Date.now()}`,
      nameEn: nameEn.trim(),
      nameUr: nameUr.trim() || nameEn.trim(),
      varietyCode:
        initialListing?.varietyCode ||
        `DESI-${category.toUpperCase()}-${Date.now().toString().slice(-3)}`,
      category,
      image: finalImage,
      pricePKR: parsedPrice,
      quantityEn: quantityEn.trim(),
      quantityUr: quantityEn.trim(),
      availableStockEn: availableStockEn.trim(),
      availableStockUr: availableStockEn.trim(),
      city: primaryCity,
      locationEn: displayAddr,
      locationUr: displayAddr,
      structuredLocation: cleanLocation,
      descriptionEn: descriptionEn.trim(),
      descriptionUr: descriptionEn.trim(),
      sellerId: initialListing?.sellerId || 'seller-user',
      sellerNameEn: sellerNameEn.trim(),
      sellerNameUr: sellerNameEn.trim(),
      sellerFarmEn: sellerFarmEn.trim(),
      sellerFarmUr: sellerFarmEn.trim(),
      sellerPhone: sellerPhone.trim(),
      exchangeType,
      exchangeNotesEn: exchangeNotesEn.trim(),
      exchangeNotesUr: exchangeNotesEn.trim(),
      sowingSeasonEn: sowingSeasonEn.trim(),
      sowingSeasonUr: sowingSeasonEn.trim(),
      germinationRate: parsedGerm,
      maturityDays: initialListing?.maturityDays || 120,
      waterRequirementEn: initialListing?.waterRequirementEn || 'Moderate Canal / Rain-fed',
      waterRequirementUr: initialListing?.waterRequirementUr || 'مناسب نہری یا بارانی پانی',
      heirloomGenerationEn:
        initialListing?.heirloomGenerationEn || 'Farm-Saved Open Pollinated Desi',
      heirloomGenerationUr:
        initialListing?.heirloomGenerationUr || 'فارم کا محفوظ شدہ خالص دیسی بیج',
      createdAt: initialListing?.createdAt || new Date().toISOString().split('T')[0],
      isUserCreated: true,
    };

    onSave(newListing);
  };

  const categories: SeedCategory[] = [
    'wheat',
    'rice',
    'cotton',
    'vegetables',
    'fruits',
    'traditional',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 overflow-y-auto">
      <div className="bg-white border border-[#E6E2D8] rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto my-8">
        {/* Modal Header */}
        <div className="sticky top-0 z-10 bg-white px-6 py-4 border-b border-[#E6E2D8] flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#18241B]">
            {initialListing ? t.editModalTitle : t.addModalTitle}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-[#5C6660] hover:text-[#18241B] rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Seed Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.seedNameEnLabel} *
              </label>
              <input
                type="text"
                required
                value={nameEn}
                onChange={(e) => setNameEn(e.target.value)}
                placeholder="e.g., Desi Red Carrot (Lal Gajar) Seed"
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.seedNameUrLabel}
              </label>
              <input
                type="text"
                value={nameUr}
                onChange={(e) => setNameUr(e.target.value)}
                placeholder="دیسی لال گاجر کا خالص بیج"
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
          </div>

          {/* Category & Price & Quantity */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.selectCategoryLabel} *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as SeedCategory)}
                className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {CATEGORY_LABELS[cat][lang]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.pricePKRLabel} *
              </label>
              <input
                type="number"
                min={50}
                required
                value={pricePKR}
                onChange={(e) => setPricePKR(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D] font-mono-num"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.quantityUnitLabel} *
              </label>
              <input
                type="text"
                required
                value={quantityEn}
                onChange={(e) => setQuantityEn(e.target.value)}
                placeholder="40 kg Maund / 5 kg Pack"
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
          </div>

          {/* Global Location Autocomplete, GPS Detection & Structured 5-Field Editor */}
          <LocationAutocompletePicker
            lang={lang}
            value={structuredLocation}
            onChange={setStructuredLocation}
            required={true}
            labelEn="Seed / Farm Location (Global Address Search & GPS)"
            labelUr="بیج یا فارم کا مقام (خودکار سرچ یا GPS لوکیشن)"
          />

          {/* Seed Image Selector & Upload */}
          <div className="space-y-3 pt-2 border-t border-[#E6E2D8]">
            <label className="block text-xs font-semibold text-[#18241B]">
              {t.choosePresetImage}
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
              {SEED_IMAGE_PRESETS.map((preset) => {
                const isSelected = !customImageUrl && selectedImage === preset.url;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => {
                      setSelectedImage(preset.url);
                      setCustomImageUrl('');
                    }}
                    className={`relative rounded-lg overflow-hidden border-2 aspect-4/3 transition-all ${
                      isSelected ? 'border-[#14532D]' : 'border-transparent opacity-75 hover:opacity-100'
                    }`}
                  >
                    <SeedImage
                      src={preset.url}
                      alt={preset.labelEn}
                      className="w-full h-full object-cover"
                    />
                    {isSelected && (
                      <span className="absolute top-1 end-1 w-4 h-4 rounded-full bg-[#14532D] text-white flex items-center justify-center">
                        <Check className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <div>
                <label className="block text-xs text-[#5C6660] mb-1">{t.orCustomImageUrl}</label>
                <input
                  type="url"
                  value={customImageUrl}
                  onChange={(e) => setCustomImageUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-1.5 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#5C6660] mb-1">{t.uploadLocalPhoto}</label>
                <label className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{t.uploadLocalPhoto}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Exchange Mode, Sowing Season & Germination */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[#E6E2D8]">
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.exchangePrefLabel}
              </label>
              <select
                value={exchangeType}
                onChange={(e) => setExchangeType(e.target.value as ExchangeType)}
                className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              >
                {(['both', 'sale', 'exchange'] as ExchangeType[]).map((mode) => (
                  <option key={mode} value={mode}>
                    {EXCHANGE_LABELS[mode][lang]}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.sowingSeasonInputLabel}
              </label>
              <input
                type="text"
                value={sowingSeasonEn}
                onChange={(e) => setSowingSeasonEn(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.germinationInputLabel}
              </label>
              <input
                type="number"
                min={50}
                max={99}
                value={germinationRate}
                onChange={(e) => setGerminationRate(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D] font-mono-num"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-medium text-[#4A554E] mb-1">
              {t.descriptionInputLabel} *
            </label>
            <textarea
              rows={3}
              required
              value={descriptionEn}
              onChange={(e) => setDescriptionEn(e.target.value)}
              placeholder="Describe how many years this desi seed has been saved, water requirements, yield, and resistance..."
              className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
            />
          </div>

          {/* Seller Contact Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[#E6E2D8]">
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.sellerNameInputLabel} *
              </label>
              <input
                type="text"
                required
                value={sellerNameEn}
                onChange={(e) => setSellerNameEn(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.sellerFarmInputLabel}
              </label>
              <input
                type="text"
                value={sellerFarmEn}
                onChange={(e) => setSellerFarmEn(e.target.value)}
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#4A554E] mb-1">
                {t.sellerPhoneInputLabel} *
              </label>
              <input
                type="tel"
                required
                value={sellerPhone}
                onChange={(e) => setSellerPhone(e.target.value)}
                placeholder="0300-1234567"
                className="w-full px-3.5 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D] font-mono-num"
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E6E2D8]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-[#4A554E] hover:text-[#18241B] bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
            >
              {t.cancelBtn}
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors"
            >
              {initialListing ? t.saveChangesBtn : t.publishSeedBtn}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
