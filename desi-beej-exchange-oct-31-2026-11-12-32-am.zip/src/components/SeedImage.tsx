import React, { useState } from 'react';
import { Sprout } from 'lucide-react';

interface SeedImageProps {
  src: string;
  alt: string;
  className?: string;
}

export const SeedImage: React.FC<SeedImageProps> = ({ src, alt, className = '' }) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-[#EFECE6] text-[#14532D] p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Sprout className="w-10 h-10 mb-2 opacity-75" />
        <span className="text-xs font-medium text-[#4A554E] line-clamp-2 max-w-[20ch]">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      loading="lazy"
    />
  );
};
