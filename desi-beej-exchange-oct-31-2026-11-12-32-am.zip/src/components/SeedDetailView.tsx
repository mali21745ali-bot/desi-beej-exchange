import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Heart,
  MessageCircle,
  MessageSquare,
  Copy,
  Check,
  MapPin,
  Phone,
  Send,
  UserCheck,
  Flag,
  X,
} from 'lucide-react';
import {
  SeedListing,
  SellerProfile,
  SeedInquiry,
  Language,
  UserReport,
  ReportReasonType,
  StructuredLocation,
} from '../types/seed';
import {
  CATEGORY_LABELS,
  EXCHANGE_LABELS,
  UI_TEXT,
  formatPKR,
  formatWhatsAppUrl,
} from '../i18n/translations';
import { PAKISTANI_CITIES } from '../data/initialSeeds';
import { SeedImage } from './SeedImage';
import { LocationAutocompletePicker } from './LocationAutocompletePicker';
import { locationService } from '../services/locationService';

interface SeedDetailViewProps {
  seed: SeedListing;
  seller?: SellerProfile;
  lang: Language;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onBack: () => void;
  onOpenSellerProfile: (sellerId: string) => void;
  onStartChatWithSeed: (seed: SeedListing) => void;
  onSubmitInquiry: (inquiry: SeedInquiry) => void;
  onSubmitReport?: (report: UserReport) => void;
}

export const SeedDetailView: React.FC<SeedDetailViewProps> = ({
  seed,
  seller,
  lang,
  isFavorite,
  onToggleFavorite,
  onBack,
  onOpenSellerProfile,
  onStartChatWithSeed,
  onSubmitInquiry,
  onSubmitReport,
}) => {
  const t = UI_TEXT[lang];
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [buyerName, setBuyerName] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [buyerStructuredLocation, setBuyerStructuredLocation] = useState<StructuredLocation>({
    country: '',
    state: '',
    city: '',
    area: '',
    address: '',
    source: 'manual',
  });
  const [inquiryType, setInquiryType] = useState<'buy' | 'exchange'>(
    seed.exchangeType === 'exchange' ? 'exchange' : 'buy'
  );
  const [requestedQuantity, setRequestedQuantity] = useState(seed.quantityEn);
  const [offeredSeed, setOfferedSeed] = useState('');
  const [message, setMessage] = useState('');
  const [inquirySubmitted, setInquirySubmitted] = useState(false);

  // Report Modal State
  const [showReportModal, setShowReportModal] = useState(false);
  const [reporterName, setReporterName] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [reporterCity, setReporterCity] = useState('');
  const [reasonType, setReasonType] = useState<ReportReasonType>('fake_seed');
  const [reportDetails, setReportDetails] = useState('');
  const [reportSubmittedBanner, setReportSubmittedBanner] = useState(false);

  const seedStructuredLoc = locationService.resolveSeedStructuredLocation(seed, lang);
  const title = lang === 'ur' ? seed.nameUr || seed.nameEn : seed.nameEn;
  const secondaryTitle = lang === 'ur' ? seed.nameEn : seed.nameUr;
  const categoryLabel = CATEGORY_LABELS[seed.category][lang];
  const exchangeLabel = EXCHANGE_LABELS[seed.exchangeType][lang];
  const cityObj = PAKISTANI_CITIES.find((c) => c.id.toLowerCase() === seed.city.toLowerCase());
  const cityLabel = cityObj ? (lang === 'ur' ? cityObj.nameUr : cityObj.nameEn) : seed.city;
  const locationText = lang === 'ur' ? seed.locationUr || seed.locationEn : seed.locationEn;
  const descriptionText = lang === 'ur' ? seed.descriptionUr || seed.descriptionEn : seed.descriptionEn;
  const exchangeNotesText =
    lang === 'ur' ? seed.exchangeNotesUr || seed.exchangeNotesEn : seed.exchangeNotesEn;
  const quantityText = lang === 'ur' ? seed.quantityUr || seed.quantityEn : seed.quantityEn;
  const availableStockText =
    lang === 'ur' ? seed.availableStockUr || seed.availableStockEn : seed.availableStockEn;
  const sellerName = lang === 'ur' ? seed.sellerNameUr || seed.sellerNameEn : seed.sellerNameEn;
  const sellerFarm = lang === 'ur' ? seed.sellerFarmUr || seed.sellerFarmEn : seed.sellerFarmEn;

  const buyerCitySummary =
    locationService.formatDisplayLocation(buyerStructuredLocation) ||
    buyerStructuredLocation.address ||
    'Pakistan';

  const directWhatsAppMsg =
    lang === 'ur'
      ? `السلام علیکم ${sellerName} صاحب، میں دیسی بیج ایکسچینج پر آپ کے "${title}" (${cityLabel}) کے اشتہار کے حوالے سے رابطہ کر رہا ہوں۔`
      : `Assalam-o-Alaikum ${seed.sellerNameEn}, I am contacting you from Desi Beej Exchange regarding your "${seed.nameEn}" (${seed.city}) listing.`;

  const whatsappUrl = formatWhatsAppUrl(seed.sellerPhone, directWhatsAppMsg);

  const handleCopyPhone = () => {
    navigator.clipboard?.writeText(seed.sellerPhone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerName.trim() || !buyerPhone.trim()) return;

    const newInquiry: SeedInquiry = {
      id: `inq-${Date.now()}`,
      seedId: seed.id,
      seedNameEn: seed.nameEn,
      seedNameUr: seed.nameUr || seed.nameEn,
      sellerNameEn: seed.sellerNameEn,
      sellerPhone: seed.sellerPhone,
      buyerName: buyerName.trim(),
      buyerPhone: buyerPhone.trim(),
      buyerCity: buyerCitySummary,
      buyerLocation: buyerStructuredLocation,
      inquiryType,
      requestedQuantity: requestedQuantity.trim(),
      offeredSeedForExchange: inquiryType === 'exchange' ? offeredSeed.trim() : undefined,
      message: message.trim(),
      createdAt: new Date().toISOString().split('T')[0],
    };

    onSubmitInquiry(newInquiry);
    setInquirySubmitted(true);
  };

  const handleReportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reporterName.trim() || !reportDetails.trim()) return;

    const newReport: UserReport = {
      id: `rep-${Date.now().toString().slice(-4)}`,
      targetSeedId: seed.id,
      targetSeedNameEn: seed.nameEn,
      targetSeedNameUr: seed.nameUr || seed.nameEn,
      targetSellerId: seed.sellerId,
      targetSellerNameEn: seed.sellerNameEn,
      targetSellerNameUr: seed.sellerNameUr || seed.sellerNameEn,
      reporterName: reporterName.trim(),
      reporterPhone: reporterPhone.trim() || '0300-0000000',
      reporterCity: reporterCity.trim(),
      reasonType,
      detailsEn: reportDetails.trim(),
      detailsUr: reportDetails.trim(),
      status: 'open',
      createdAt: new Date().toLocaleString(),
    };

    onSubmitReport?.(newReport);
    setShowReportModal(false);
    setReportSubmittedBanner(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Bar: Back + Report Button */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#4A554E] hover:text-[#14532D] transition-colors"
        >
          {lang === 'ur' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          <span>{t.backToCatalog}</span>
        </button>

        <button
          type="button"
          onClick={() => setShowReportModal(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#991B1B] bg-[#FEF2F2] hover:bg-[#FEE2E2] rounded-lg transition-colors"
        >
          <Flag className="w-3.5 h-3.5" />
          <span>
            {lang === 'ur'
              ? 'جعلی اشتہار یا شکایت رپورٹ کریں'
              : 'Report Listing / Complaint'}
          </span>
        </button>
      </div>

      {reportSubmittedBanner && (
        <div className="mb-6 p-4 rounded-xl bg-[#EAF2EC] border border-[#14532D]/30 text-xs font-medium text-[#14532D]">
          {lang === 'ur'
            ? 'آپ کی شکایت ایڈمن پینل کے رپورٹ سسٹم میں درج کر لی گئی ہے۔ ایڈمن جلد اس کا جائزہ لے کر کارروائی کرے گا۔'
            : 'Your complaint has been logged in the Admin Panel Report System for immediate review.'}
        </div>
      )}

      {/* 2-Column Contiguous Purchase & Exchange Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Seed Visual & Agronomic Specifications (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          <div className="bg-white border border-[#E6E2D8] rounded-xl overflow-hidden">
            <div className="aspect-4/3 w-full bg-[#F4F1EA]">
              <SeedImage
                src={seed.image}
                alt={title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Detailed Agronomic Description */}
          <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 sm:p-8 space-y-6">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660] mb-2">
                <span className="font-mono-num">{seed.varietyCode}</span>
                <span aria-hidden="true">·</span>
                <span>
                  {lang === 'ur'
                    ? seed.heirloomGenerationUr || seed.heirloomGenerationEn
                    : seed.heirloomGenerationEn}
                </span>
              </div>
              <h2 className="text-xl font-semibold text-[#18241B] mb-3">
                {lang === 'ur' ? 'بیج کی تفصیل اور زرعی خصوصیات' : 'Heirloom Seed Story & Agronomic Traits'}
              </h2>
              <p className="text-base text-[#36403A] leading-relaxed">
                {descriptionText}
              </p>
            </div>

            {/* Tabular Agronomic Specifications */}
            <div className="pt-6 border-t border-[#E6E2D8] grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-[#5C6660]">{t.germinationLabel}</p>
                <p className="text-base font-semibold text-[#18241B] font-mono-num mt-1">
                  {seed.germinationRate}%
                </p>
              </div>
              <div>
                <p className="text-xs text-[#5C6660]">{t.maturityLabel}</p>
                <p className="text-base font-semibold text-[#18241B] font-mono-num mt-1">
                  {seed.maturityDays} {t.daysWord}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#5C6660]">{t.sowingSeasonLabel}</p>
                <p className="text-sm font-semibold text-[#18241B] mt-1">
                  {lang === 'ur' ? seed.sowingSeasonUr || seed.sowingSeasonEn : seed.sowingSeasonEn}
                </p>
              </div>
              <div>
                <p className="text-xs text-[#5C6660]">{t.waterReqLabel}</p>
                <p className="text-sm font-semibold text-[#18241B] mt-1">
                  {lang === 'ur'
                    ? seed.waterRequirementUr || seed.waterRequirementEn
                    : seed.waterRequirementEn}
                </p>
              </div>
            </div>

            {/* Exchange Terms Note */}
            <div className="pt-6 border-t border-[#E6E2D8]">
              <h3 className="text-sm font-semibold text-[#18241B] mb-1.5">
                {t.exchangeTermsHeading}
              </h3>
              <p className="text-sm text-[#4A554E] leading-relaxed">
                {exchangeNotesText}
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Contiguous Purchase, Seller Profile & Inquiry Module (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Primary Purchase / Barter Card */}
          <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 sm:p-7 space-y-6">
            {/* Unboxed Metadata */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#5C6660]">
              <span className="font-semibold text-[#14532D]">{categoryLabel}</span>
              <span aria-hidden="true">·</span>
              <span>{cityLabel}</span>
              <span aria-hidden="true">·</span>
              <span>{exchangeLabel}</span>
            </div>

            <div>
              <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B] leading-tight">
                {title}
              </h1>
              {secondaryTitle && (
                <p className="text-sm text-[#5C6660] mt-1.5">{secondaryTitle}</p>
              )}
            </div>

            {/* Price & Stock Row */}
            <div className="pt-4 border-t border-[#E6E2D8] flex items-baseline justify-between gap-4">
              <div>
                <span className="text-2xl font-bold text-[#18241B] font-mono-num">
                  {formatPKR(seed.pricePKR, lang)}
                </span>
                <span className="text-sm text-[#5C6660] block mt-0.5">
                  {quantityText}
                </span>
              </div>
              <div className="text-end">
                <span className="text-xs text-[#5C6660] block">{t.availableStockLabel}</span>
                <span className="text-sm font-semibold text-[#14532D] font-mono-num">
                  {availableStockText}
                </span>
              </div>
            </div>

            {/* Structured Location Info */}
            <div className="p-3.5 rounded-xl bg-[#FAF8F5] border border-[#E6E2D8] space-y-2">
              <div className="flex items-start gap-2 text-sm font-medium text-[#18241B]">
                <MapPin className="w-4 h-4 text-[#14532D] shrink-0 mt-0.5" />
                <span>{locationText}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-[#E6E2D8] text-[11px] text-[#4A554E]">
                <div>
                  <span className="text-[#5C6660] block">
                    {lang === 'ur' ? 'ملک (Country)' : 'Country'}
                  </span>
                  <span className="font-semibold text-[#18241B]">
                    {seedStructuredLoc.country || 'Pakistan'}
                  </span>
                </div>
                <div>
                  <span className="text-[#5C6660] block">
                    {lang === 'ur' ? 'صوبہ (State)' : 'State / Province'}
                  </span>
                  <span className="font-semibold text-[#18241B]">
                    {seedStructuredLoc.state || '—'}
                  </span>
                </div>
                <div>
                  <span className="text-[#5C6660] block">
                    {lang === 'ur' ? 'شہر (City)' : 'City'}
                  </span>
                  <span className="font-semibold text-[#18241B]">
                    {seedStructuredLoc.city || cityLabel}
                  </span>
                </div>
                <div>
                  <span className="text-[#5C6660] block">
                    {lang === 'ur' ? 'علاقہ (Area)' : 'Area / Village'}
                  </span>
                  <span className="font-semibold text-[#18241B]">
                    {seedStructuredLoc.area || '—'}
                  </span>
                </div>
              </div>
            </div>

            {/* Direct Action Buttons (In-App Chat & Voice Call + WhatsApp) */}
            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={() => onStartChatWithSeed(seed)}
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4" />
                <span>
                  {lang === 'ur'
                    ? 'کسان سے براہ راست چیٹ / وائس کال کریں'
                    : 'Chat & Voice Call with Farmer'}
                </span>
              </button>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" />
                <span>{t.contactViaWhatsApp}</span>
              </a>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors whitespace-nowrap"
                >
                  {copiedPhone ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-[#14532D]" />
                      <span>{t.phoneCopied}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span className="font-mono-num">{seed.sellerPhone}</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => onToggleFavorite(seed.id)}
                  className={`inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                    isFavorite
                      ? 'bg-[#EAF2EC] text-[#14532D] border-[#14532D]'
                      : 'bg-[#FAF8F5] text-[#18241B] border-[#E6E2D8] hover:bg-[#EFECE6]'
                  }`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-current' : ''}`} />
                  <span>{isFavorite ? t.savedInFavorites : t.saveToFavorites}</span>
                </button>
              </div>
            </div>

            {/* Seller Guardian Summary */}
            <div className="pt-5 border-t border-[#E6E2D8] space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#5C6660]">{t.sellerGuardianHeading}</p>
                  <p className="text-base font-semibold text-[#18241B] mt-0.5">{sellerName}</p>
                  <p className="text-xs text-[#4A554E]">{sellerFarm}</p>
                </div>
                <UserCheck className="w-5 h-5 text-[#14532D]" />
              </div>

              {seller && (
                <div className="flex items-center gap-3 text-xs text-[#5C6660] font-mono-num">
                  <span>
                    {seller.experienceYears} {t.yearsExperience}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {seller.totalExchanges} {t.completedExchanges}
                  </span>
                </div>
              )}

              <button
                type="button"
                onClick={() => onOpenSellerProfile(seed.sellerId)}
                className="w-full text-start text-xs font-semibold text-[#14532D] hover:underline pt-1"
              >
                {t.viewFullSellerProfile} →
              </button>
            </div>
          </div>

          {/* Seed Exchange / Purchase Inquiry Log Form */}
          <div className="bg-white border border-[#E6E2D8] rounded-xl p-6 sm:p-7">
            <h3 className="text-base font-semibold text-[#18241B] mb-4">
              {t.sendInquiryHeading}
            </h3>

            {inquirySubmitted ? (
              <div className="p-4 rounded-lg bg-[#EAF2EC] text-[#14532D] space-y-3">
                <p className="text-sm font-medium">{t.inquirySavedBanner}</p>
                <a
                  href={formatWhatsAppUrl(
                    seed.sellerPhone,
                    `${directWhatsAppMsg}\nName: ${buyerName}\nLocation: ${buyerCitySummary}\nMode: ${inquiryType.toUpperCase()}\nQty: ${requestedQuantity}\n${offeredSeed ? `Offered Seed: ${offeredSeed}\n` : ''}${message}`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{t.contactViaWhatsApp}</span>
                </a>
              </div>
            ) : (
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {t.requestType}
                  </label>
                  <div className="grid grid-cols-2 gap-2 p-1 bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg">
                    <button
                      type="button"
                      onClick={() => setInquiryType('buy')}
                      className={`py-2 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate ${
                        inquiryType === 'buy'
                          ? 'bg-[#14532D] text-white'
                          : 'text-[#4A554E] hover:text-[#18241B]'
                      }`}
                    >
                      {t.requestBuy}
                    </button>
                    <button
                      type="button"
                      onClick={() => setInquiryType('exchange')}
                      className={`py-2 px-3 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate ${
                        inquiryType === 'exchange'
                          ? 'bg-[#14532D] text-white'
                          : 'text-[#4A554E] hover:text-[#18241B]'
                      }`}
                    >
                      {t.requestExchange}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {t.yourName} *
                    </label>
                    <input
                      type="text"
                      required
                      value={buyerName}
                      onChange={(e) => setBuyerName(e.target.value)}
                      placeholder={lang === 'ur' ? 'محمد ابراہیم' : 'Muhammad Ibrahim'}
                      className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {t.yourPhone} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={buyerPhone}
                      onChange={(e) => setBuyerPhone(e.target.value)}
                      placeholder="0300-1234567"
                      className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D] font-mono-num"
                    />
                  </div>
                </div>

                {/* Buyer Location Autocomplete & GPS */}
                <LocationAutocompletePicker
                  lang={lang}
                  value={buyerStructuredLocation}
                  onChange={setBuyerStructuredLocation}
                  compact={true}
                  required={true}
                  labelEn="Your Delivery / Exchange Location (Search or GPS)"
                  labelUr="آپ کا پتہ / لوکیشن (سرچ یا GPS)"
                />

                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {t.requestedQty}
                  </label>
                  <input
                    type="text"
                    value={requestedQuantity}
                    onChange={(e) => setRequestedQuantity(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                  />
                </div>

                {inquiryType === 'exchange' && (
                  <div>
                    <label className="block text-xs font-medium text-[#4A554E] mb-1">
                      {t.offeredSeeds} *
                    </label>
                    <input
                      type="text"
                      required
                      value={offeredSeed}
                      onChange={(e) => setOfferedSeed(e.target.value)}
                      placeholder={
                        lang === 'ur'
                          ? 'مثلاً 20 کلو دیسی کالا چنا یا سرسوں'
                          : 'e.g., 20 kg Desi Kala Chana or Sarson seed'
                      }
                      className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {t.additionalNotes}
                  </label>
                  <textarea
                    rows={2}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{t.submitInquiryBtn}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Report / Complaint Submission Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="bg-white border border-[#E6E2D8] rounded-xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E6E2D8] pb-3">
              <h3 className="text-base font-bold text-[#18241B]">
                {lang === 'ur'
                  ? 'اشتہار کے خلاف شکایت درج کریں (Report Listing)'
                  : 'Report Suspicious Listing or Seller Complaint'}
              </h3>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="p-1 text-[#5C6660] hover:text-[#18241B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleReportSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#4A554E] mb-1">
                  {lang === 'ur' ? 'شکایت کی وجہ' : 'Reason for Report'} *
                </label>
                <select
                  value={reasonType}
                  onChange={(e) => setReasonType(e.target.value as ReportReasonType)}
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                >
                  <option value="fake_seed">
                    {lang === 'ur'
                      ? 'جعلی یا غیر معیاری بیج (Fake Seed)'
                      : 'Fake or Adulterated Seed'}
                  </option>
                  <option value="advance_payment_scam">
                    {lang === 'ur'
                      ? 'پیشگی رقم کا دھوکہ (Advance Payment Scam)'
                      : 'Advance Payment Fraud Attempt'}
                  </option>
                  <option value="hybrid_sold_as_desi">
                    {lang === 'ur'
                      ? 'ہائبرڈ بیج کو دیسی بنا کر بیچنا'
                      : 'Hybrid / GMO Sold as Heirloom Desi'}
                  </option>
                  <option value="wrong_phone">
                    {lang === 'ur'
                      ? 'غلط فون نمبر یا رابطہ نہ ہونا'
                      : 'Invalid Phone Number / Unresponsive'}
                  </option>
                  <option value="overpriced">
                    {lang === 'ur' ? 'غیر فطری قیمت' : 'Abnormal / Misleading Pricing'}
                  </option>
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {t.yourName} *
                  </label>
                  <input
                    type="text"
                    required
                    value={reporterName}
                    onChange={(e) => setReporterName(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A554E] mb-1">
                    {t.yourPhone}
                  </label>
                  <input
                    type="tel"
                    value={reporterPhone}
                    onChange={(e) => setReporterPhone(e.target.value)}
                    placeholder="0300-1234567"
                    className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg font-mono-num"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#4A554E] mb-1">
                  {lang === 'ur'
                    ? 'شکایت کی مکمل تفصیل لکھیں'
                    : 'Detailed Description of the Issue'} *
                </label>
                <textarea
                  rows={3}
                  required
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder={
                    lang === 'ur'
                      ? 'براہ کرم بتائیں کہ اس اشتہار میں کیا مسئلہ ہے تاکہ ایڈمن کارروائی کر سکے...'
                      : 'Describe why this listing appears fraudulent or inaccurate...'
                  }
                  className="w-full px-3 py-2 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 text-xs font-medium text-[#4A554E] bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg"
                >
                  {t.cancelBtn}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-[#991B1B] hover:bg-[#7F1D1D] rounded-lg"
                >
                  {lang === 'ur' ? 'شکایت جمع کرائیں' : 'Submit Report to Admin'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
