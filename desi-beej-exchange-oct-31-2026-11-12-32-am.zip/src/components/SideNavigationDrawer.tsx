import React, { useEffect } from 'react';
import {
  X,
  Plus,
  Sprout,
  BookOpen,
  MessageSquare,
  Heart,
  Users,
  LayoutDashboard,
  ShieldCheck,
  Globe,
  Wheat,
  ChevronRight,
  ChevronLeft,
  Phone,
} from 'lucide-react';
import { Language, SeedCategory, AdminSession } from '../types/seed';
import { CATEGORY_LABELS, UI_TEXT } from '../i18n/translations';

export type NavPageId =
  | 'catalog'
  | 'crops'
  | 'chat'
  | 'saved'
  | 'sellers'
  | 'dashboard'
  | 'detail'
  | 'admin';

interface SideNavigationDrawerProps {
  isOpen: boolean;
  lang: Language;
  activePage: NavPageId;
  selectedCategory: SeedCategory | 'all';
  brandTitle: string;
  totalListingsCount: number;
  favoritesCount: number;
  sellersCount: number;
  inquiriesCount: number;
  adminSession: AdminSession | null;
  supportPhone?: string;
  onClose: () => void;
  onNavigate: (page: NavPageId) => void;
  onSelectCategory: (cat: SeedCategory | 'all') => void;
  onOpenAddSeedModal: () => void;
  onChangeLanguage: (nextLang: Language) => void;
}

export const SideNavigationDrawer: React.FC<SideNavigationDrawerProps> = ({
  isOpen,
  lang,
  activePage,
  selectedCategory,
  brandTitle,
  totalListingsCount,
  favoritesCount,
  sellersCount,
  inquiriesCount,
  adminSession,
  supportPhone,
  onClose,
  onNavigate,
  onSelectCategory,
  onOpenAddSeedModal,
  onChangeLanguage,
}) => {
  const t = UI_TEXT[lang];
  const isRtl = lang === 'ur';

  // Prevent background body scrolling while the drawer is open
  useEffect(() => {
    if (isOpen) {
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = prevOverflow;
      };
    }
  }, [isOpen]);

  // Close drawer on Escape key press
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const handleNavClick = (page: NavPageId) => {
    onNavigate(page);
    onClose();
  };

  const handleCategoryClick = (cat: SeedCategory | 'all') => {
    onSelectCategory(cat);
    onNavigate('catalog');
    onClose();
  };

  const handleAddSeedClick = () => {
    onClose();
    onOpenAddSeedModal();
  };

  const mainNavItems: {
    id: NavPageId;
    label: string;
    subLabel: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
  }[] = [
    {
      id: 'catalog',
      label: t.navCatalog,
      subLabel: isRtl ? 'تمام دیسی بیج تلاش کریں' : 'Browse & filter heirloom seeds',
      icon: Sprout,
      badge: totalListingsCount,
    },
    {
      id: 'crops',
      label: isRtl ? 'مشہور فصلیں' : t.navPopularCrops,
      subLabel: isRtl
        ? 'پاکستان کی فصلوں کی مکمل کاشتکاری گائیڈ'
        : 'Pakistan cultivation & sowing guide',
      icon: BookOpen,
    },
    {
      id: 'chat',
      label: t.navChat,
      subLabel: isRtl
        ? 'کسانوں سے براہِ راست پیغام اور وائس کال'
        : 'Voice messages & live WebRTC calls',
      icon: MessageSquare,
    },
    {
      id: 'saved',
      label: t.navSaved,
      subLabel: isRtl ? 'آپ کے محفوظ کردہ پسندیدہ بیج' : 'Your bookmarked seed varieties',
      icon: Heart,
      badge: favoritesCount,
    },
    {
      id: 'sellers',
      label: t.navSellers,
      subLabel: isRtl ? 'تصدیق شدہ کسان اور بیج محافظ' : 'Verified regional seed guardians',
      icon: Users,
      badge: sellersCount,
    },
    {
      id: 'dashboard',
      label: t.navDashboard,
      subLabel: isRtl
        ? 'آپ کے اشتہارات اور تبادلے کی درخواستیں'
        : 'Manage your listings & inquiries',
      icon: LayoutDashboard,
      badge: inquiriesCount > 0 ? inquiriesCount : undefined,
    },
    {
      id: 'admin',
      label: isRtl ? 'ایڈمن پینل (Admin Panel)' : 'Admin Panel',
      subLabel: adminSession
        ? isRtl
          ? 'ایڈمن سیشن فعال ہے'
          : 'Authorized session active'
        : isRtl
          ? 'موڈریشن، صارفین اور سکیورٹی کنٹرول'
          : 'Moderation, users & security logs',
      icon: ShieldCheck,
    },
  ];

  const categoriesList: (SeedCategory | 'all')[] = [
    'all',
    'wheat',
    'rice',
    'cotton',
    'vegetables',
    'fruits',
    'traditional',
  ];

  // Slide direction strictly follows active language:
  // Urdu (RTL): anchored on right (`right-0`), slides from `translate-x-full` to `translate-x-0`
  // English (LTR): anchored on left (`left-0`), slides from `-translate-x-full` to `translate-x-0`
  const drawerPositionClasses = isRtl
    ? 'right-0 border-l border-[#E6E2D8]'
    : 'left-0 border-r border-[#E6E2D8]';

  const drawerTranslateClasses = isOpen
    ? 'translate-x-0'
    : isRtl
      ? 'translate-x-full pointer-events-none'
      : '-translate-x-full pointer-events-none';

  return (
    <div
      className={`fixed inset-0 z-50 ${
        isOpen ? 'pointer-events-auto' : 'pointer-events-none'
      }`}
      aria-hidden={!isOpen}
    >
      {/* Semi-transparent Backdrop behind Drawer */}
      <div
        onClick={onClose}
        className={`fixed inset-0 bg-black/55 backdrop-blur-[2px] transition-opacity duration-300 ease-out ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        aria-label={isRtl ? 'مینیو بند کریں' : 'Close navigation menu'}
      />

      {/* Full-Height ChatGPT-Style Side Drawer Panel */}
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={isRtl ? 'نیویگیشن مینیو' : 'Side Navigation Menu'}
        dir={isRtl ? 'rtl' : 'ltr'}
        className={`fixed top-0 bottom-0 h-dvh w-[86vw] max-w-[320px] sm:max-w-[340px] bg-[#FAF8F5] text-[#18241B] shadow-2xl flex flex-col transition-transform duration-300 ease-out ${drawerPositionClasses} ${drawerTranslateClasses}`}
      >
        {/* 1. Sticky Top Header Bar (Brand + Close X Button + Primary New Seed CTA) */}
        <div className="px-4 pt-4 pb-3 bg-white border-b border-[#E6E2D8] shrink-0 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-[#14532D] text-white flex items-center justify-center shrink-0">
                <Sprout className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-[#14532D] truncate font-display">
                  {brandTitle}
                </p>
                <p className="text-[11px] text-[#5C6660] truncate">
                  {isRtl
                    ? 'پاکستانی دیسی بیج تبادلہ نیٹ ورک'
                    : 'Heirloom Seed Exchange Network'}
                </p>
              </div>
            </div>

            {/* Clear Close (X) Button at the top */}
            <button
              type="button"
              onClick={onClose}
              aria-label={isRtl ? 'مینیو بند کریں' : 'Close menu'}
              className="w-9 h-9 rounded-lg flex items-center justify-center text-[#4A554E] hover:text-[#18241B] hover:bg-[#EFECE6] transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Primary Action Button (ChatGPT "New Chat"-style top action) */}
          <button
            type="button"
            onClick={handleAddSeedClick}
            className="w-full flex items-center justify-between gap-2 px-3.5 py-2.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-xl transition-colors cursor-pointer shadow-xs"
          >
            <span className="inline-flex items-center gap-2">
              <Plus className="w-4 h-4" />
              <span>{t.postSeedCta}</span>
            </span>
            {isRtl ? (
              <ChevronLeft className="w-4 h-4 opacity-80" />
            ) : (
              <ChevronRight className="w-4 h-4 opacity-80" />
            )}
          </button>
        </div>

        {/* 2. Scrollable Middle Navigation Area */}
        <div className="flex-1 overflow-y-auto overscroll-contain px-3 py-4 space-y-6">
          {/* Primary Navigation Section */}
          <div className="space-y-1">
            <p className="px-2.5 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#5C6660]">
              {isRtl ? 'مرکزی صفحات (Navigation)' : 'Main Navigation'}
            </p>
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-xl text-start transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#14532D] text-white font-semibold shadow-xs'
                      : 'text-[#18241B] hover:bg-[#EFECE6]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        isActive
                          ? 'bg-white/15 text-white'
                          : 'bg-white border border-[#E6E2D8] text-[#14532D]'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm leading-tight truncate">{item.label}</p>
                      <p
                        className={`text-[11px] truncate mt-0.5 ${
                          isActive ? 'text-white/80' : 'text-[#5C6660]'
                        }`}
                      >
                        {item.subLabel}
                      </p>
                    </div>
                  </div>

                  {typeof item.badge === 'number' && (
                    <span
                      className={`px-2 py-0.5 text-[11px] font-mono-num rounded-md shrink-0 ${
                        isActive
                          ? 'bg-white/20 text-white'
                          : 'bg-[#EAF2EC] text-[#14532D] font-semibold'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Seed Categories Quick-Filter Section */}
          <div className="space-y-1 pt-2 border-t border-[#E6E2D8]">
            <p className="px-2.5 pb-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#5C6660]">
              {isRtl ? 'بیجوں کی اقسام (Seed Categories)' : 'Seed Categories'}
            </p>
            <div className="space-y-1">
              {categoriesList.map((cat) => {
                const isCatActive =
                  activePage === 'catalog' && selectedCategory === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => handleCategoryClick(cat)}
                    className={`w-full flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-start transition-colors cursor-pointer ${
                      isCatActive
                        ? 'bg-[#EAF2EC] text-[#14532D] font-semibold border border-[#14532D]/25'
                        : 'text-[#36403A] hover:bg-[#EFECE6]'
                    }`}
                  >
                    <span className="inline-flex items-center gap-2.5 truncate">
                      <Wheat className="w-3.5 h-3.5 text-[#14532D] shrink-0" />
                      <span className="truncate">{CATEGORY_LABELS[cat][lang]}</span>
                    </span>
                    {isRtl ? (
                      <ChevronLeft className="w-3.5 h-3.5 text-[#5C6660] shrink-0" />
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-[#5C6660] shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* 3. Sticky Bottom Footer (Language Switcher & Helpline Info) */}
        <div className="p-3.5 bg-white border-t border-[#E6E2D8] shrink-0 space-y-3">
          {/* Language Switcher inside Drawer */}
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#4A554E]">
              <Globe className="w-3.5 h-3.5 text-[#14532D]" />
              <span>{isRtl ? 'ایپ کی زبان:' : 'Language:'}</span>
            </span>

            <div className="inline-flex items-center p-0.5 bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg">
              <button
                type="button"
                onClick={() => onChangeLanguage('en')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  lang === 'en'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                English (LTR)
              </button>
              <button
                type="button"
                onClick={() => onChangeLanguage('ur')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  lang === 'ur'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                اردو (RTL)
              </button>
            </div>
          </div>

          {supportPhone && (
            <div className="pt-2 border-t border-[#F0EDE6] flex items-center justify-between text-[11px] text-[#5C6660]">
              <span className="inline-flex items-center gap-1">
                <Phone className="w-3 h-3 text-[#14532D]" />
                <span>{isRtl ? 'کسان ہیلپ لائن:' : 'Farmer Helpline:'}</span>
              </span>
              <span className="font-mono-num font-semibold text-[#18241B]">
                {supportPhone}
              </span>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
};
