import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Edit3,
  RotateCcw,
  Download,
  MessageCircle,
  Database,
} from 'lucide-react';
import { SeedListing, SeedInquiry, Language } from '../types/seed';
import { CATEGORY_LABELS, UI_TEXT, formatPKR, formatWhatsAppUrl } from '../i18n/translations';
import { SeedCard } from './SeedCard';
import { SeedImage } from './SeedImage';

interface UserDashboardViewProps {
  listings: SeedListing[];
  favorites: string[];
  inquiries: SeedInquiry[];
  lang: Language;
  onAddSeedClick: () => void;
  onEditSeed: (seed: SeedListing) => void;
  onDeleteSeed: (id: string) => void;
  onResetDemo: () => void;
  onSelectSeed: (seed: SeedListing) => void;
  onSelectSeller: (sellerId: string, e: React.MouseEvent) => void;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  listings,
  favorites,
  inquiries,
  lang,
  onAddSeedClick,
  onEditSeed,
  onDeleteSeed,
  onResetDemo,
  onSelectSeed,
  onSelectSeller,
  onToggleFavorite,
}) => {
  const t = UI_TEXT[lang];
  const [activeTab, setActiveTab] = useState<'listings' | 'saved' | 'inquiries'>('listings');

  const favoriteSeeds = listings.filter((item) => favorites.includes(item.id));

  const handleExportJson = () => {
    const dataStr =
      'data:text/json;charset=utf-8,' +
      encodeURIComponent(JSON.stringify(listings, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'desi-beej-catalog-backup.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header & Utility Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-6 border-b border-[#E6E2D8]">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#14532D] font-medium mb-1">
            <Database className="w-3.5 h-3.5" />
            <span>{t.firebaseReadyBadge}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">{t.dashboardTitle}</h1>
          <p className="text-sm text-[#4A554E] mt-1">{t.dashboardSubtitle}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onAddSeedClick}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>{t.postSeedCta}</span>
          </button>

          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#18241B] bg-white hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.exportJsonBtn}</span>
          </button>

          <button
            type="button"
            onClick={onResetDemo}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-[#4A554E] hover:text-[#18241B] bg-white hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t.resetDemoDataBtn}</span>
          </button>
        </div>
      </div>

      {/* Dashboard Summary Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
          <p className="text-xs text-[#5C6660]">{t.myListingsTab}</p>
          <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
            {listings.length}
          </p>
        </div>
        <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
          <p className="text-xs text-[#5C6660]">{t.savedSeedsTab}</p>
          <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
            {favoriteSeeds.length}
          </p>
        </div>
        <div className="bg-white border border-[#E6E2D8] rounded-xl p-5">
          <p className="text-xs text-[#5C6660]">{t.inquiriesTab}</p>
          <p className="text-2xl font-bold text-[#18241B] font-mono-num mt-1">
            {inquiries.length}
          </p>
        </div>
      </div>

      {/* Segmented Control Tabs */}
      <div className="inline-flex items-center gap-1 p-1 bg-[#EFECE6] rounded-lg">
        <button
          type="button"
          onClick={() => setActiveTab('listings')}
          className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'listings'
              ? 'bg-white text-[#18241B] shadow-xs'
              : 'text-[#4A554E] hover:text-[#18241B]'
          }`}
        >
          {t.myListingsTab} ({listings.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('saved')}
          className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'saved'
              ? 'bg-white text-[#18241B] shadow-xs'
              : 'text-[#4A554E] hover:text-[#18241B]'
          }`}
        >
          {t.savedSeedsTab} ({favoriteSeeds.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('inquiries')}
          className={`px-4 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
            activeTab === 'inquiries'
              ? 'bg-white text-[#18241B] shadow-xs'
              : 'text-[#4A554E] hover:text-[#18241B]'
          }`}
        >
          {t.inquiriesTab} ({inquiries.length})
        </button>
      </div>

      {/* Tab 1: Manage All Seed Listings */}
      {activeTab === 'listings' && (
        <div className="bg-white border border-[#E6E2D8] rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-[#E6E2D8] bg-[#FAF8F5] text-xs font-semibold text-[#4A554E]">
                  <th className="py-3.5 px-4 text-start">
                    {lang === 'ur' ? 'بیج کا نام' : 'Seed Variety'}
                  </th>
                  <th className="py-3.5 px-4 text-start">
                    {lang === 'ur' ? 'کیٹیگری · شہر' : 'Category · City'}
                  </th>
                  <th className="py-3.5 px-4 text-start">
                    {lang === 'ur' ? 'قیمت' : 'Price (PKR)'}
                  </th>
                  <th className="py-3.5 px-4 text-start">
                    {lang === 'ur' ? 'کسان رابطہ' : 'Seller Contact'}
                  </th>
                  <th className="py-3.5 px-4 text-end">
                    {lang === 'ur' ? 'عمل' : 'Actions'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F0EDE6] text-sm">
                {listings.map((item) => {
                  const title = lang === 'ur' ? item.nameUr || item.nameEn : item.nameEn;
                  return (
                    <tr key={item.id} className="hover:bg-[#FAF8F5] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-9 rounded-md overflow-hidden bg-[#EFECE6] shrink-0">
                            <SeedImage
                              src={item.image}
                              alt={title}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <button
                              type="button"
                              onClick={() => onSelectSeed(item)}
                              className="font-semibold text-[#18241B] hover:text-[#14532D] text-start line-clamp-1"
                            >
                              {title}
                            </button>
                            <p className="text-xs text-[#5C6660] font-mono-num">
                              {item.quantityEn}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-xs text-[#4A554E]">
                        <span>{CATEGORY_LABELS[item.category][lang]}</span>
                        <span className="mx-1.5">·</span>
                        <span>{item.city}</span>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-[#18241B] font-mono-num whitespace-nowrap">
                        {formatPKR(item.pricePKR, lang)}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-[#4A554E] font-mono-num">
                        {item.sellerNameEn} · {item.sellerPhone}
                      </td>
                      <td className="py-3.5 px-4 text-end whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onEditSeed(item)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-md"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>{t.editListingBtn}</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteSeed(item.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#991B1B] bg-[#FEF2F2] hover:bg-[#FEE2E2] rounded-md"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>{t.deleteListingBtn}</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Saved Favorites */}
      {activeTab === 'saved' && (
        <div>
          {favoriteSeeds.length === 0 ? (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-10 text-center">
              <p className="text-base font-semibold text-[#18241B]">
                {lang === 'ur'
                  ? 'آپ نے ابھی تک کوئی دیسی بیج محفوظ نہیں کیا'
                  : 'No favorite seeds saved yet'}
              </p>
              <p className="text-xs text-[#5C6660] mt-1">
                {lang === 'ur'
                  ? 'کسی بھی بیج کارڈ پر دل کے نشان پر کلک کر کے اسے یہاں محفوظ کریں۔'
                  : 'Click the heart icon on any seed listing to bookmark it here for quick comparison.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {favoriteSeeds.map((seed) => (
                <SeedCard
                  key={seed.id}
                  seed={seed}
                  lang={lang}
                  isFavorite={true}
                  onToggleFavorite={onToggleFavorite}
                  onSelectSeed={onSelectSeed}
                  onSelectSeller={onSelectSeller}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Sent Inquiries */}
      {activeTab === 'inquiries' && (
        <div className="space-y-4">
          {inquiries.length === 0 ? (
            <div className="bg-white border border-[#E6E2D8] rounded-xl p-10 text-center">
              <p className="text-base font-semibold text-[#18241B]">
                {lang === 'ur'
                  ? 'ابھی تک کوئی خریداری یا تبادلے کی درخواست نہیں بھیجی گئی'
                  : 'No purchase or seed exchange inquiries logged yet'}
              </p>
              <p className="text-xs text-[#5C6660] mt-1">
                {lang === 'ur'
                  ? 'کسی بھی بیج کی تفصیل کے صفحے پر جا کر کسان کو تبادلے یا خریداری کا پیغام بھیجیں۔'
                  : 'Open any seed detail page and submit a Cash Purchase or Barter Exchange inquiry.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {inquiries.map((inq) => (
                <div
                  key={inq.id}
                  className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-3"
                >
                  <div className="flex items-center justify-between text-xs text-[#5C6660]">
                    <span className="font-semibold text-[#14532D]">
                      {inq.inquiryType === 'exchange'
                        ? lang === 'ur'
                          ? 'بیج کا تبادلہ (بارٹر)'
                          : 'Seed Barter Exchange'
                        : lang === 'ur'
                          ? 'نقد خریداری'
                          : 'Direct Cash Purchase'}
                    </span>
                    <span className="font-mono-num">{inq.createdAt}</span>
                  </div>
                  <h3 className="text-base font-bold text-[#18241B]">
                    {lang === 'ur' ? inq.seedNameUr : inq.seedNameEn}
                  </h3>
                  <p className="text-xs text-[#4A554E]">
                    {lang === 'ur' ? 'مقدار: ' : 'Requested Qty: '}
                    <span className="font-semibold">{inq.requestedQuantity}</span>
                    {inq.offeredSeedForExchange && (
                      <>
                        {' · '}
                        {lang === 'ur' ? 'پیش کردہ بیج: ' : 'Offered in Exchange: '}
                        <span className="font-semibold">{inq.offeredSeedForExchange}</span>
                      </>
                    )}
                  </p>
                  {inq.message && (
                    <p className="text-xs text-[#5C6660] italic">"{inq.message}"</p>
                  )}
                  <div className="pt-3 border-t border-[#F0EDE6] flex items-center justify-between">
                    <span className="text-xs text-[#4A554E]">
                      {inq.sellerNameEn} ({inq.sellerPhone})
                    </span>
                    <a
                      href={formatWhatsAppUrl(
                        inq.sellerPhone,
                        `Assalam-o-Alaikum ${inq.sellerNameEn}, following up on my inquiry for ${inq.seedNameEn} (${inq.requestedQuantity}).`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] rounded-lg"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>{t.whatsappSeller}</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
