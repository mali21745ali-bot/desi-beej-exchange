import React, { useState, useMemo } from 'react';
import {
  Search,
  Calendar,
  Clock,
  Sprout,
  Droplets,
  ShieldAlert,
  BookOpen,
  ArrowLeft,
  ArrowRight,
  AlertTriangle,
  ArrowUpRight,
} from 'lucide-react';
import {
  CropGuide,
  CropGroupCategory,
  Language,
  SeedCategory,
} from '../types/seed';
import {
  POPULAR_CROPS_DATA,
  CROP_GROUP_LABELS,
} from '../data/popularCropsData';
import { SeedImage } from './SeedImage';

interface PopularCropsViewProps {
  lang: Language;
  onBrowseCategoryInCatalog: (category: SeedCategory) => void;
}

export const PopularCropsView: React.FC<PopularCropsViewProps> = ({
  lang,
  onBrowseCategoryInCatalog,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<CropGroupCategory>('all');
  const [selectedCrop, setSelectedCrop] = useState<CropGuide | null>(null);

  const filteredCrops = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return POPULAR_CROPS_DATA.filter((crop) => {
      if (selectedGroup !== 'all' && crop.category !== selectedGroup) {
        return false;
      }
      if (!q) return true;
      return (
        crop.nameEn.toLowerCase().includes(q) ||
        crop.nameUr.toLowerCase().includes(q) ||
        crop.botanicalName.toLowerCase().includes(q) ||
        crop.sowingSeasonEn.toLowerCase().includes(q) ||
        crop.seedSelectionEn.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedGroup]);

  const categories: CropGroupCategory[] = [
    'all',
    'cereals',
    'cash_oilseeds',
    'vegetables',
    'fruits_seasonal',
  ];

  // Detailed Single Crop Cultivation View
  if (selectedCrop) {
    const title = lang === 'ur' ? selectedCrop.nameUr : selectedCrop.nameEn;
    const secondaryTitle =
      lang === 'ur' ? selectedCrop.nameEn : selectedCrop.nameUr;

    const guideSections = [
      {
        label: lang === 'ur' ? 'وقتِ کاشت (پاکستان)' : 'Sowing Season in Pakistan',
        value:
          lang === 'ur'
            ? selectedCrop.sowingSeasonUr
            : selectedCrop.sowingSeasonEn,
        icon: Calendar,
      },
      {
        label:
          lang === 'ur'
            ? 'موزوں زمین اور آب و ہوا'
            : 'Suitable Soil & Climate',
        value:
          lang === 'ur'
            ? selectedCrop.soilAndClimateUr
            : selectedCrop.soilAndClimateEn,
        icon: Sprout,
      },
      {
        label:
          lang === 'ur'
            ? 'بیج کا انتخاب اور شرحِ بیج'
            : 'Seed Selection & Seed Rate',
        value:
          lang === 'ur'
            ? selectedCrop.seedSelectionUr
            : selectedCrop.seedSelectionEn,
        icon: BookOpen,
      },
      {
        label:
          lang === 'ur'
            ? 'زمین کی تیاری اور طریقہ کاشت'
            : 'Cultivation & Planting Guide',
        value:
          lang === 'ur'
            ? selectedCrop.cultivationGuideUr
            : selectedCrop.cultivationGuideEn,
        icon: Sprout,
      },
      {
        label:
          lang === 'ur'
            ? 'آبپاشی (پانی لگانے کا شیڈول)'
            : 'Irrigation Guidance',
        value:
          lang === 'ur'
            ? selectedCrop.irrigationGuidanceUr
            : selectedCrop.irrigationGuidanceEn,
        icon: Droplets,
      },
      {
        label:
          lang === 'ur'
            ? 'دیسی اور کیمیائی کھادوں کا استعمال'
            : 'Fertilizer & Organic Manure Guidance',
        value:
          lang === 'ur'
            ? selectedCrop.fertilizerGuidanceUr
            : selectedCrop.fertilizerGuidanceEn,
        icon: Sprout,
      },
      {
        label:
          lang === 'ur'
            ? 'عام کیڑے مکوڑے، بیماریاں اور تدارک'
            : 'Common Pests, Diseases & IPM Controls',
        value:
          lang === 'ur'
            ? selectedCrop.pestsAndDiseasesUr
            : selectedCrop.pestsAndDiseasesEn,
        icon: ShieldAlert,
      },
      {
        label:
          lang === 'ur'
            ? 'برداشت (کٹائی) اور ذخیرہ اندوزی'
            : 'Harvesting & Storage Information',
        value:
          lang === 'ur'
            ? selectedCrop.harvestingInfoUr
            : selectedCrop.harvestingInfoEn,
        icon: Clock,
      },
    ];

    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <button
          type="button"
          onClick={() => setSelectedCrop(null)}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#4A554E] hover:text-[#14532D]"
        >
          {lang === 'ur' ? (
            <ArrowRight className="w-4 h-4" />
          ) : (
            <ArrowLeft className="w-4 h-4" />
          )}
          <span>
            {lang === 'ur'
              ? 'مشہور فصلوں کی فہرست پر واپس جائیں'
              : 'Back to All Popular Crops (مشہور فصلیں)'}
          </span>
        </button>

        {/* Crop Hero Header */}
        <div className="bg-white border border-[#E6E2D8] rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          <div className="lg:col-span-5 aspect-4/3 lg:aspect-auto bg-[#F4F1EA]">
            <SeedImage
              src={selectedCrop.image}
              alt={title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-3">
              <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6660]">
                <span className="font-semibold text-[#14532D]">
                  {CROP_GROUP_LABELS[selectedCrop.category][lang]}
                </span>
                <span aria-hidden="true">·</span>
                <span className="italic">{selectedCrop.botanicalName}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-num">
                  {lang === 'ur'
                    ? selectedCrop.estimatedDurationUr
                    : selectedCrop.estimatedDurationEn}
                </span>
              </div>

              <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">
                {title}
              </h1>
              <p className="text-base text-[#5C6660] font-medium">
                {secondaryTitle}
              </p>
            </div>

            <div className="p-4 rounded-lg bg-[#FAF8F5] border border-[#E6E2D8] space-y-1">
              <p className="text-xs text-[#5C6660]">
                {lang === 'ur'
                  ? 'پکنے کا تخمینی دورانیہ (Estimated Crop Duration)'
                  : 'Estimated Crop Duration'}
              </p>
              <p className="text-base font-bold text-[#14532D] font-mono-num">
                {lang === 'ur'
                  ? selectedCrop.estimatedDurationUr
                  : selectedCrop.estimatedDurationEn}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() =>
                  onBrowseCategoryInCatalog(selectedCrop.linkedSeedCategory)
                }
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors"
              >
                <span>
                  {lang === 'ur'
                    ? 'کیٹلاگ میں اس فصل کے دیسی بیج دیکھیں'
                    : 'Browse Seeds for This Crop in Catalog'}
                </span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* 8-Point Comprehensive Agronomic Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {guideSections.map((sec, idx) => {
            const IconComponent = sec.icon;
            return (
              <div
                key={idx}
                className="bg-white border border-[#E6E2D8] rounded-xl p-6 space-y-2.5"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-[#14532D]">
                  <IconComponent className="w-4 h-4 shrink-0" />
                  <span>
                    0{idx + 1}. {sec.label}
                  </span>
                </div>
                <p className="text-sm text-[#18241B] leading-relaxed">
                  {sec.value}
                </p>
              </div>
            );
          })}
        </div>

        {/* Local Confirmation Advisory Banner */}
        <div className="bg-[#F3EFE6] border border-[#E6E2D8] rounded-xl p-5 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
          <div className="text-xs text-[#36403A] leading-relaxed">
            <span className="font-bold text-[#18241B]">
              {lang === 'ur'
                ? 'مقامی زرعی مشاورت کی ہدایت: '
                : 'Local Agricultural Advisory Notice: '}
            </span>
            {lang === 'ur'
              ? 'پاکستان کے مختلف اضلاع (پنجاب، سندھ، خیبر پختونخوا، بلوچستان) میں زمین کی ساخت، نہری پانی اور موسم کے فرق کی وجہ سے بوائی کی تاریخوں اور کھاد کی مقدار میں تبدیلی ہو سکتی ہے۔ کاشتکار بھائی حتمی عمل درآمد سے قبل اپنے علاقے کے محکمہ زراعت (توسیع) یا مٹی و پانی کی تجزیہ گاہ سے ضرور مشورہ کریں۔'
              : 'Sowing windows, seed rates, and fertilizer dosages vary across agro-ecological zones of Punjab, Sindh, Khyber Pakhtunkhwa, and Balochistan. Farmers are strongly advised to confirm final recommendations with their local Agriculture Extension Officer (محکمہ زراعت توسیع) and soil/water testing laboratory before application.'}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Section Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 border-b border-[#E6E2D8] pb-6">
        <div className="space-y-2 max-w-3xl">
          <p className="text-xs font-semibold tracking-wider text-[#14532D]">
            {lang === 'ur'
              ? 'پاکستان زرعی معلوماتی مرکز · ربیع اور خریف گائیڈ'
              : 'PAKISTAN AGRONOMIC KNOWLEDGE BASE · RABI & KHARIF'}
          </p>
          <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">
            مشہور فصلیں | Popular Crops
          </h1>
          <p className="text-sm text-[#4A554E] leading-relaxed">
            {lang === 'ur'
              ? 'گندم، دھان، کپاس، مکئی، گنا، سرسوں، آلو، پیاز، ٹماٹر اور موسمی پھلوں و سبزیوں کی پاکستان کے موسم اور زمین کے مطابق مکمل کاشتکاری گائیڈ۔'
              : 'Complete Pakistan-specific cultivation guides covering sowing seasons, soil requirements, seed selection, canal irrigation, organic fertilization, pest management, and harvest duration.'}
          </p>
        </div>
      </div>

      {/* Local Extension Confirmation Banner */}
      <div className="bg-[#F3EFE6] border border-[#E6E2D8] rounded-xl p-4 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-[#B45309] shrink-0 mt-0.5" />
        <p className="text-xs text-[#36403A] leading-relaxed">
          <span className="font-bold text-[#18241B]">
            {lang === 'ur' ? 'اہم زرعی نوٹ: ' : 'Regional Confirmation Advisory: '}
          </span>
          {lang === 'ur'
            ? 'یہ معلومات پاکستان کے عمومی زرعی حالات کے مطابق مرتب کی گئی ہیں۔ اپنے گاؤں یا ضلع کی زمین کے تجزیے اور مقامی موسم کے مطابق محکمہ زراعت توسیع کے عملے سے سفارشات کی تصدیق ضرور کریں۔'
            : 'These crop calendars and agronomic guidelines reflect general Pakistani canal and barani zones. Always verify seed varieties, fertilizer rates, and pest controls with your local District Agriculture Extension office and soil test report.'}
        </p>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 space-y-4">
        <div className="relative">
          <Search className="w-4 h-4 text-[#5C6660] absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              lang === 'ur'
                ? 'فصل کا نام تلاش کریں (مثلاً گندم، کپاس، مکئی، گنا، سرسوں، آلو، پیاز، ٹماٹر)...'
                : 'Search crops by English, Urdu, or botanical name (e.g., Wheat, Gandum, Maize, Mustard, Potato, Onion)...'
            }
            className="w-full ps-10 pe-4 py-2.5 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {categories.map((cat) => {
            const active = selectedGroup === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedGroup(cat)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#14532D] text-white'
                    : 'bg-[#FAF8F5] text-[#4A554E] hover:text-[#18241B] border border-[#E6E2D8]'
                }`}
              >
                {CROP_GROUP_LABELS[cat][lang]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Crops Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCrops.map((crop) => {
          const primaryName = lang === 'ur' ? crop.nameUr : crop.nameEn;
          const secondaryName = lang === 'ur' ? crop.nameEn : crop.nameUr;

          return (
            <article
              key={crop.id}
              onClick={() => setSelectedCrop(crop)}
              className="group bg-white border border-[#E6E2D8] rounded-xl overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <div>
                <div className="aspect-4/3 w-full bg-[#F4F1EA] overflow-hidden">
                  <SeedImage
                    src={crop.image}
                    alt={primaryName}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                </div>

                <div className="p-5 space-y-2.5">
                  {/* Unboxed Metadata */}
                  <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#5C6660]">
                    <span className="font-semibold text-[#14532D]">
                      {CROP_GROUP_LABELS[crop.category][lang]}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-num">
                      {lang === 'ur'
                        ? crop.estimatedDurationUr
                        : crop.estimatedDurationEn}
                    </span>
                  </div>

                  <div>
                    <h2 className="text-lg font-bold text-[#18241B] group-hover:text-[#14532D] transition-colors">
                      {primaryName}
                    </h2>
                    <p className="text-xs text-[#5C6660] font-medium">
                      {secondaryName} · <span className="italic">{crop.botanicalName}</span>
                    </p>
                  </div>

                  <p className="text-xs text-[#36403A] line-clamp-3 leading-relaxed pt-1">
                    <span className="font-semibold text-[#18241B]">
                      {lang === 'ur' ? 'وقتِ کاشت: ' : 'Sowing Season: '}
                    </span>
                    {lang === 'ur' ? crop.sowingSeasonUr : crop.sowingSeasonEn}
                  </p>
                </div>
              </div>

              <div className="px-5 pb-5 pt-3 border-t border-[#F0EDE6] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedCrop(crop);
                  }}
                  className="text-xs font-semibold text-[#14532D] hover:underline"
                >
                  {lang === 'ur'
                    ? 'مکمل کاشتکاری گائیڈ پڑھیں ←'
                    : 'Read Full Cultivation Guide →'}
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onBrowseCategoryInCatalog(crop.linkedSeedCategory);
                  }}
                  className="px-2.5 py-1.5 text-xs font-medium text-[#18241B] bg-[#FAF8F5] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg whitespace-nowrap"
                >
                  {lang === 'ur' ? 'بیج دیکھیں' : 'Find Seeds'}
                </button>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};
