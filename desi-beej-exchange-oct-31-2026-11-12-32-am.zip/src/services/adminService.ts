import {
  SellerProfile,
  SeedListing,
  UserReport,
  AdminActivityLog,
  PlatformSettings,
  AdminSession,
  AdminActionCategory,
  ReportStatus,
} from '../types/seed';
import { INITIAL_SELLERS } from '../data/initialSeeds';

const ADMIN_STORAGE_KEYS = {
  USERS: 'desi_beej_admin_users_v1',
  REPORTS: 'desi_beej_admin_reports_v1',
  ACTIVITY_LOGS: 'desi_beej_admin_logs_v1',
  PLATFORM_SETTINGS: 'desi_beej_platform_settings_v1',
  ADMIN_SESSION: 'desi_beej_admin_session_v1',
};

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettings = {
  appNameEn: 'Desi Beej Exchange',
  appNameUr: 'دیسی بیج ایکسچینج',
  taglineEn: 'PAKISTANI HEIRLOOM SEED SOVEREIGNTY · KISAN TO KISAN',
  taglineUr: 'پاکستان کے روایتی دیسی بیجوں کا تحفظ · کسان سے کسان تک',
  defaultLanguage: 'ur',
  helplinePhone: '0800-11223 (Kisan Seed Helpline)',
  supportEmail: 'support@desibeej.pk',
  requireListingApproval: false,
  enableBarterExchange: true,
  announcementBannerEn: '',
  announcementBannerUr: '',
};

const INITIAL_USERS_WITH_STATUS: SellerProfile[] = [
  ...INITIAL_SELLERS.map((s) => ({
    ...s,
    status: 'active' as const,
    role: 'verified_guardian' as const,
  })),
  {
    id: 'seller-suspect-99',
    nameEn: 'Rana Dilشاد Traders (Unverified Broker)',
    nameUr: 'رانا دلشاد ٹریڈرز (غیر تصدیق شدہ آڑھتی)',
    farmNameEn: 'Imported Hybrid Seed Agency',
    farmNameUr: 'امپورٹڈ ہائبرڈ سیڈ ایجنسی',
    city: 'Lahore',
    provinceEn: 'Punjab',
    provinceUr: 'پنجاب',
    locationEn: 'temporary stall near Badami Bagh',
    locationUr: 'بادامی باغ کے قریب عارضی سٹال',
    phone: '0399-0000111',
    whatsapp: '923990000111',
    experienceYears: 1,
    bioEn: 'Selling cheap chemical-coated hybrid packets claiming 100% miracle yield if advance JazzCash payment is sent.',
    bioUr: 'پیشگی جیز کیش رقم منگوا کر کیمیکل ملے ہائبرڈ بیج کو دیسی قرار دے کر فروخت کرنے والا مشتبہ اکاؤنٹ۔',
    totalExchanges: 0,
    joinedYear: 2026,
    seedPledgeEn: 'Advance payment required before dispatch.',
    seedPledgeUr: 'ڈلیوری سے پہلے ایڈوانس رقم لازمی۔',
    status: 'active',
    role: 'farmer',
  },
];

export const SUSPECT_FAKE_DEMO_LISTING: SeedListing = {
  id: 'seed-fake-999',
  nameEn: 'Miracle Imported GMO Wheat Sold as Sharbati (Advance Payment Only)',
  nameUr: 'امپورٹڈ ہائبرڈ گندم بطور دیسی شربتی (صرف ایڈوانس رقم)',
  varietyCode: 'SUSPECT-GMO-99',
  category: 'wheat',
  image: '/src/assets/images/seed_sharbati_wheat_1793414536309.jpg',
  pricePKR: 450,
  quantityEn: '40 kg Maund Bag (Unverified)',
  quantityUr: '40 کلو بوری (غیر تصدیق شدہ)',
  availableStockEn: '5000 Bags',
  availableStockUr: '5000 بوریاں',
  city: 'Lahore',
  locationEn: 'Unknown Go-down, Lahore',
  locationUr: 'نامعلوم گودام، لاہور',
  descriptionEn:
    'Send 100% advance payment on EasyPaisa before delivery. Guaranteed 120 maunds per acre miracle GMO hybrid wheat labeled as desi seed.',
  descriptionUr:
    'ڈلیوری سے پہلے مکمل ایڈوانس رقم ایزی پیسہ کریں۔ ہائبرڈ بیج کو دیسی شربتی گندم کے نام پر انتہائی کم قیمت میں فروخت کیا جا رہا ہے۔',
  sellerId: 'seller-suspect-99',
  sellerNameEn: 'Rana Dilshad Traders (Unverified Broker)',
  sellerNameUr: 'رانا دلشاد ٹریڈرز (غیر تصدیق شدہ آڑھتی)',
  sellerFarmEn: 'Imported Hybrid Seed Agency',
  sellerFarmUr: 'امپورٹڈ ہائبرڈ سیڈ ایجنسی',
  sellerPhone: '0399-0000111',
  exchangeType: 'sale',
  exchangeNotesEn: 'No inspection allowed. Advance payment only.',
  exchangeNotesUr: 'معائنہ کی اجازت نہیں، صرف پیشگی رقم۔',
  sowingSeasonEn: 'Anytime',
  sowingSeasonUr: 'ہر موسم',
  germinationRate: 99,
  maturityDays: 60,
  waterRequirementEn: 'None',
  waterRequirementUr: 'بغیر پانی',
  heirloomGenerationEn: 'Unverified Commercial Batch',
  heirloomGenerationUr: 'غیر تصدیق شدہ تجارتی بیج',
  createdAt: '2026-10-30',
  approvalStatus: 'pending',
  isSuspectedFake: true,
  fakeReasonEn:
    'Flagged by Automated Fraud Scanner: Price (PKR 450 / 40kg) is 90% below market average, demands 100% advance payment without inspection, and mixes GMO/Hybrid claims with Desi wheat.',
  fakeReasonUr:
    'خودکار جعلی اشتہار اسکینر کی رپورٹ: 40 کلو گندم کی قیمت (450 روپے) مارکیٹ سے 90 فیصد کم ہے، بغیر معائنہ پیشگی رقم کا مطالبہ ہے اور ہائبرڈ/جی ایم او بیج کو دیسی ظاہر کیا گیا ہے۔',
};

const INITIAL_REPORTS: UserReport[] = [
  {
    id: 'rep-1001',
    targetSeedId: 'seed-fake-999',
    targetSeedNameEn: 'Miracle Imported GMO Wheat Sold as Sharbati',
    targetSeedNameUr: 'امپورٹڈ ہائبرڈ گندم بطور دیسی شربتی',
    targetSellerId: 'seller-suspect-99',
    targetSellerNameEn: 'Rana Dilshad Traders (Unverified Broker)',
    targetSellerNameUr: 'رانا دلشاد ٹریڈرز',
    reporterName: 'Malik Tariq Mehmood',
    reporterPhone: '0302-4455667',
    reporterCity: 'Okara',
    reasonType: 'advance_payment_scam',
    detailsEn:
      'This seller is demanding Rs. 5,000 advance fee on JazzCash and refusing video call inspection of the wheat bags. Also PKR 450 for 40kg wheat is impossible.',
    detailsUr:
      'یہ شخص جیز کیش پر پیشگی رقم مانگ رہا ہے اور بیج دکھانے سے انکار کر رہا ہے۔ 450 روپے میں 40 کلو گندم ممکن نہیں، یہ جعلی اشتہار ہے۔',
    status: 'open',
    createdAt: '2026-10-30 09:15 AM',
  },
  {
    id: 'rep-1002',
    targetSeedId: 'seed-fake-999',
    targetSeedNameEn: 'Miracle Imported GMO Wheat Sold as Sharbati',
    targetSeedNameUr: 'امپورٹڈ ہائبرڈ گندم بطور دیسی شربتی',
    targetSellerId: 'seller-suspect-99',
    targetSellerNameEn: 'Rana Dilshad Traders (Unverified Broker)',
    targetSellerNameUr: 'رانا دلشاد ٹریڈرز',
    reporterName: 'Haji Ghulam Mustafa',
    reporterPhone: '0300-6543210',
    reporterCity: 'Sahiwal',
    reasonType: 'hybrid_sold_as_desi',
    detailsEn:
      'Seller is using photos of our Sharbati wheat to sell chemically treated F1 hybrid grain.',
    detailsUr:
      'یہ فروخت کنندہ ہماری شربتی گندم کی تصویر لگا کر کیمیکل لگا ہائبرڈ بیج بیچنے کی کوشش کر رہا ہے۔',
    status: 'open',
    createdAt: '2026-10-30 11:40 AM',
  },
];

const INITIAL_ACTIVITY_LOGS: AdminActivityLog[] = [
  {
    id: 'log-init-1',
    timestamp: '2026-10-30 08:00:00',
    adminEmail: 'system@desibeej.pk',
    authMode: 'demo-preview',
    category: 'fraud_action',
    actionEn:
      'Automated Fraud Scanner flagged listing #seed-fake-999 (Miracle Imported GMO Wheat) for advance-payment scam keywords & abnormal PKR 450/Maund pricing.',
    actionUr:
      'خودکار اسکینر نے اشتہار #seed-fake-999 کو غیر معمولی کم قیمت (450 روپے فی من) اور پیشگی رقم کے مطالبے کی وجہ سے مشکوک/جعلی قرار دیا۔',
    targetId: 'seed-fake-999',
  },
  {
    id: 'log-init-2',
    timestamp: '2026-10-29 18:30:00',
    adminEmail: 'admin@desibeej.pk',
    authMode: 'demo-preview',
    category: 'listing_moderation',
    actionEn:
      'Approved 6 verified heirloom seed listings from Sahiwal, Gujranwala, Bahawalpur, Multan, Faisalabad, and Hyderabad.',
    actionUr:
      'ساہیوال، گوجرانوالہ، بہاولپور، ملتان، فیصل آباد اور حیدرآباد کے 6 تصدیق شدہ دیسی بیج اشتہارات کی منظوری دی گئی۔',
  },
];

export interface FraudAssessment {
  isSuspect: boolean;
  riskScore: number; // 0 to 100
  reasonsEn: string[];
  reasonsUr: string[];
}

class AdminService {
  /**
   * Checks if real Firebase configuration is present in environment variables.
   * Never hardcodes passwords or PINs in client HTML/JS.
   */
  isFirebaseConfigured(): boolean {
    const env = (import.meta as any).env || {};
    return Boolean(env.VITE_FIREBASE_PROJECT_ID && env.VITE_FIREBASE_API_KEY);
  }

  getSession(): AdminSession | null {
    try {
      const raw = sessionStorage.getItem(ADMIN_STORAGE_KEYS.ADMIN_SESSION);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as AdminSession;
      if (Date.now() > parsed.expiresAt || parsed.role !== 'admin') {
        sessionStorage.removeItem(ADMIN_STORAGE_KEYS.ADMIN_SESSION);
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  }

  /**
   * Starts an authorized Preview Demo Mode Admin Session using Web Crypto API
   * when Firebase is not yet provisioned, so no hardcoded password/PIN exists in HTML/JS.
   */
  async startDemoPreviewAdminSession(adminIdentifier: string): Promise<AdminSession> {
    const cleanEmail = adminIdentifier.trim() || 'admin-preview@desibeej.pk';
    const randomBytes = new Uint8Array(16);
    if (typeof window !== 'undefined' && window.crypto) {
      window.crypto.getRandomValues(randomBytes);
    }
    const tokenHex = Array.from(randomBytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');

    const session: AdminSession = {
      token: `ephemeral_demo_${tokenHex}`,
      email: cleanEmail,
      role: 'admin',
      mode: 'demo-preview',
      issuedAt: Date.now(),
      expiresAt: Date.now() + 1000 * 60 * 60 * 4, // 4 hours
    };

    try {
      sessionStorage.setItem(ADMIN_STORAGE_KEYS.ADMIN_SESSION, JSON.stringify(session));
    } catch {
      // ignore
    }

    this.logAction({
      adminEmail: session.email,
      authMode: session.mode,
      category: 'auth',
      actionEn: `Admin signed in via Preview Demo Session (${session.email})`,
      actionUr: `ایڈمن نے پریویو ڈیمو سیشن کے ذریعے لاگ ان کیا (${session.email})`,
    });

    return session;
  }

  logoutAdmin(): void {
    const current = this.getSession();
    if (current) {
      this.logAction({
        adminEmail: current.email,
        authMode: current.mode,
        category: 'auth',
        actionEn: `Admin signed out (${current.email})`,
        actionUr: `ایڈمن سیشن سے لاگ آؤٹ ہو گیا (${current.email})`,
      });
    }
    try {
      sessionStorage.removeItem(ADMIN_STORAGE_KEYS.ADMIN_SESSION);
    } catch {
      // ignore
    }
  }

  // =========================================================================
  // USERS / FARMERS MANAGEMENT (Block & Unblock)
  // =========================================================================
  getUsers(): SellerProfile[] {
    try {
      const raw = localStorage.getItem(ADMIN_STORAGE_KEYS.USERS);
      if (!raw) {
        localStorage.setItem(
          ADMIN_STORAGE_KEYS.USERS,
          JSON.stringify(INITIAL_USERS_WITH_STATUS)
        );
        return INITIAL_USERS_WITH_STATUS;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_USERS_WITH_STATUS;
    }
  }

  toggleBlockUser(userId: string): SellerProfile[] {
    const users = this.getUsers();
    let targetUser: SellerProfile | undefined;
    const updated = users.map((u) => {
      if (u.id === userId) {
        const nextStatus = u.status === 'blocked' ? 'active' : 'blocked';
        targetUser = { ...u, status: nextStatus };
        return targetUser;
      }
      return u;
    });

    try {
      localStorage.setItem(ADMIN_STORAGE_KEYS.USERS, JSON.stringify(updated));
    } catch {
      // ignore
    }

    if (targetUser) {
      const session = this.getSession();
      const isBlocked = targetUser.status === 'blocked';
      this.logAction({
        adminEmail: session?.email || 'admin@desibeej.pk',
        authMode: session?.mode || 'demo-preview',
        category: 'user_moderation',
        actionEn: `${isBlocked ? 'Blocked' : 'Unblocked'} user account "${targetUser.nameEn}" (${targetUser.city})`,
        actionUr: `صارف "${targetUser.nameUr}" (${targetUser.city}) کا اکاؤنٹ ${isBlocked ? 'بلاک ( معطل)' : 'ان بلاک (بحال)'} کیا گیا`,
        targetId: userId,
      });
    }

    return updated;
  }

  // =========================================================================
  // AUTOMATED FAKE / FRAUDULENT LISTING ANALYSIS
  // =========================================================================
  analyzeListingFraud(
    listing: SeedListing,
    reports: UserReport[]
  ): FraudAssessment {
    const reasonsEn: string[] = [];
    const reasonsUr: string[] = [];
    let score = 0;

    if (listing.isSuspectedFake) {
      score += 65;
      if (listing.fakeReasonEn) reasonsEn.push(listing.fakeReasonEn);
      if (listing.fakeReasonUr) reasonsUr.push(listing.fakeReasonUr);
    }

    const textCombined =
      `${listing.nameEn} ${listing.descriptionEn} ${listing.exchangeNotesEn}`.toLowerCase();

    if (
      textCombined.includes('advance payment') ||
      textCombined.includes('no inspection') ||
      textCombined.includes('gmo') ||
      textCombined.includes('miracle')
    ) {
      score += 45;
      reasonsEn.push(
        'Contains high-risk keywords ("advance payment", "no inspection", "GMO/miracle").'
      );
      reasonsUr.push(
        'اشتہار میں مشکوک الفاظ ("ایڈوانس رقم"، "بغیر معائنہ"، "جی ایم او") شامل ہیں۔'
      );
    }

    if (listing.category === 'wheat' && listing.pricePKR < 1200) {
      score += 35;
      reasonsEn.push(
        `Unrealistic low price for Wheat (${listing.pricePKR} PKR vs typical 4,500–6,000 PKR/Maund).`
      );
      reasonsUr.push(
        `گندم کی غیر فطری کم قیمت (${listing.pricePKR} روپے بمقابلہ مارکیٹ ریٹ 4500–6000 روپے)۔`
      );
    }

    const listingReports = reports.filter(
      (r) => r.targetSeedId === listing.id && r.status !== 'dismissed'
    );
    if (listingReports.length > 0) {
      score += listingReports.length * 30;
      reasonsEn.push(
        `Reported ${listingReports.length} time(s) by community farmers.`
      );
      reasonsUr.push(
        `اس اشتہار کے خلاف کسانوں کی جانب سے ${listingReports.length} شکایات موصول ہوئی ہیں۔`
      );
    }

    const cappedScore = Math.min(100, score);
    return {
      isSuspect: cappedScore >= 40 || Boolean(listing.isSuspectedFake),
      riskScore: cappedScore,
      reasonsEn,
      reasonsUr,
    };
  }

  // =========================================================================
  // COMPLAINTS & REPORTS SYSTEM
  // =========================================================================
  getReports(): UserReport[] {
    try {
      const raw = localStorage.getItem(ADMIN_STORAGE_KEYS.REPORTS);
      if (!raw) {
        localStorage.setItem(
          ADMIN_STORAGE_KEYS.REPORTS,
          JSON.stringify(INITIAL_REPORTS)
        );
        return INITIAL_REPORTS;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_REPORTS;
    }
  }

  submitReport(report: UserReport): UserReport[] {
    const current = this.getReports();
    const updated = [report, ...current];
    try {
      localStorage.setItem(ADMIN_STORAGE_KEYS.REPORTS, JSON.stringify(updated));
    } catch {
      // ignore
    }
    return updated;
  }

  updateReportStatus(
    reportId: string,
    status: ReportStatus,
    resolutionNote?: string
  ): UserReport[] {
    const current = this.getReports();
    let targetReport: UserReport | undefined;
    const session = this.getSession();

    const updated = current.map((r) => {
      if (r.id === reportId) {
        targetReport = {
          ...r,
          status,
          resolvedBy: session?.email || 'admin@desibeej.pk',
          resolutionNote: resolutionNote || r.resolutionNote,
        };
        return targetReport;
      }
      return r;
    });

    try {
      localStorage.setItem(ADMIN_STORAGE_KEYS.REPORTS, JSON.stringify(updated));
    } catch {
      // ignore
    }

    if (targetReport) {
      this.logAction({
        adminEmail: session?.email || 'admin@desibeej.pk',
        authMode: session?.mode || 'demo-preview',
        category: 'report_resolution',
        actionEn: `Updated complaint #${reportId} on "${targetReport.targetSeedNameEn}" to status: ${status.toUpperCase()}`,
        actionUr: `شکایت نمبر #${reportId} ("${targetReport.targetSeedNameUr}") کا اسٹیٹس تبدیل کر کے "${status}" کر دیا گیا`,
        targetId: reportId,
      });
    }

    return updated;
  }

  // =========================================================================
  // PLATFORM SETTINGS
  // =========================================================================
  getSettings(): PlatformSettings {
    try {
      const raw = localStorage.getItem(ADMIN_STORAGE_KEYS.PLATFORM_SETTINGS);
      if (!raw) {
        localStorage.setItem(
          ADMIN_STORAGE_KEYS.PLATFORM_SETTINGS,
          JSON.stringify(DEFAULT_PLATFORM_SETTINGS)
        );
        return DEFAULT_PLATFORM_SETTINGS;
      }
      return { ...DEFAULT_PLATFORM_SETTINGS, ...JSON.parse(raw) };
    } catch {
      return DEFAULT_PLATFORM_SETTINGS;
    }
  }

  saveSettings(settings: PlatformSettings): PlatformSettings {
    try {
      localStorage.setItem(
        ADMIN_STORAGE_KEYS.PLATFORM_SETTINGS,
        JSON.stringify(settings)
      );
    } catch {
      // ignore
    }
    const session = this.getSession();
    this.logAction({
      adminEmail: session?.email || 'admin@desibeej.pk',
      authMode: session?.mode || 'demo-preview',
      category: 'settings_update',
      actionEn: `Updated platform settings (Default Lang: ${settings.defaultLanguage.toUpperCase()}, Require Approval: ${settings.requireListingApproval})`,
      actionUr: `ایپ کی بنیادی سیٹنگز اور زبان (${settings.defaultLanguage === 'ur' ? 'اردو' : 'انگریزی'}) اپڈیٹ کی گئیں`,
    });
    return settings;
  }

  // =========================================================================
  // ADMIN ACTIVITY LOG (Append-Only Audit Trail)
  // =========================================================================
  getActivityLogs(): AdminActivityLog[] {
    try {
      const raw = localStorage.getItem(ADMIN_STORAGE_KEYS.ACTIVITY_LOGS);
      if (!raw) {
        localStorage.setItem(
          ADMIN_STORAGE_KEYS.ACTIVITY_LOGS,
          JSON.stringify(INITIAL_ACTIVITY_LOGS)
        );
        return INITIAL_ACTIVITY_LOGS;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_ACTIVITY_LOGS;
    }
  }

  logAction(params: {
    adminEmail: string;
    authMode: 'firebase-auth' | 'demo-preview';
    category: AdminActionCategory;
    actionEn: string;
    actionUr: string;
    targetId?: string;
  }): AdminActivityLog[] {
    const current = this.getActivityLogs();
    const now = new Date();
    const formattedTime = `${now.toISOString().split('T')[0]} ${now.toTimeString().split(' ')[0]}`;

    const entry: AdminActivityLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      timestamp: formattedTime,
      adminEmail: params.adminEmail,
      authMode: params.authMode,
      category: params.category,
      actionEn: params.actionEn,
      actionUr: params.actionUr,
      targetId: params.targetId,
    };

    const updated = [entry, ...current];
    try {
      localStorage.setItem(
        ADMIN_STORAGE_KEYS.ACTIVITY_LOGS,
        JSON.stringify(updated)
      );
    } catch {
      // ignore
    }
    return updated;
  }
}

export const adminService = new AdminService();
export { ADMIN_STORAGE_KEYS };
