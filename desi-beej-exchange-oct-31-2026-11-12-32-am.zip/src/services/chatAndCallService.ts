import { ChatConversation, ChatMessage } from '../types/seed';

const CHAT_STORAGE_KEYS = {
  CONVERSATIONS: 'desi_beej_chat_convos_v1',
  MESSAGES: 'desi_beej_chat_msgs_v1',
};

/**
 * Generates a small, valid playable WAV audio data URL (chime/tone)
 * so the initial demo voice message in the inbox can be played & paused immediately.
 */
function createDemoVoiceWavDataUrl(durationSec = 4): string {
  const sampleRate = 8000;
  const numSamples = sampleRate * durationSec;
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const freq = t < 1.5 ? 440 : t < 3.0 ? 523.25 : 659.25;
    const envelope = Math.sin(Math.PI * ((t % 1.5) / 1.5)) * 0.25;
    const sample = Math.max(-1, Math.min(1, Math.sin(2 * Math.PI * freq * t) * envelope));
    view.setInt16(44 + i * 2, sample * 32767, true);
  }

  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return `data:audio/wav;base64,${btoa(binary)}`;
}

export const INITIAL_CONVERSATIONS: ChatConversation[] = [
  {
    id: 'conv-seller-1',
    participantId: 'seller-1',
    participantNameEn: 'Haji Ghulam Mustafa',
    participantNameUr: 'حاجی غلام مصطفیٰ',
    participantFarmEn: 'Satluj Heritage Seed Dera',
    participantFarmUr: 'ستلج ہیریٹیج سیڈ ڈیرہ',
    participantCity: 'Sahiwal',
    participantPhone: '0300-6543210',
    relatedSeedId: 'seed-101',
    relatedSeedNameEn: 'Pure Sharbati Desi Wheat (C-591 Heirloom)',
    relatedSeedNameUr: 'خالص شربتی دیسی گندم (قدیمی بیج)',
    unreadCount: 1,
    updatedAt: '10:32 AM',
  },
  {
    id: 'conv-seller-2',
    participantId: 'seller-2',
    participantNameEn: 'Chaudhry Naseer Ahmed Virk',
    participantNameUr: 'چوہدری نصیر احمد ورک',
    participantFarmEn: 'Kalar Tract Basmati Collective',
    participantFarmUr: 'کلر ٹریکٹ باسمتی کلیکٹو',
    participantCity: 'Gujranwala',
    participantPhone: '0321-7788990',
    relatedSeedId: 'seed-102',
    relatedSeedNameEn: 'Kalar Tract Super Kernel Basmati Paddy',
    relatedSeedNameUr: 'کلر ٹریکٹ سپر کرنل باسمتی دھان',
    unreadCount: 0,
    updatedAt: 'Yesterday',
  },
  {
    id: 'conv-seller-4',
    participantId: 'seller-4',
    participantNameEn: 'Bibi Ruqayya Sultana & Sons',
    participantNameUr: 'بی بی رقیہ سلطانہ اینڈ سنز',
    participantFarmEn: 'Chenab Kitchen Garden & Heirloom Bagh',
    participantFarmUr: 'چناب کچن گارڈن اینڈ دیسی باغ',
    participantCity: 'Multan',
    participantPhone: '0333-6123456',
    relatedSeedId: 'seed-104',
    relatedSeedNameEn: 'Summer Desi Vegetable 4-Variety Heirloom Kit',
    relatedSeedNameUr: 'گرمیوں کی 4 دیسی سبزیوں کا خالص بیج پیک',
    unreadCount: 0,
    updatedAt: 'Oct 28',
  },
];

const DEMO_VOICE_URL = createDemoVoiceWavDataUrl(4);

export const INITIAL_MESSAGES: Record<string, ChatMessage[]> = {
  'conv-seller-1': [
    {
      id: 'msg-1',
      conversationId: 'conv-seller-1',
      senderId: 'seller-1',
      senderNameEn: 'Haji Ghulam Mustafa',
      senderNameUr: 'حاجی غلام مصطفیٰ',
      type: 'text',
      text: 'Assalam-o-Alaikum Kisan Bhai! Welcome to Satluj Heritage Seed Dera Sahiwal. Our C-591 Sharbati Desi Wheat seed is sun-dried and ready in 40 kg jute bags.',
      timestamp: '10:25 AM',
      status: 'read',
    },
    {
      id: 'msg-2',
      conversationId: 'conv-seller-1',
      senderId: 'seller-1',
      senderNameEn: 'Haji Ghulam Mustafa',
      senderNameUr: 'حاجی غلام مصطفیٰ',
      type: 'image',
      imageUrl: '/src/assets/images/seed_sharbati_wheat_1793414536309.jpg',
      text: 'Photo from our courtyard seed cleaning this morning (94% germination tested).',
      timestamp: '10:28 AM',
      status: 'read',
    },
    {
      id: 'msg-3',
      conversationId: 'conv-seller-1',
      senderId: 'seller-1',
      senderNameEn: 'Haji Ghulam Mustafa',
      senderNameUr: 'حاجی غلام مصطفیٰ',
      type: 'voice',
      audioDataUrl: DEMO_VOICE_URL,
      audioDurationSec: 4,
      text: 'Voice Note (Sample Audio)',
      timestamp: '10:32 AM',
      status: 'delivered',
    },
  ],
  'conv-seller-2': [
    {
      id: 'msg-201',
      conversationId: 'conv-seller-2',
      senderId: 'current-user',
      senderNameEn: 'You (Local Farmer)',
      senderNameUr: 'آپ (مقامی کسان)',
      type: 'text',
      text: 'Assalam-o-Alaikum Chaudhry Sahib, do you accept Desi Kala Chana in exchange for 2 bags of Kalar Basmati 370 seed?',
      timestamp: 'Yesterday, 4:15 PM',
      status: 'read',
    },
    {
      id: 'msg-202',
      conversationId: 'conv-seller-2',
      senderId: 'seller-2',
      senderNameEn: 'Chaudhry Naseer Ahmed Virk',
      senderNameUr: 'چوہدری نصیر احمد ورک',
      type: 'text',
      text: 'Walaikum Assalam! Yes, we gladly accept clean Thal Desi Kala Chana or Berseem seed at Kamoke Mandi.',
      timestamp: 'Yesterday, 4:40 PM',
      status: 'read',
    },
  ],
  'conv-seller-4': [
    {
      id: 'msg-401',
      conversationId: 'conv-seller-4',
      senderId: 'seller-4',
      senderNameEn: 'Bibi Ruqayya Sultana & Sons',
      senderNameUr: 'بی بی رقیہ سلطانہ اینڈ سنز',
      type: 'text',
      text: 'Assalam-o-Alaikum! Each vegetable kit contains 250g each of Multani Karela, 5-Dhari Bhindi, Nagina Tomato, and Kali Turi.',
      timestamp: 'Oct 28, 11:10 AM',
      status: 'read',
    },
  ],
};

/**
 * Signaling & Messaging Repository Pattern
 * - Persists local demo chat history in localStorage.
 * - Uses BroadcastChannel('desi_beej_realtime_v1') for real cross-tab messaging & WebRTC signaling on the same device.
 * - Exposes a clean adapter boundary for Firebase Firestore (`conversations/{id}/messages` & `calls/{id}/candidates`).
 */
class ChatAndCallService {
  private channel: BroadcastChannel | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      this.channel = new BroadcastChannel('desi_beej_realtime_v1');
    }
  }

  getChannel(): BroadcastChannel | null {
    return this.channel;
  }

  getConversations(): ChatConversation[] {
    try {
      const raw = localStorage.getItem(CHAT_STORAGE_KEYS.CONVERSATIONS);
      if (!raw) {
        localStorage.setItem(
          CHAT_STORAGE_KEYS.CONVERSATIONS,
          JSON.stringify(INITIAL_CONVERSATIONS)
        );
        return INITIAL_CONVERSATIONS;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_CONVERSATIONS;
    }
  }

  saveConversations(convos: ChatConversation[]): void {
    try {
      localStorage.setItem(CHAT_STORAGE_KEYS.CONVERSATIONS, JSON.stringify(convos));
    } catch {
      // ignore storage quota errors
    }
  }

  getMessagesMap(): Record<string, ChatMessage[]> {
    try {
      const raw = localStorage.getItem(CHAT_STORAGE_KEYS.MESSAGES);
      if (!raw) {
        localStorage.setItem(
          CHAT_STORAGE_KEYS.MESSAGES,
          JSON.stringify(INITIAL_MESSAGES)
        );
        return INITIAL_MESSAGES;
      }
      return JSON.parse(raw);
    } catch {
      return INITIAL_MESSAGES;
    }
  }

  getMessages(conversationId: string): ChatMessage[] {
    const map = this.getMessagesMap();
    return map[conversationId] || [];
  }

  appendMessage(conversationId: string, message: ChatMessage): ChatMessage[] {
    const map = this.getMessagesMap();
    const existing = map[conversationId] || [];
    if (existing.some((m) => m.id === message.id)) {
      return existing;
    }
    const updatedList = [...existing, message];
    map[conversationId] = updatedList;
    try {
      localStorage.setItem(CHAT_STORAGE_KEYS.MESSAGES, JSON.stringify(map));
    } catch {
      // ignore quota error on large base64 blobs
    }

    // Update conversation timestamp
    const convos = this.getConversations().map((c) =>
      c.id === conversationId
        ? { ...c, updatedAt: message.timestamp, unreadCount: 0 }
        : c
    );
    this.saveConversations(convos);

    // Broadcast to any other open browser tab
    this.channel?.postMessage({
      type: 'chat:new-message',
      conversationId,
      message,
    });

    return updatedList;
  }

  updateMessageStatus(
    conversationId: string,
    messageId: string,
    status: 'sent' | 'delivered' | 'read'
  ): ChatMessage[] {
    const map = this.getMessagesMap();
    const list = (map[conversationId] || []).map((m) =>
      m.id === messageId ? { ...m, status } : m
    );
    map[conversationId] = list;
    try {
      localStorage.setItem(CHAT_STORAGE_KEYS.MESSAGES, JSON.stringify(map));
    } catch {
      // ignore
    }
    return list;
  }

  ensureConversationForSeller(params: {
    sellerId: string;
    sellerNameEn: string;
    sellerNameUr: string;
    sellerFarmEn: string;
    sellerFarmUr: string;
    city: string;
    phone: string;
    seedId?: string;
    seedNameEn?: string;
    seedNameUr?: string;
  }): ChatConversation {
    const convos = this.getConversations();
    const convId = `conv-${params.sellerId}`;
    const existing = convos.find((c) => c.id === convId);
    if (existing) {
      const updated = convos.map((c) =>
        c.id === convId
          ? {
              ...c,
              relatedSeedId: params.seedId || c.relatedSeedId,
              relatedSeedNameEn: params.seedNameEn || c.relatedSeedNameEn,
              relatedSeedNameUr: params.seedNameUr || c.relatedSeedNameUr,
              unreadCount: 0,
            }
          : c
      );
      this.saveConversations(updated);
      return updated.find((c) => c.id === convId)!;
    }

    const newConvo: ChatConversation = {
      id: convId,
      participantId: params.sellerId,
      participantNameEn: params.sellerNameEn,
      participantNameUr: params.sellerNameUr,
      participantFarmEn: params.sellerFarmEn,
      participantFarmUr: params.sellerFarmUr,
      participantCity: params.city,
      participantPhone: params.phone,
      relatedSeedId: params.seedId,
      relatedSeedNameEn: params.seedNameEn,
      relatedSeedNameUr: params.seedNameUr,
      unreadCount: 0,
      updatedAt: 'Just now',
    };

    const updatedConvos = [newConvo, ...convos];
    this.saveConversations(updatedConvos);
    return newConvo;
  }
}

export const chatAndCallService = new ChatAndCallService();
