import { Language, SeedListing, StructuredLocation } from '../types/seed';

export interface LocationSuggestion {
  id: string;
  primaryText: string;
  secondaryText: string;
  structured: StructuredLocation;
}

export class GeolocationError extends Error {
  code: 'PERMISSION_DENIED' | 'POSITION_UNAVAILABLE' | 'TIMEOUT' | 'UNSUPPORTED';
  messageEn: string;
  messageUr: string;

  constructor(
    code: 'PERMISSION_DENIED' | 'POSITION_UNAVAILABLE' | 'TIMEOUT' | 'UNSUPPORTED',
    messageEn: string,
    messageUr: string
  ) {
    super(messageEn);
    this.code = code;
    this.messageEn = messageEn;
    this.messageUr = messageUr;
  }
}

// Real geographical reference coordinates for existing seed districts in Pakistan
const DISTRICT_COORDINATES: Record<
  string,
  { lat: number; lng: number; stateEn: string; stateUr: string }
> = {
  multan: { lat: 30.1575, lng: 71.5249, stateEn: 'Punjab', stateUr: 'پنجاب' },
  faisalabad: { lat: 31.4504, lng: 73.135, stateEn: 'Punjab', stateUr: 'پنجاب' },
  sahiwal: { lat: 30.6682, lng: 73.1114, stateEn: 'Punjab', stateUr: 'پنجاب' },
  gujranwala: { lat: 32.1877, lng: 74.1945, stateEn: 'Punjab', stateUr: 'پنجاب' },
  bahawalpur: { lat: 29.3544, lng: 71.6911, stateEn: 'Punjab', stateUr: 'پنجاب' },
  okara: { lat: 30.8138, lng: 73.4534, stateEn: 'Punjab', stateUr: 'پنجاب' },
  hyderabad: { lat: 25.396, lng: 68.3578, stateEn: 'Sindh', stateUr: 'سندھ' },
  lahore: { lat: 31.5204, lng: 74.3587, stateEn: 'Punjab', stateUr: 'پنجاب' },
  peshawar: {
    lat: 34.0151,
    lng: 71.5249,
    stateEn: 'Khyber Pakhtunkhwa',
    stateUr: 'خیبر پختونخوا',
  },
  sukkur: { lat: 27.7244, lng: 68.8228, stateEn: 'Sindh', stateUr: 'سندھ' },
};

function getGoogleMapsApiKey(): string {
  const key = (import.meta as any).env?.VITE_GOOGLE_MAPS_API_KEY;
  return typeof key === 'string' ? key.trim() : '';
}

/**
 * Extracts Country, State/Province, City, Area/Village, and Full Address
 * from an OpenStreetMap Nominatim address object.
 */
function parseNominatimRecord(
  item: any,
  source: 'gps' | 'autocomplete'
): StructuredLocation {
  const addr = item.address || {};

  const country =
    addr.country ||
    '';

  const state =
    addr.state ||
    addr.province ||
    addr.region ||
    addr.state_district ||
    '';

  const city =
    addr.city ||
    addr.town ||
    addr.municipality ||
    addr.county ||
    addr.district ||
    addr.village ||
    item.name ||
    '';

  const area =
    addr.suburb ||
    addr.neighbourhood ||
    addr.quarter ||
    addr.hamlet ||
    (addr.village && addr.village !== city ? addr.village : '') ||
    addr.city_district ||
    addr.road ||
    '';

  const displayAddress = item.display_name || '';
  const roadPart = [addr.house_number, addr.road, area]
    .filter(Boolean)
    .join(', ');

  const address = roadPart || displayAddress;

  const lat = item.lat !== undefined ? Number(item.lat) : undefined;
  const lon = item.lon !== undefined ? Number(item.lon) : undefined;

  return {
    country: country.trim(),
    state: state.trim(),
    city: city.trim(),
    area: area.trim(),
    address: address.trim(),
    latitude: Number.isFinite(lat) ? lat : undefined,
    longitude: Number.isFinite(lon) ? lon : undefined,
    source,
    formattedAddress: displayAddress.trim(),
  };
}

/**
 * Extracts structured fields from a Photon (Komoot OpenStreetMap) GeoJSON feature.
 */
function parsePhotonFeature(feature: any): LocationSuggestion | null {
  const props = feature?.properties;
  const coords = feature?.geometry?.coordinates;
  if (!props) return null;

  const country = props.country || '';
  const state = props.state || props.county || '';
  const city = props.city || props.town || props.locality || props.name || '';
  const area =
    props.district ||
    props.suburb ||
    (props.name && props.name !== city ? props.name : '') ||
    props.street ||
    '';

  const addressParts = [
    props.housenumber,
    props.street,
    area,
    city,
    state,
    country,
  ].filter(Boolean);
  const fullAddress = addressParts.join(', ');

  const lng = Array.isArray(coords) ? Number(coords[0]) : undefined;
  const lat = Array.isArray(coords) ? Number(coords[1]) : undefined;

  const primaryText = props.name || area || city || fullAddress;
  const secondaryText = [area !== primaryText ? area : '', city !== primaryText ? city : '', state, country]
    .filter(Boolean)
    .join(', ');

  return {
    id: `photon-${props.osm_id || Math.random().toString(36).slice(2)}`,
    primaryText,
    secondaryText,
    structured: {
      country,
      state,
      city,
      area,
      address: fullAddress || primaryText,
      latitude: Number.isFinite(lat) ? lat : undefined,
      longitude: Number.isFinite(lng) ? lng : undefined,
      source: 'autocomplete',
      formattedAddress: fullAddress || primaryText,
    },
  };
}

/**
 * Parses Google Geocoding API results if VITE_GOOGLE_MAPS_API_KEY is configured.
 */
function parseGoogleGeocodeResult(
  result: any,
  source: 'gps' | 'autocomplete'
): StructuredLocation {
  const components: any[] = result.address_components || [];
  const getComponent = (types: string[]) => {
    const found = components.find((c) =>
      types.some((t) => Array.isArray(c.types) && c.types.includes(t))
    );
    return found ? found.long_name : '';
  };

  const country = getComponent(['country']);
  const state = getComponent(['administrative_area_level_1']);
  const city =
    getComponent(['locality', 'postal_town']) ||
    getComponent(['administrative_area_level_2']);
  const area =
    getComponent([
      'sublocality_level_1',
      'sublocality',
      'neighborhood',
      'administrative_area_level_3',
    ]) || getComponent(['route']);

  const formattedAddress = result.formatted_address || '';
  const loc = result.geometry?.location;
  const lat = typeof loc?.lat === 'number' ? loc.lat : undefined;
  const lng = typeof loc?.lng === 'number' ? loc.lng : undefined;

  return {
    country,
    state,
    city,
    area,
    address: formattedAddress,
    latitude: lat,
    longitude: lng,
    source,
    formattedAddress,
  };
}

export const locationService = {
  /**
   * Searches worldwide addresses, countries, states, cities, villages, and streets
   * in real time using OpenStreetMap Nominatim (with Photon backup and optional Google Maps key).
   */
  async searchLocations(
    query: string,
    lang: Language,
    signal?: AbortSignal
  ): Promise<LocationSuggestion[]> {
    const trimmed = query.trim();
    if (trimmed.length < 2) return [];

    const acceptLang = lang === 'ur' ? 'ur,en;q=0.9' : 'en,ur;q=0.8';
    const googleKey = getGoogleMapsApiKey();

    // 1. If optional Google Maps API Key is configured, try Google Geocoding first
    if (googleKey) {
      try {
        const gUrl = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
          trimmed
        )}&language=${lang}&key=${encodeURIComponent(googleKey)}`;
        const gRes = await fetch(gUrl, { signal });
        if (gRes.ok) {
          const gData = await gRes.json();
          if (gData.status === 'OK' && Array.isArray(gData.results) && gData.results.length > 0) {
            return gData.results.slice(0, 7).map((item: any, idx: number) => {
              const structured = parseGoogleGeocodeResult(item, 'autocomplete');
              const primaryText =
                structured.area ||
                structured.city ||
                structured.state ||
                structured.country ||
                structured.address;
              const secondaryText = [
                structured.city !== primaryText ? structured.city : '',
                structured.state,
                structured.country,
              ]
                .filter(Boolean)
                .join(', ');
              return {
                id: item.place_id || `g-${idx}`,
                primaryText,
                secondaryText: secondaryText || structured.address,
                structured,
              };
            });
          }
        }
      } catch (err: any) {
        if (err?.name === 'AbortError') throw err;
        // Fall through to OpenStreetMap Nominatim
      }
    }

    // 2. Primary Free Live Global Geocoder: OpenStreetMap Nominatim
    try {
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=8&q=${encodeURIComponent(
        trimmed
      )}`;
      const res = await fetch(url, {
        signal,
        headers: {
          'Accept-Language': acceptLang,
        },
      });

      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          return data.map((item: any) => {
            const structured = parseNominatimRecord(item, 'autocomplete');
            const primaryText =
              item.name ||
              structured.area ||
              structured.city ||
              structured.state ||
              structured.country ||
              (item.display_name ? item.display_name.split(',')[0] : trimmed);
            const secondaryText = [
              structured.area && structured.area !== primaryText ? structured.area : '',
              structured.city && structured.city !== primaryText ? structured.city : '',
              structured.state && structured.state !== primaryText ? structured.state : '',
              structured.country && structured.country !== primaryText ? structured.country : '',
            ]
              .filter(Boolean)
              .join(', ');

            return {
              id: `nom-${item.place_id}`,
              primaryText,
              secondaryText: secondaryText || item.display_name || '',
              structured,
            };
          });
        }
      }
    } catch (err: any) {
      if (err?.name === 'AbortError') throw err;
    }

    // 3. Secondary Live OpenStreetMap Backup: Photon API
    try {
      const photonUrl = `https://photon.komoot.io/api/?q=${encodeURIComponent(
        trimmed
      )}&limit=8`;
      const pRes = await fetch(photonUrl, { signal });
      if (pRes.ok) {
        const pData = await pRes.json();
        if (Array.isArray(pData?.features)) {
          return pData.features
            .map(parsePhotonFeature)
            .filter((x: LocationSuggestion | null): x is LocationSuggestion => Boolean(x));
        }
      }
    } catch (err: any) {
      if (err?.name === 'AbortError') throw err;
    }

    return [];
  },

  /**
   * Reverse geocodes real GPS coordinates (latitude, longitude) into
   * Country, State/Province, City, Area, and Full Address.
   */
  async reverseGeocode(
    latitude: number,
    longitude: number,
    lang: Language
  ): Promise<StructuredLocation> {
    const acceptLang = lang === 'ur' ? 'ur,en;q=0.9' : 'en,ur;q=0.8';
    const googleKey = getGoogleMapsApiKey();

    if (googleKey) {
      try {
        const gUrl = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&language=${lang}&key=${encodeURIComponent(
          googleKey
        )}`;
        const gRes = await fetch(gUrl);
        if (gRes.ok) {
          const gData = await gRes.json();
          if (gData.status === 'OK' && Array.isArray(gData.results) && gData.results.length > 0) {
            return parseGoogleGeocodeResult(gData.results[0], 'gps');
          }
        }
      } catch {
        // Fall through to OpenStreetMap Nominatim
      }
    }

    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&lat=${encodeURIComponent(
      latitude
    )}&lon=${encodeURIComponent(longitude)}&zoom=18`;

    const res = await fetch(url, {
      headers: {
        'Accept-Language': acceptLang,
      },
    });

    if (!res.ok) {
      throw new Error('Reverse geocoding service unavailable');
    }

    const data = await res.json();
    const parsed = parseNominatimRecord(data, 'gps');
    return {
      ...parsed,
      latitude,
      longitude,
      source: 'gps',
    };
  },

  /**
   * Requests browser GPS permission and returns the user's real structured location.
   * Never returns fake locations; throws GeolocationError if denied or unavailable.
   */
  async detectCurrentLocation(lang: Language): Promise<StructuredLocation> {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      throw new GeolocationError(
        'UNSUPPORTED',
        'GPS Geolocation is not supported by this browser. Please enter your address manually.',
        'آپ کا براؤزر GPS لوکیشن کو سپورٹ نہیں کرتا۔ براہِ کرم اپنا پتہ دستی طور پر درج کریں۔'
      );
    }

    const position = await new Promise<GeolocationPosition>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 12000,
        maximumAge: 0,
      });
    }).catch((err: GeolocationPositionError) => {
      if (err.code === 1) {
        throw new GeolocationError(
          'PERMISSION_DENIED',
          'Location permission was denied. Please allow GPS access in your browser settings or type your address manually below.',
          'لوکیشن کی اجازت نہیں ملی۔ براہِ کرم براؤزر میں GPS کی اجازت دیں یا نیچے دستی طور پر اپنا پتہ لکھیں۔'
        );
      }
      if (err.code === 2) {
        throw new GeolocationError(
          'POSITION_UNAVAILABLE',
          'GPS signal is currently unavailable on this device. Please search or enter your address manually.',
          'اس وقت GPS سگنل دستیاب نہیں ہے۔ براہِ کرم سرچ باکس یا دستی خانوں میں اپنا پتہ درج کریں۔'
        );
      }
      throw new GeolocationError(
        'TIMEOUT',
        'Location detection timed out. Please try again or enter your address manually.',
        'لوکیشن معلوم کرنے کا وقت ختم ہو گیا۔ دوبارہ کوشش کریں یا دستی طور پر پتہ لکھیں۔'
      );
    });

    const { latitude, longitude } = position.coords;

    try {
      return await this.reverseGeocode(latitude, longitude, lang);
    } catch {
      // Even if reverse geocoding network call fails, return the real GPS coordinates so user can fill text fields
      return {
        country: '',
        state: '',
        city: '',
        area: '',
        address: `GPS (${latitude.toFixed(5)}, ${longitude.toFixed(5)})`,
        latitude,
        longitude,
        source: 'gps',
      };
    }
  },

  /**
   * Resolves a complete StructuredLocation for any SeedListing (including legacy listings).
   */
  resolveSeedStructuredLocation(seed: SeedListing, lang: Language = 'en'): StructuredLocation {
    if (seed.structuredLocation && (seed.structuredLocation.city || seed.structuredLocation.country)) {
      return seed.structuredLocation;
    }

    const cityKey = (seed.city || '').trim().toLowerCase();
    const ref = DISTRICT_COORDINATES[cityKey];
    const rawAddr = lang === 'ur' ? seed.locationUr || seed.locationEn : seed.locationEn;
    const areaPart = rawAddr ? rawAddr.split(',')[0].trim() : '';

    return {
      country: lang === 'ur' ? 'پاکستان' : 'Pakistan',
      state: ref ? (lang === 'ur' ? ref.stateUr : ref.stateEn) : lang === 'ur' ? 'پنجاب' : 'Punjab',
      city: seed.city || '',
      area: areaPart,
      address: rawAddr || seed.city || '',
      latitude: ref?.lat,
      longitude: ref?.lng,
      source: 'manual',
    };
  },

  /**
   * Formats a clean display string from a StructuredLocation.
   */
  formatDisplayLocation(loc: StructuredLocation): string {
    const parts = [loc.area, loc.city, loc.state, loc.country]
      .map((p) => (p || '').trim())
      .filter(Boolean);
    const uniqueParts = parts.filter((item, idx) => parts.indexOf(item) === idx);
    if (uniqueParts.length > 0) {
      return uniqueParts.join(', ');
    }
    return loc.address || '';
  },

  /**
   * Calculates real great-circle distance in kilometers between two GPS coordinates.
   */
  calculateDistanceKm(
    lat1?: number,
    lon1?: number,
    lat2?: number,
    lon2?: number
  ): number | null {
    if (
      typeof lat1 !== 'number' ||
      typeof lon1 !== 'number' ||
      typeof lat2 !== 'number' ||
      typeof lon2 !== 'number'
    ) {
      return null;
    }
    const R = 6371; // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c);
  },
};
