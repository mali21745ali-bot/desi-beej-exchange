import {
  SeedListing,
  SeedInquiry,
  SellerProfile,
  ListingApprovalStatus,
} from '../types/seed';
import { INITIAL_SEED_LISTINGS } from '../data/initialSeeds';
import { adminService, SUSPECT_FAKE_DEMO_LISTING } from './adminService';

const STORAGE_KEYS = {
  LISTINGS: 'desi_beej_listings_v2',
  FAVORITES: 'desi_beej_favorites_v1',
  INQUIRIES: 'desi_beej_inquiries_v1',
  LANGUAGE: 'desi_beej_lang_v1',
};

const SEEDED_INITIAL_LISTINGS: SeedListing[] = [
  ...INITIAL_SEED_LISTINGS.map((item) => ({
    ...item,
    approvalStatus: 'approved' as ListingApprovalStatus,
    isSuspectedFake: false,
  })),
  SUSPECT_FAKE_DEMO_LISTING,
];

export interface ISeedRepository {
  getAllListings(): SeedListing[];
  getPublicListings(): SeedListing[];
  saveListing(listing: SeedListing): SeedListing[];
  updateListingApproval(
    seedId: string,
    status: ListingApprovalStatus
  ): SeedListing[];
  updateListingFakeFlag(
    seedId: string,
    isSuspectedFake: boolean,
    reasonEn?: string,
    reasonUr?: string
  ): SeedListing[];
  deleteListing(id: string, isAdminAction?: boolean): SeedListing[];
  resetDemoListings(): SeedListing[];
  getFavorites(): string[];
  toggleFavorite(seedId: string): string[];
  getInquiries(): SeedInquiry[];
  addInquiry(inquiry: SeedInquiry): SeedInquiry[];
  getSellers(): SellerProfile[];
}

class LocalStorageSeedRepository implements ISeedRepository {
  getAllListings(): SeedListing[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.LISTINGS);
      if (!raw) {
        localStorage.setItem(
          STORAGE_KEYS.LISTINGS,
          JSON.stringify(SEEDED_INITIAL_LISTINGS)
        );
        return SEEDED_INITIAL_LISTINGS;
      }
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length === 0) {
        return SEEDED_INITIAL_LISTINGS;
      }
      return parsed;
    } catch {
      return SEEDED_INITIAL_LISTINGS;
    }
  }

  /**
   * Returns only approved, non-fake listings from active (non-blocked) sellers
   * for public marketplace visitors.
   */
  getPublicListings(): SeedListing[] {
    const all = this.getAllListings();
    const users = adminService.getUsers();
    const blockedSellerIds = new Set(
      users.filter((u) => u.status === 'blocked').map((u) => u.id)
    );

    return all.filter((seed) => {
      if (blockedSellerIds.has(seed.sellerId)) return false;
      if (seed.approvalStatus === 'rejected') return false;
      if (seed.isSuspectedFake && seed.approvalStatus !== 'approved') return false;
      return true;
    });
  }

  saveListing(listing: SeedListing): SeedListing[] {
    const current = this.getAllListings();
    const settings = adminService.getSettings();
    const defaultStatus: ListingApprovalStatus = settings.requireListingApproval
      ? 'pending'
      : listing.approvalStatus || 'approved';

    const normalizedListing: SeedListing = {
      ...listing,
      approvalStatus: defaultStatus,
    };

    const existingIndex = current.findIndex(
      (item) => item.id === normalizedListing.id
    );
    let updated: SeedListing[];
    if (existingIndex >= 0) {
      updated = [...current];
      updated[existingIndex] = normalizedListing;
    } else {
      updated = [normalizedListing, ...current];
    }
    try {
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(updated));
    } catch {
      // ignore quota errors
    }
    return updated;
  }

  updateListingApproval(
    seedId: string,
    status: ListingApprovalStatus
  ): SeedListing[] {
    const current = this.getAllListings();
    let targetSeed: SeedListing | undefined;
    const updated = current.map((item) => {
      if (item.id === seedId) {
        targetSeed = {
          ...item,
          approvalStatus: status,
          isSuspectedFake: status === 'approved' ? false : item.isSuspectedFake,
        };
        return targetSeed;
      }
      return item;
    });

    try {
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(updated));
    } catch {
      // ignore
    }

    if (targetSeed) {
      const session = adminService.getSession();
      adminService.logAction({
        adminEmail: session?.email || 'admin@desibeej.pk',
        authMode: session?.mode || 'demo-preview',
        category: 'listing_moderation',
        actionEn: `Changed listing "${targetSeed.nameEn}" (#${seedId}) approval status to ${status.toUpperCase()}`,
        actionUr: `بیج اشتہار "${targetSeed.nameUr}" (#${seedId}) کو ${status === 'approved' ? 'منظور (Approved)' : status === 'rejected' ? 'مسترد (Rejected)' : 'زیرِ التواء'} کر دیا گیا`,
        targetId: seedId,
      });
    }

    return updated;
  }

  updateListingFakeFlag(
    seedId: string,
    isSuspectedFake: boolean,
    reasonEn?: string,
    reasonUr?: string
  ): SeedListing[] {
    const current = this.getAllListings();
    let targetSeed: SeedListing | undefined;
    const updated = current.map((item) => {
      if (item.id === seedId) {
        targetSeed = {
          ...item,
          isSuspectedFake,
          approvalStatus: isSuspectedFake ? 'rejected' : 'approved',
          fakeReasonEn: isSuspectedFake ? reasonEn || item.fakeReasonEn : undefined,
          fakeReasonUr: isSuspectedFake ? reasonUr || item.fakeReasonUr : undefined,
        };
        return targetSeed;
      }
      return item;
    });

    try {
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(updated));
    } catch {
      // ignore
    }

    if (targetSeed) {
      const session = adminService.getSession();
      adminService.logAction({
        adminEmail: session?.email || 'admin@desibeej.pk',
        authMode: session?.mode || 'demo-preview',
        category: 'fraud_action',
        actionEn: isSuspectedFake
          ? `Flagged & rejected fake listing "${targetSeed.nameEn}" (#${seedId})`
          : `Cleared fake flag & verified listing "${targetSeed.nameEn}" (#${seedId})`,
        actionUr: isSuspectedFake
          ? `جعلی اشتہار "${targetSeed.nameUr}" (#${seedId}) کی شناخت کر کے اسے مسترد کر دیا گیا`
          : `اشتہار "${targetSeed.nameUr}" (#${seedId}) کی تصدیق کر کے جعلی نشان ہٹا دیا گیا`,
        targetId: seedId,
      });
    }

    return updated;
  }

  deleteListing(id: string, isAdminAction = false): SeedListing[] {
    const current = this.getAllListings();
    const target = current.find((item) => item.id === id);
    const updated = current.filter((item) => item.id !== id);
    try {
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(updated));
    } catch {
      // ignore
    }

    if (isAdminAction && target) {
      const session = adminService.getSession();
      adminService.logAction({
        adminEmail: session?.email || 'admin@desibeej.pk',
        authMode: session?.mode || 'demo-preview',
        category: 'listing_moderation',
        actionEn: `Permanently deleted seed listing "${target.nameEn}" (#${id})`,
        actionUr: `بیج کا اشتہار "${target.nameUr}" (#${id}) مستقل طور پر حذف کر دیا گیا`,
        targetId: id,
      });
    }

    return updated;
  }

  resetDemoListings(): SeedListing[] {
    try {
      localStorage.setItem(
        STORAGE_KEYS.LISTINGS,
        JSON.stringify(SEEDED_INITIAL_LISTINGS)
      );
    } catch {
      // ignore
    }
    return SEEDED_INITIAL_LISTINGS;
  }

  getFavorites(): string[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
      return raw ? JSON.parse(raw) : ['seed-101', 'seed-104'];
    } catch {
      return ['seed-101', 'seed-104'];
    }
  }

  toggleFavorite(seedId: string): string[] {
    const current = this.getFavorites();
    const exists = current.includes(seedId);
    const updated = exists
      ? current.filter((id) => id !== seedId)
      : [...current, seedId];
    try {
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(updated));
    } catch {
      // ignore
    }
    return updated;
  }

  getInquiries(): SeedInquiry[] {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.INQUIRIES);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  addInquiry(inquiry: SeedInquiry): SeedInquiry[] {
    const current = this.getInquiries();
    const updated = [inquiry, ...current];
    try {
      localStorage.setItem(STORAGE_KEYS.INQUIRIES, JSON.stringify(updated));
    } catch {
      // ignore
    }
    return updated;
  }

  getSellers(): SellerProfile[] {
    return adminService.getUsers().filter((u) => u.status !== 'blocked');
  }
}

export const seedRepository = new LocalStorageSeedRepository();
export { STORAGE_KEYS };
