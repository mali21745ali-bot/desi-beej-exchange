/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  SlidersHorizontal,
  Globe,
  RotateCcw,
  Heart,
  Menu,
  X,
  MessageSquare,
  BookOpen,
  ShieldCheck,
} from 'lucide-react';
import {
  Language,
  SeedCategory,
  SeedListing,
  SeedInquiry,
  ExchangeType,
  SellerProfile,
  UserReport,
  AdminActivityLog,
  PlatformSettings,
  AdminSession,
  ListingApprovalStatus,
  StructuredLocation,
} from './types/seed';
import {
  CATEGORY_LABELS,
  EXCHANGE_LABELS,
  UI_TEXT,
  formatPKR,
} from './i18n/translations';
import { HERO_IMAGE_PATH } from './data/initialSeeds';
import { seedRepository, STORAGE_KEYS } from './services/seedRepository';
import { chatAndCallService } from './services/chatAndCallService';
import { adminService } from './services/adminService';
import { locationService } from './services/locationService';
import { SeedCard } from './components/SeedCard';
import { SeedDetailView } from './components/SeedDetailView';
import { AddSeedModal } from './components/AddSeedModal';
import { SellerDirectoryView } from './components/SellerDirectoryView';
import { UserDashboardView } from './components/UserDashboardView';
import { FarmerChatView } from './components/FarmerChatView';
import { PopularCropsView } from './components/PopularCropsView';
import { AdminPanelView } from './components/AdminPanelView';
import { SeedImage } from './components/SeedImage';
import { CatalogLocationFilterBar } from './components/CatalogLocationFilterBar';
import { SideNavigationDrawer } from './components/SideNavigationDrawer';

type ActivePage =
  | 'catalog'
  | 'crops'
  | 'chat'
  | 'saved'
  | 'sellers'
  | 'dashboard'
  | 'detail'
  | 'admin';

export default function App() {
  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>(() =>
    adminService.getSettings()
  );

  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.LANGUAGE);
      if (saved === 'ur' || saved === 'en') return saved;
      return adminService.getSettings().defaultLanguage || 'en';
    } catch {
      return 'en';
    }
  });

  // Admin & Moderation State
  const [adminSession, setAdminSession] = useState<AdminSession | null>(() =>
    adminService.getSession()
  );
  const [allListings, setAllListings] = useState<SeedListing[]>(() =>
    seedRepository.getAllListings()
  );
  const [users, setUsers] = useState<SellerProfile[]>(() =>
    adminService.getUsers()
  );
  const [reports, setReports] = useState<UserReport[]>(() =>
    adminService.getReports()
  );
  const [activityLogs, setActivityLogs] = useState<AdminActivityLog[]>(() =>
    adminService.getActivityLogs()
  );

  const [favorites, setFavorites] = useState<string[]>(() =>
    seedRepository.getFavorites()
  );
  const [inquiries, setInquiries] = useState<SeedInquiry[]>(() =>
    seedRepository.getInquiries()
  );

  // Public listings exclude rejected listings, unapproved fake listings, and listings by blocked sellers
  const publicListings = useMemo(() => {
    const blockedSellerIds = new Set(
      users.filter((u) => u.status === 'blocked').map((u) => u.id)
    );
    return allListings.filter((seed) => {
      if (blockedSellerIds.has(seed.sellerId)) return false;
      if (seed.approvalStatus === 'rejected') return false;
      if (seed.isSuspectedFake && seed.approvalStatus !== 'approved') return false;
      return true;
    });
  }, [allListings, users]);

  const activeSellers = useMemo(
    () => users.filter((u) => u.status !== 'blocked'),
    [users]
  );

  // Navigation & Modal State
  const [activePage, setActivePage] = useState<ActivePage>('catalog');
  const [selectedSeedId, setSelectedSeedId] = useState<string | null>(null);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);
  const [activeChatConvId, setActiveChatConvId] = useState<string | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingListing, setEditingListing] = useState<SeedListing | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<SeedCategory | 'all'>('all');
  const [selectedCity, setSelectedCity] = useState<string>('all');
  const [activeFilterLocation, setActiveFilterLocation] =
    useState<StructuredLocation | null>(null);
  const [maxPrice, setMaxPrice] = useState<number>(10000);
  const [exchangeMode, setExchangeMode] = useState<ExchangeType | 'all'>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'newest'>(
    'featured'
  );

  // Distinct active cities across all current public listings
  const availableListingCities = useMemo(() => {
    const set = new Set<string>();
    publicListings.forEach((item) => {
      if (item.city && item.city.trim()) {
        set.add(item.city.trim());
      }
    });
    return Array.from(set);
  }, [publicListings]);

  // Sync RTL / LTR direction on document root
  useEffect(() => {
    const dir = lang === 'ur' ? 'rtl' : 'ltr';
    document.documentElement.setAttribute('dir', dir);
    document.documentElement.setAttribute('lang', lang);
    try {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    } catch {
      // ignore
    }
  }, [lang]);

  const t = UI_TEXT[lang];
  const appBrandTitle =
    lang === 'ur'
      ? platformSettings.appNameUr || t.brandName
      : platformSettings.appNameEn || t.brandName;

  // Filtered and sorted public listings
  const filteredListings = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const locTerm = selectedCity.trim().toLowerCase();

    const matchesLocationFilter = (seed: SeedListing) => {
      if (selectedCity === 'all' || !locTerm) return true;
      const resolved = locationService.resolveSeedStructuredLocation(seed, lang);
      const haystack = [
        seed.city,
        seed.locationEn,
        seed.locationUr,
        resolved.country,
        resolved.state,
        resolved.city,
        resolved.area,
        resolved.address,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      if (haystack.includes(locTerm)) return true;

      if (activeFilterLocation) {
        const cityMatch =
          activeFilterLocation.city &&
          haystack.includes(activeFilterLocation.city.toLowerCase());
        const areaMatch =
          activeFilterLocation.area &&
          haystack.includes(activeFilterLocation.area.toLowerCase());
        if (cityMatch || areaMatch) return true;
      }

      return false;
    };

    // Check if any seed matches the text location filter; if user used GPS and 0 exact city matches exist,
    // show all listings sorted by GPS proximity so GPS detection is always helpful.
    const hasExactLocMatches =
      selectedCity === 'all' || publicListings.some(matchesLocationFilter);

    const filtered = publicListings.filter((seed) => {
      if (selectedCategory !== 'all' && seed.category !== selectedCategory) {
        return false;
      }
      if (
        selectedCity !== 'all' &&
        (hasExactLocMatches || activeFilterLocation?.source !== 'gps') &&
        !matchesLocationFilter(seed)
      ) {
        return false;
      }
      if (seed.pricePKR > maxPrice) {
        return false;
      }
      if (exchangeMode !== 'all' && seed.exchangeType !== exchangeMode) {
        return false;
      }
      if (q) {
        const resolved = locationService.resolveSeedStructuredLocation(seed, lang);
        const matchesNameEn = seed.nameEn.toLowerCase().includes(q);
        const matchesNameUr = (seed.nameUr || '').toLowerCase().includes(q);
        const matchesCity = seed.city.toLowerCase().includes(q);
        const matchesLocation =
          seed.locationEn.toLowerCase().includes(q) ||
          (resolved.country || '').toLowerCase().includes(q) ||
          (resolved.state || '').toLowerCase().includes(q) ||
          (resolved.area || '').toLowerCase().includes(q);
        const matchesDesc = seed.descriptionEn.toLowerCase().includes(q);
        const matchesSeller = seed.sellerNameEn.toLowerCase().includes(q);
        return (
          matchesNameEn ||
          matchesNameUr ||
          matchesCity ||
          matchesLocation ||
          matchesDesc ||
          matchesSeller
        );
      }
      return true;
    });

    if (
      activeFilterLocation &&
      typeof activeFilterLocation.latitude === 'number' &&
      typeof activeFilterLocation.longitude === 'number' &&
      sortBy === 'featured'
    ) {
      return [...filtered].sort((a, b) => {
        const locA = locationService.resolveSeedStructuredLocation(a, lang);
        const locB = locationService.resolveSeedStructuredLocation(b, lang);
        const distA =
          locationService.calculateDistanceKm(
            activeFilterLocation.latitude,
            activeFilterLocation.longitude,
            locA.latitude,
            locA.longitude
          ) ?? 999999;
        const distB =
          locationService.calculateDistanceKm(
            activeFilterLocation.latitude,
            activeFilterLocation.longitude,
            locB.latitude,
            locB.longitude
          ) ?? 999999;
        return distA - distB;
      });
    }

    if (sortBy === 'price-asc') {
      return [...filtered].sort((a, b) => a.pricePKR - b.pricePKR);
    }
    if (sortBy === 'price-desc') {
      return [...filtered].sort((a, b) => b.pricePKR - a.pricePKR);
    }
    if (sortBy === 'newest') {
      return [...filtered].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      );
    }
    return filtered;
  }, [
    publicListings,
    searchQuery,
    selectedCategory,
    selectedCity,
    activeFilterLocation,
    maxPrice,
    exchangeMode,
    sortBy,
    lang,
  ]);

  const handleToggleFavorite = (seedId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = seedRepository.toggleFavorite(seedId);
    setFavorites(updated);
  };

  const handleSelectSeed = (seed: SeedListing) => {
    setSelectedSeedId(seed.id);
    setActivePage('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectSeller = (sellerId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedSellerId(sellerId);
    setActivePage('sellers');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartChatWithSeed = (seed: SeedListing, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const conv = chatAndCallService.ensureConversationForSeller({
      sellerId: seed.sellerId,
      sellerNameEn: seed.sellerNameEn,
      sellerNameUr: seed.sellerNameUr || seed.sellerNameEn,
      sellerFarmEn: seed.sellerFarmEn,
      sellerFarmUr: seed.sellerFarmUr || seed.sellerFarmEn,
      city: seed.city,
      phone: seed.sellerPhone,
      seedId: seed.id,
      seedNameEn: seed.nameEn,
      seedNameUr: seed.nameUr || seed.nameEn,
    });
    setActiveChatConvId(conv.id);
    setActivePage('chat');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartChatWithSeller = (seller: SellerProfile) => {
    const conv = chatAndCallService.ensureConversationForSeller({
      sellerId: seller.id,
      sellerNameEn: seller.nameEn,
      sellerNameUr: seller.nameUr,
      sellerFarmEn: seller.farmNameEn,
      sellerFarmUr: seller.farmNameUr,
      city: seller.city,
      phone: seller.phone,
    });
    setActiveChatConvId(conv.id);
    setActivePage('chat');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveListing = (newListing: SeedListing) => {
    const updated = seedRepository.saveListing(newListing);
    setAllListings(updated);
    setIsAddModalOpen(false);
    setEditingListing(null);
    setSelectedSeedId(newListing.id);
    setActivePage('detail');
  };

  const handleDeleteListing = (id: string, isAdminAction = false) => {
    const updated = seedRepository.deleteListing(id, isAdminAction);
    setAllListings(updated);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleResetDemo = () => {
    const reset = seedRepository.resetDemoListings();
    setAllListings(reset);
  };

  const handleAddInquiry = (inquiry: SeedInquiry) => {
    const updated = seedRepository.addInquiry(inquiry);
    setInquiries(updated);
  };

  const handleSubmitReport = (report: UserReport) => {
    const updated = adminService.submitReport(report);
    setReports(updated);
  };

  // Admin Handlers
  const handleAdminLoginSuccess = (session: AdminSession) => {
    setAdminSession(session);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleAdminLogout = () => {
    adminService.logoutAdmin();
    setAdminSession(null);
    setActivityLogs(adminService.getActivityLogs());
    setActivePage('catalog');
  };

  const handleToggleBlockUser = (userId: string) => {
    const updated = adminService.toggleBlockUser(userId);
    setUsers(updated);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleUpdateListingApproval = (
    seedId: string,
    status: ListingApprovalStatus
  ) => {
    const updated = seedRepository.updateListingApproval(seedId, status);
    setAllListings(updated);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleUpdateListingFakeFlag = (
    seedId: string,
    isFake: boolean,
    reasonEn?: string,
    reasonUr?: string
  ) => {
    const updated = seedRepository.updateListingFakeFlag(
      seedId,
      isFake,
      reasonEn,
      reasonUr
    );
    setAllListings(updated);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleUpdateReportStatus = (
    reportId: string,
    status: 'open' | 'investigating' | 'resolved' | 'dismissed',
    note?: string
  ) => {
    const updated = adminService.updateReportStatus(reportId, status, note);
    setReports(updated);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleSavePlatformSettings = (newSettings: PlatformSettings) => {
    const saved = adminService.saveSettings(newSettings);
    setPlatformSettings(saved);
    setLang(saved.defaultLanguage);
    setActivityLogs(adminService.getActivityLogs());
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedCity('all');
    setActiveFilterLocation(null);
    setMaxPrice(10000);
    setExchangeMode('all');
    setSortBy('featured');
  };

  const activeSeed = useMemo(
    () => allListings.find((item) => item.id === selectedSeedId) || null,
    [allListings, selectedSeedId]
  );

  const categoriesList: (SeedCategory | 'all')[] = [
    'all',
    'wheat',
    'rice',
    'cotton',
    'vegetables',
    'fruits',
    'traditional',
  ];

  const announcementText =
    lang === 'ur'
      ? platformSettings.announcementBannerUr || platformSettings.announcementBannerEn
      : platformSettings.announcementBannerEn || platformSettings.announcementBannerUr;

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#18241B]">
      {/* Optional Admin-Configured Announcement Banner */}
      {announcementText && (
        <div className="bg-[#14532D] text-white text-xs font-medium py-2 px-4 text-center">
          {announcementText}
        </div>
      )}

      {/* Top Navigation Bar with ChatGPT-Style Sidebar Drawer Toggle */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-[#E6E2D8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Sidebar Menu Toggle Button + Brand Wordmark */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label={lang === 'ur' ? 'مینیو کھولیں' : 'Open navigation menu'}
              title={lang === 'ur' ? 'مینیو کھولیں' : 'Open sidebar menu'}
              className="p-2 text-[#18241B] hover:text-[#14532D] hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors cursor-pointer"
            >
              <Menu className="w-5 h-5" />
            </button>

            <a
              href="#catalog"
              onClick={(e) => {
                e.preventDefault();
                setActivePage('catalog');
              }}
              className="text-lg sm:text-xl font-bold tracking-tight text-[#14532D] font-display whitespace-nowrap shrink-0"
            >
              {appBrandTitle}
            </a>
          </div>

          {/* Zone 2: 5 Clean Single-Line Text Navigation Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-[#4A554E]">
            <button
              type="button"
              onClick={() => setActivePage('catalog')}
              className={`hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0 py-1 ${
                activePage === 'catalog'
                  ? 'text-[#14532D] font-semibold underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {t.navCatalog}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('crops')}
              className={`hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0 py-1 ${
                activePage === 'crops'
                  ? 'text-[#14532D] font-semibold underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {t.navPopularCrops}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('chat')}
              className={`hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0 py-1 ${
                activePage === 'chat'
                  ? 'text-[#14532D] font-semibold underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {t.navChat}
            </button>
            <button
              type="button"
              onClick={() => {
                setSelectedSellerId(null);
                setActivePage('sellers');
              }}
              className={`hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0 py-1 ${
                activePage === 'sellers'
                  ? 'text-[#14532D] font-semibold underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {t.navSellers}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('dashboard')}
              className={`hover:text-[#14532D] transition-colors whitespace-nowrap shrink-0 py-1 ${
                activePage === 'dashboard'
                  ? 'text-[#14532D] font-semibold underline underline-offset-8 decoration-2'
                  : ''
              }`}
            >
              {t.navDashboard}
            </button>
          </nav>

          {/* Zone 3: Primary Action Button */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                setEditingListing(null);
                setIsAddModalOpen(true);
              }}
              className="px-4 py-2 text-xs font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              {t.postSeedCta}
            </button>
          </div>
        </div>
      </header>

      {/* Full-Height ChatGPT-Style Side Navigation Drawer */}
      <SideNavigationDrawer
        isOpen={mobileMenuOpen}
        lang={lang}
        activePage={activePage}
        selectedCategory={selectedCategory}
        brandTitle={appBrandTitle}
        totalListingsCount={publicListings.length}
        favoritesCount={favorites.length}
        sellersCount={activeSellers.length}
        inquiriesCount={inquiries.length}
        adminSession={adminSession}
        supportPhone={platformSettings.supportPhone}
        onClose={() => setMobileMenuOpen(false)}
        onNavigate={(page) => {
          if (page === 'sellers') {
            setSelectedSellerId(null);
          }
          setActivePage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAddSeedModal={() => {
          setEditingListing(null);
          setIsAddModalOpen(true);
        }}
        onChangeLanguage={(nextLang) => setLang(nextLang)}
      />

      {/* Workspace Language, Saved Seeds & Admin Portal Bar Below Header */}
      <div className="bg-[#F3EFE6] border-b border-[#E6E2D8]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 text-xs text-[#4A554E] font-medium">
            <span>
              {lang === 'ur'
                ? platformSettings.taglineUr || t.heroKicker
                : platformSettings.taglineEn || t.heroKicker}
            </span>
            <span aria-hidden="true" className="hidden sm:inline">
              ·
            </span>
            <button
              type="button"
              onClick={() => setActivePage('saved')}
              className="inline-flex items-center gap-1 text-[#14532D] font-semibold hover:underline"
            >
              <Heart className="w-3.5 h-3.5" />
              <span>
                {t.navSaved} ({favorites.length})
              </span>
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => setActivePage('admin')}
              className="inline-flex items-center gap-1 text-[#18241B] hover:text-[#14532D] font-semibold hover:underline"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#14532D]" />
              <span>
                {adminSession
                  ? lang === 'ur'
                    ? 'ایڈمن پینل (فعال)'
                    : 'Admin Console (Active)'
                  : lang === 'ur'
                    ? 'ایڈمن لاگ ان'
                    : 'Admin Portal'}
              </span>
            </button>
          </div>

          {/* Interactive Language Switcher (English LTR / Urdu RTL) */}
          <div className="flex items-center gap-2">
            <Globe className="w-3.5 h-3.5 text-[#14532D]" />
            <span className="text-xs text-[#5C6660] hidden sm:inline">
              {t.languageLabel}:
            </span>
            <div className="inline-flex items-center p-0.5 bg-white border border-[#E6E2D8] rounded-lg">
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  lang === 'en'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLang('ur')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  lang === 'ur'
                    ? 'bg-[#14532D] text-white'
                    : 'text-[#4A554E] hover:text-[#18241B]'
                }`}
              >
                اردو (RTL)
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Router */}
      <main className="flex-1">
        {activePage === 'admin' ? (
          <AdminPanelView
            lang={lang}
            allListings={allListings}
            users={users}
            reports={reports}
            activityLogs={activityLogs}
            platformSettings={platformSettings}
            adminSession={adminSession}
            onAdminLoginSuccess={handleAdminLoginSuccess}
            onAdminLogout={handleAdminLogout}
            onToggleBlockUser={handleToggleBlockUser}
            onUpdateListingApproval={handleUpdateListingApproval}
            onUpdateListingFakeFlag={handleUpdateListingFakeFlag}
            onDeleteListing={(seedId) => handleDeleteListing(seedId, true)}
            onUpdateReportStatus={handleUpdateReportStatus}
            onSaveSettings={handleSavePlatformSettings}
            onInspectSeed={handleSelectSeed}
            onExitAdmin={() => setActivePage('catalog')}
            onChangeLanguage={(nextLang) => setLang(nextLang)}
          />
        ) : activePage === 'detail' && activeSeed ? (
          <SeedDetailView
            seed={activeSeed}
            seller={users.find((s) => s.id === activeSeed.sellerId)}
            lang={lang}
            isFavorite={favorites.includes(activeSeed.id)}
            onToggleFavorite={(id) => handleToggleFavorite(id)}
            onBack={() => setActivePage('catalog')}
            onOpenSellerProfile={(sellerId) => handleSelectSeller(sellerId)}
            onStartChatWithSeed={(seed) => handleStartChatWithSeed(seed)}
            onSubmitInquiry={handleAddInquiry}
            onSubmitReport={handleSubmitReport}
          />
        ) : activePage === 'crops' ? (
          <PopularCropsView
            lang={lang}
            onBrowseCategoryInCatalog={(cat) => {
              setSelectedCategory(cat);
              setActivePage('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        ) : activePage === 'chat' ? (
          <FarmerChatView
            lang={lang}
            initialConversationId={activeChatConvId}
            onOpenSeedById={(seedId) => {
              setSelectedSeedId(seedId);
              setActivePage('detail');
            }}
            onOpenSellerById={(sellerId) => handleSelectSeller(sellerId)}
          />
        ) : activePage === 'sellers' ? (
          <SellerDirectoryView
            sellers={activeSellers}
            listings={publicListings}
            selectedSellerId={selectedSellerId}
            lang={lang}
            favorites={favorites}
            onSelectSeller={setSelectedSellerId}
            onSelectSeed={handleSelectSeed}
            onToggleFavorite={handleToggleFavorite}
            onStartChatWithSeller={handleStartChatWithSeller}
            onStartChatWithSeed={handleStartChatWithSeed}
          />
        ) : activePage === 'dashboard' ? (
          <UserDashboardView
            listings={publicListings}
            favorites={favorites}
            inquiries={inquiries}
            lang={lang}
            onAddSeedClick={() => {
              setEditingListing(null);
              setIsAddModalOpen(true);
            }}
            onEditSeed={(seed) => {
              setEditingListing(seed);
              setIsAddModalOpen(true);
            }}
            onDeleteSeed={(id) => handleDeleteListing(id, false)}
            onResetDemo={handleResetDemo}
            onSelectSeed={handleSelectSeed}
            onSelectSeller={handleSelectSeller}
            onToggleFavorite={handleToggleFavorite}
          />
        ) : activePage === 'saved' ? (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-[#18241B]">
                  {t.navSaved} ({favorites.length})
                </h1>
                <p className="text-sm text-[#4A554E] mt-1">
                  {lang === 'ur'
                    ? 'آپ کے پسندیدہ اور محفوظ کردہ دیسی بیجوں کی فہرست'
                    : 'Your bookmarked heirloom desi seeds saved in browser storage.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActivePage('catalog')}
                className="px-4 py-2 text-xs font-semibold text-[#14532D] bg-[#EAF2EC] rounded-lg"
              >
                {t.backToCatalog}
              </button>
            </div>

            {favorites.length === 0 ? (
              <div className="bg-white border border-[#E6E2D8] rounded-xl p-12 text-center space-y-3">
                <Heart className="w-8 h-8 text-[#5C6660] mx-auto" />
                <h2 className="text-lg font-semibold text-[#18241B]">
                  {lang === 'ur'
                    ? 'کوئی پسندیدہ بیج موجود نہیں'
                    : 'Your saved seeds list is empty'}
                </h2>
                <button
                  type="button"
                  onClick={() => setActivePage('catalog')}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                >
                  {t.exploreCatalogBtn}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {publicListings
                  .filter((item) => favorites.includes(item.id))
                  .map((seed) => (
                    <SeedCard
                      key={seed.id}
                      seed={seed}
                      lang={lang}
                      isFavorite={true}
                      onToggleFavorite={handleToggleFavorite}
                      onSelectSeed={handleSelectSeed}
                      onSelectSeller={handleSelectSeller}
                      onStartChat={handleStartChatWithSeed}
                    />
                  ))}
              </div>
            )}
          </div>
        ) : (
          /* Storefront Homepage & Catalog */
          <div>
            {/* Section 1: Storefront Split Hero */}
            <section className="border-b border-[#E6E2D8] bg-[#FAF8F5]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
                  {/* Text Column */}
                  <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
                    <div className="space-y-4">
                      <p className="text-xs font-semibold tracking-wider text-[#14532D]">
                        {lang === 'ur'
                          ? 'پنجاب · سندھ · خیبر پختونخوا · بلوچستان'
                          : 'PUNJAB · SINDH · KHYBER PAKHTUNKHWA · BALOCHISTAN'}
                      </p>
                      <h1
                        className="text-3xl sm:text-4xl lg:text-[2.75rem] font-bold text-[#18241B] leading-[1.15]"
                        style={{ textWrap: 'balance' }}
                      >
                        {t.heroTitle}
                      </h1>
                      <p className="text-base text-[#4A554E] leading-relaxed max-w-[62ch]">
                        {t.heroSubtitle}
                      </p>
                    </div>

                    <div className="space-y-6 pt-2">
                      <div className="flex flex-wrap items-center gap-3">
                        <a
                          href="#seed-catalog-grid"
                          className="px-6 py-3 text-sm font-semibold text-white bg-[#14532D] hover:bg-[#0F3F22] rounded-lg transition-colors whitespace-nowrap"
                        >
                          {t.exploreCatalogBtn}
                        </a>
                        <button
                          type="button"
                          onClick={() => setActivePage('crops')}
                          className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#18241B] bg-white hover:bg-[#EFECE6] border border-[#E6E2D8] rounded-lg transition-colors whitespace-nowrap"
                        >
                          <BookOpen className="w-4 h-4 text-[#14532D]" />
                          <span>مشہور فصلیں | Popular Crops</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setActivePage('chat')}
                          className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold text-[#14532D] bg-[#EAF2EC] hover:bg-[#DCE9E0] rounded-lg transition-colors whitespace-nowrap"
                        >
                          <MessageSquare className="w-4 h-4" />
                          <span>{t.navChat}</span>
                        </button>
                      </div>

                      {/* Claim-to-Proof Adjacency Strip */}
                      <div className="pt-5 border-t border-[#E6E2D8] flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-[#4A554E]">
                        <span className="font-semibold text-[#14532D]">
                          {t.metricVarieties}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{t.metricDistricts}</span>
                        <span aria-hidden="true">·</span>
                        <span>{t.metricDirect}</span>
                      </div>
                    </div>
                  </div>

                  {/* Hero Image Column */}
                  <div className="lg:col-span-6">
                    <div className="relative h-full min-h-[280px] sm:min-h-[360px] rounded-xl overflow-hidden border border-[#E6E2D8] bg-[#EFECE6]">
                      <SeedImage
                        src={HERO_IMAGE_PATH}
                        alt="Golden Pakistani wheat harvest and heirloom seeds in terracotta bowls"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent flex items-end p-6">
                        <div className="text-white max-w-md">
                          <p className="text-xs font-mono-num text-white/85">
                            {lang === 'ur'
                              ? 'ربیع اور خریف سیزن 2026–2027 · تصدیق شدہ دیسی بیج'
                              : 'Rabi & Kharif Harvest 2026–2027 · Farmer-Verified Lineage'}
                          </p>
                          <p className="text-sm font-medium mt-1">
                            {lang === 'ur'
                              ? 'شربتی گندم، کلر باسمتی، چولستانی دیسی کپاس اور ملتانی سبزیاں'
                              : 'Sharbati Gandum, Kalar Tract Basmati, Cholistani Desi Kapas & Multani Heirloom Vegetables'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Section 2: Interactive Search, Category Tabs & Multi-Filter Catalog */}
            <section
              id="seed-catalog-grid"
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8"
            >
              {/* Search & Filter Control Panel */}
              <div className="bg-white border border-[#E6E2D8] rounded-xl p-5 sm:p-6 space-y-5">
                {/* Search Bar + Global Location Autocomplete & GPS + Sort Row */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
                  {/* Search Input */}
                  <div className="lg:col-span-5 relative">
                    <Search className="w-4 h-4 text-[#5C6660] absolute top-1/2 -translate-y-1/2 start-3.5 pointer-events-none" />
                    <input
                      type="search"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={t.searchPlaceholder}
                      className="w-full ps-10 pe-4 py-2.5 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                    />
                  </div>

                  {/* Worldwide Location Autocomplete + Use Current Location (GPS) */}
                  <div className="lg:col-span-5">
                    <CatalogLocationFilterBar
                      lang={lang}
                      selectedCity={selectedCity}
                      activeLocationObj={activeFilterLocation}
                      availableListingCities={availableListingCities}
                      onSelectLocationFilter={(cityOrQuery, structured) => {
                        setSelectedCity(cityOrQuery);
                        setActiveFilterLocation(structured);
                      }}
                    />
                  </div>

                  {/* Sort Selector */}
                  <div className="lg:col-span-2">
                    <select
                      value={sortBy}
                      onChange={(e) =>
                        setSortBy(
                          e.target.value as
                            | 'featured'
                            | 'price-asc'
                            | 'price-desc'
                            | 'newest'
                        )
                      }
                      aria-label={t.sortByLabel}
                      className="w-full px-3 py-2.5 text-sm bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                    >
                      <option value="featured">{t.sortFeatured}</option>
                      <option value="price-asc">{t.sortPriceAsc}</option>
                      <option value="price-desc">{t.sortPriceDesc}</option>
                      <option value="newest">{t.sortNewest}</option>
                    </select>
                  </div>
                </div>

                {/* Category Filter Buttons */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {categoriesList.map((cat) => {
                    const active = selectedCategory === cat;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3.5 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-[#14532D] text-white'
                            : 'bg-[#FAF8F5] text-[#4A554E] hover:text-[#18241B] border border-[#E6E2D8]'
                        }`}
                      >
                        {CATEGORY_LABELS[cat][lang]}
                      </button>
                    );
                  })}
                </div>

                {/* Price Range Slider & Exchange Mode Filter Bar */}
                <div className="pt-4 border-t border-[#F0EDE6] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center gap-3">
                      <SlidersHorizontal className="w-4 h-4 text-[#14532D]" />
                      <label className="text-xs font-medium text-[#4A554E] whitespace-nowrap">
                        {t.maxPriceLabel}:{' '}
                        <span className="font-semibold text-[#18241B] font-mono-num">
                          {formatPKR(maxPrice, lang)}
                        </span>
                      </label>
                      <input
                        type="range"
                        min={500}
                        max={10000}
                        step={250}
                        value={maxPrice}
                        onChange={(e) => setMaxPrice(Number(e.target.value))}
                        className="w-32 sm:w-44 accent-[#14532D] cursor-pointer"
                      />
                    </div>

                    {/* Exchange Mode Filter */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-[#5C6660]">
                        {t.exchangeModeLabel}:
                      </span>
                      <select
                        value={exchangeMode}
                        onChange={(e) =>
                          setExchangeMode(e.target.value as ExchangeType | 'all')
                        }
                        className="px-2.5 py-1.5 text-xs bg-[#FAF8F5] border border-[#E6E2D8] rounded-lg focus:outline-none focus:border-[#14532D]"
                      >
                        {(['all', 'both', 'sale', 'exchange'] as const).map(
                          (m) => (
                            <option key={m} value={m}>
                              {EXCHANGE_LABELS[m][lang]}
                            </option>
                          )
                        )}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4">
                    <span className="text-xs text-[#5C6660] font-mono-num">
                      {t.showingResults} {filteredListings.length} {t.ofTotal}{' '}
                      {publicListings.length} {t.seedListingsWord}
                    </span>
                    <button
                      type="button"
                      onClick={handleResetFilters}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-[#14532D] hover:underline whitespace-nowrap"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{t.resetFilters}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* 3-Column Featured Seed Collection Grid */}
              {filteredListings.length === 0 ? (
                <div className="bg-white border border-[#E6E2D8] rounded-xl p-12 text-center space-y-3">
                  <h3 className="text-lg font-semibold text-[#18241B]">
                    {t.noSeedsFoundTitle}
                  </h3>
                  <p className="text-sm text-[#5C6660] max-w-md mx-auto">
                    {t.noSeedsFoundSub}
                  </p>
                  <button
                    type="button"
                    onClick={handleResetFilters}
                    className="px-5 py-2.5 text-xs font-semibold text-white bg-[#14532D] rounded-lg"
                  >
                    {t.resetFilters}
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredListings.map((seed) => {
                    const seedLoc = locationService.resolveSeedStructuredLocation(
                      seed,
                      lang
                    );
                    const distanceKm =
                      activeFilterLocation &&
                      typeof activeFilterLocation.latitude === 'number' &&
                      typeof activeFilterLocation.longitude === 'number'
                        ? locationService.calculateDistanceKm(
                            activeFilterLocation.latitude,
                            activeFilterLocation.longitude,
                            seedLoc.latitude,
                            seedLoc.longitude
                          )
                        : null;

                    return (
                      <SeedCard
                        key={seed.id}
                        seed={seed}
                        lang={lang}
                        isFavorite={favorites.includes(seed.id)}
                        distanceKm={distanceKm}
                        onToggleFavorite={handleToggleFavorite}
                        onSelectSeed={handleSelectSeed}
                        onSelectSeller={handleSelectSeller}
                        onStartChat={handleStartChatWithSeed}
                      />
                    );
                  })}
                </div>
              )}
            </section>

            {/* Section 3: Craftsmanship & Seed Sovereignty Editorial Section */}
            <section className="border-t border-[#E6E2D8] bg-[#F3EFE6] py-12">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  <div className="lg:col-span-7 space-y-4">
                    <h2 className="text-2xl sm:text-3xl font-bold text-[#18241B]">
                      {t.storyHeading}
                    </h2>
                    <p className="text-base text-[#36403A] leading-relaxed">
                      {t.storyBody1}
                    </p>
                    <p className="text-sm text-[#4A554E] leading-relaxed">
                      {t.storyBody2}
                    </p>
                  </div>

                  <div className="lg:col-span-5 bg-white border border-[#E6E2D8] rounded-xl p-6 space-y-4">
                    <p className="text-xs font-semibold text-[#14532D]">
                      {lang === 'ur'
                        ? 'کسان گواہی · ساہیوال اور گوجرانوالہ'
                        : 'FARMER TESTIMONIAL · SAHIWAL & GUJRANWALA'}
                    </p>
                    <blockquote className="text-sm text-[#18241B] leading-relaxed">
                      {lang === 'ur'
                        ? '"پچھلے سال میں نے دیسی بیج ایکسچینج کے ذریعے اپنی شربتی گندم کے بدلے کامونکی کے کسان سے خالص کلر باسمتی کا بیج حاصل کیا۔ بغیر کسی زرعی زہر کے 94 فیصد اگاؤ ملا۔"'
                        : '"Last Rabi season I swapped 2 Maunds of our farm-saved Sharbati wheat for pure Kalar Tract Basmati paddy from Kamoke. We achieved 94% germination with zero chemical fungicide outlay."'}
                    </blockquote>
                    <div className="text-xs text-[#5C6660]">
                      <span className="font-semibold text-[#18241B]">
                        {lang === 'ur'
                          ? 'حاجی غلام مصطفیٰ'
                          : 'Haji Ghulam Mustafa'}
                      </span>
                      <span> · </span>
                      <span>
                        {lang === 'ur'
                          ? 'ستلج ہیریٹیج سیڈ ڈیرہ، ساہیوال'
                          : 'Satluj Heritage Seed Dera, Sahiwal'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )}
      </main>

      {/* Quiet Functional Footer */}
      <footer className="bg-white border-t border-[#E6E2D8] py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#5C6660]">
          <div>
            <span className="font-bold text-[#14532D]">{appBrandTitle}</span>
            <span> · </span>
            <span>
              {lang === 'ur'
                ? 'پاکستانی کسانوں کا روایتی دیسی بیج تبادلہ نیٹ ورک'
                : 'Pakistani Farmer-to-Farmer Heirloom Seed Network'}
            </span>
            <span> · </span>
            <span className="font-mono-num">{platformSettings.helplinePhone}</span>
          </div>
          <div className="flex flex-wrap items-center gap-5">
            <button
              type="button"
              onClick={() => setActivePage('catalog')}
              className="hover:text-[#14532D]"
            >
              {t.navCatalog}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('crops')}
              className="hover:text-[#14532D]"
            >
              {t.navPopularCrops}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('chat')}
              className="hover:text-[#14532D]"
            >
              {t.navChat}
            </button>
            <button
              type="button"
              onClick={() => setActivePage('admin')}
              className="hover:text-[#14532D] font-semibold"
            >
              {lang === 'ur' ? 'ایڈمن پورٹل' : 'Admin Portal'}
            </button>
            <button
              type="button"
              onClick={() => setLang(lang === 'en' ? 'ur' : 'en')}
              className="font-semibold text-[#14532D] hover:underline"
            >
              {lang === 'en' ? 'اردو میں دیکھیں' : 'Switch to English'}
            </button>
          </div>
        </div>
      </footer>

      {/* Add / Edit Seed Listing Modal */}
      {isAddModalOpen && (
        <AddSeedModal
          lang={lang}
          initialListing={editingListing}
          onClose={() => {
            setIsAddModalOpen(false);
            setEditingListing(null);
          }}
          onSave={handleSaveListing}
        />
      )}
    </div>
  );
}
