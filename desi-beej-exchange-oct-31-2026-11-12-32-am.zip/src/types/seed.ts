export type Language = 'en' | 'ur';

export type SeedCategory =
  | 'wheat'
  | 'rice'
  | 'cotton'
  | 'vegetables'
  | 'fruits'
  | 'traditional';

export type ExchangeType = 'both' | 'sale' | 'exchange';

export type AccountStatus = 'active' | 'blocked';
export type ListingApprovalStatus = 'approved' | 'pending' | 'rejected';

export type LocationSource = 'gps' | 'autocomplete' | 'manual';

export interface StructuredLocation {
  country: string;
  state: string;
  city: string;
  area: string;
  address: string;
  latitude?: number;
  longitude?: number;
  source?: LocationSource;
  formattedAddress?: string;
}

export interface SellerProfile {
  id: string;
  nameEn: string;
  nameUr: string;
  farmNameEn: string;
  farmNameUr: string;
  city: string;
  provinceEn: string;
  provinceUr: string;
  locationEn: string;
  locationUr: string;
  structuredLocation?: StructuredLocation;
  phone: string;
  whatsapp: string;
  experienceYears: number;
  bioEn: string;
  bioUr: string;
  totalExchanges: number;
  joinedYear: number;
  seedPledgeEn: string;
  seedPledgeUr: string;
  status?: AccountStatus;
  role?: 'farmer' | 'verified_guardian' | 'admin';
}

export interface SeedListing {
  id: string;
  nameEn: string;
  nameUr: string;
  varietyCode: string;
  category: SeedCategory;
  image: string;
  pricePKR: number;
  quantityEn: string;
  quantityUr: string;
  availableStockEn: string;
  availableStockUr: string;
  city: string;
  locationEn: string;
  locationUr: string;
  structuredLocation?: StructuredLocation;
  descriptionEn: string;
  descriptionUr: string;
  sellerId: string;
  sellerNameEn: string;
  sellerNameUr: string;
  sellerFarmEn: string;
  sellerFarmUr: string;
  sellerPhone: string;
  exchangeType: ExchangeType;
  exchangeNotesEn: string;
  exchangeNotesUr: string;
  sowingSeasonEn: string;
  sowingSeasonUr: string;
  germinationRate: number;
  maturityDays: number;
  waterRequirementEn: string;
  waterRequirementUr: string;
  heirloomGenerationEn: string;
  heirloomGenerationUr: string;
  createdAt: string;
  isUserCreated?: boolean;
  approvalStatus?: ListingApprovalStatus;
  isSuspectedFake?: boolean;
  fakeReasonEn?: string;
  fakeReasonUr?: string;
}

export interface SeedInquiry {
  id: string;
  seedId: string;
  seedNameEn: string;
  seedNameUr: string;
  sellerNameEn: string;
  sellerPhone: string;
  buyerName: string;
  buyerPhone: string;
  buyerCity: string;
  buyerLocation?: StructuredLocation;
  inquiryType: 'buy' | 'exchange';
  requestedQuantity: string;
  offeredSeedForExchange?: string;
  message: string;
  createdAt: string;
}

export interface FilterState {
  searchQuery: string;
  category: SeedCategory | 'all';
  city: string | 'all';
  maxPrice: number;
  exchangeMode: ExchangeType | 'all';
  sortBy: 'featured' | 'price-asc' | 'price-desc' | 'newest';
}

/* ==========================================================================
   FEATURE 1: FARMER-TO-FARMER CHAT & WEBRTC VOICE CALL TYPES
   ========================================================================== */

export type MessageStatus = 'sent' | 'delivered' | 'read';
export type MessageContentType = 'text' | 'image' | 'voice';

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: 'current-user' | string;
  senderNameEn: string;
  senderNameUr: string;
  type: MessageContentType;
  text?: string;
  imageUrl?: string;
  audioDataUrl?: string;
  audioDurationSec?: number;
  seedContextTitle?: string;
  timestamp: string;
  status: MessageStatus;
}

export interface ChatConversation {
  id: string;
  participantId: string;
  participantNameEn: string;
  participantNameUr: string;
  participantFarmEn: string;
  participantFarmUr: string;
  participantCity: string;
  participantPhone: string;
  relatedSeedId?: string;
  relatedSeedNameEn?: string;
  relatedSeedNameUr?: string;
  unreadCount: number;
  updatedAt: string;
}

export type VoiceCallStatus =
  | 'idle'
  | 'requesting-mic'
  | 'calling'
  | 'incoming'
  | 'connected'
  | 'ended'
  | 'error';

/* ==========================================================================
   FEATURE 2: POPULAR CROPS INFORMATION CENTER TYPES
   ========================================================================== */

export type CropGroupCategory =
  | 'all'
  | 'cereals'
  | 'cash_oilseeds'
  | 'vegetables'
  | 'fruits_seasonal';

export interface CropGuide {
  id: string;
  nameEn: string;
  nameUr: string;
  botanicalName: string;
  category: Exclude<CropGroupCategory, 'all'>;
  linkedSeedCategory: SeedCategory;
  image: string;
  estimatedDurationEn: string;
  estimatedDurationUr: string;
  sowingSeasonEn: string;
  sowingSeasonUr: string;
  soilAndClimateEn: string;
  soilAndClimateUr: string;
  seedSelectionEn: string;
  seedSelectionUr: string;
  cultivationGuideEn: string;
  cultivationGuideUr: string;
  irrigationGuidanceEn: string;
  irrigationGuidanceUr: string;
  fertilizerGuidanceEn: string;
  fertilizerGuidanceUr: string;
  pestsAndDiseasesEn: string;
  pestsAndDiseasesUr: string;
  harvestingInfoEn: string;
  harvestingInfoUr: string;
}

/* ==========================================================================
   FEATURE 3: ADMIN PANEL, MODERATION, REPORTS, FRAUD & ACTIVITY LOG TYPES
   ========================================================================== */

export type ReportStatus = 'open' | 'investigating' | 'resolved' | 'dismissed';

export type ReportReasonType =
  | 'fake_seed'
  | 'advance_payment_scam'
  | 'wrong_phone'
  | 'overpriced'
  | 'hybrid_sold_as_desi';

export interface UserReport {
  id: string;
  targetSeedId: string;
  targetSeedNameEn: string;
  targetSeedNameUr: string;
  targetSellerId: string;
  targetSellerNameEn: string;
  targetSellerNameUr: string;
  reporterName: string;
  reporterPhone: string;
  reporterCity: string;
  reasonType: ReportReasonType;
  detailsEn: string;
  detailsUr: string;
  status: ReportStatus;
  createdAt: string;
  resolvedBy?: string;
  resolutionNote?: string;
}

export type AdminActionCategory =
  | 'auth'
  | 'user_moderation'
  | 'listing_moderation'
  | 'report_resolution'
  | 'fraud_action'
  | 'settings_update';

export interface AdminActivityLog {
  id: string;
  timestamp: string;
  adminEmail: string;
  authMode: 'firebase-auth' | 'demo-preview';
  category: AdminActionCategory;
  actionEn: string;
  actionUr: string;
  targetId?: string;
}

export interface PlatformSettings {
  appNameEn: string;
  appNameUr: string;
  taglineEn: string;
  taglineUr: string;
  defaultLanguage: Language;
  helplinePhone: string;
  supportEmail: string;
  requireListingApproval: boolean;
  enableBarterExchange: boolean;
  announcementBannerEn: string;
  announcementBannerUr: string;
}

export interface AdminSession {
  token: string;
  email: string;
  role: 'admin';
  mode: 'firebase-auth' | 'demo-preview';
  issuedAt: number;
  expiresAt: number;
}
