import { CropGuide, CropGroupCategory } from '../types/seed';

export const CROP_GROUP_LABELS: Record<CropGroupCategory, { en: string; ur: string }> = {
  all: { en: 'All Crops (10)', ur: 'تمام فصلیں (10)' },
  cereals: { en: 'Cereals & Grains', ur: 'اناج اور غلہ دار فصلیں' },
  cash_oilseeds: { en: 'Cash & Oilseed Crops', ur: 'نقد آور اور تیلدار فصلیں' },
  vegetables: { en: 'Major Vegetables', ur: 'مشہور سبزیاں' },
  fruits_seasonal: { en: 'Seasonal Fruits & Vegetables', ur: 'موسمی پھل اور سبزیاں' },
};

export const POPULAR_CROPS_DATA: CropGuide[] = [
  {
    id: 'crop-wheat',
    nameEn: 'Wheat (Gandum)',
    nameUr: 'گندم (Wheat)',
    botanicalName: 'Triticum aestivum',
    category: 'cereals',
    linkedSeedCategory: 'wheat',
    image: '/src/assets/images/seed_sharbati_wheat_1793414536309.jpg',
    estimatedDurationEn: '140 – 155 Days (Rabi Season)',
    estimatedDurationUr: '140 تا 155 دن (موسمِ ربیع)',
    sowingSeasonEn:
      'Punjab & KP Plains: 1st November to 20th November (optimum). Sindh: 15th October to 15th November. Barani (Rain-fed) Potohar: 20th October to 10th November.',
    sowingSeasonUr:
      'پنجاب اور خیبر پختونخوا کے میدانی علاقے: یکم نومبر تا 20 نومبر۔ سندھ: 15 اکتوبر تا 15 نومبر۔ بارانی علاقے (پوٹھووار): 20 اکتوبر تا 10 نومبر۔',
    soilAndClimateEn:
      'Well-drained fertile loam to clay-loam soils (Mera Zameen) with pH 6.5–7.8. Cool, moist weather during tillering (Dec–Jan) and warm, dry sunshine during grain filling (March–April).',
    soilAndClimateUr:
      'زرخیز میرا اور بھاری میرا زمین جس میں پانی کا نکاس اچھا ہو۔ شگوفے نکلتے وقت ٹھنڈا موسم (دسمبر، جنوری) اور دانہ بنتے وقت خشک اور معتدل گرم دھوپ موزوں ہے۔',
    seedSelectionEn:
      '40 to 50 kg per acre (increase to 55 kg/acre for late sowing after 25th November). Traditional heirloom: Sharbati C-591, C-273; Approved regional varieties: Akbar-2019, Dilkash-2020, Subhani-2021, Zincol-16.',
    seedSelectionUr:
      '40 تا 50 کلوگرام فی ایکڑ (پچھیتی کاشت میں 55 کلوگرام فی ایکڑ)۔ روایتی دیسی اقسام: شربتی C-591؛ منظور شدہ اقسام: اکبر 2019، دلکش 2020، سبحانی 2021۔ بیج صاف اور 90 فیصد سے زائد اگاؤ والا منتخب کریں۔',
    cultivationGuideEn:
      'Prepare a fine, level seedbed using laser land leveler to save 25% canal water. Sow in lines 22.5 cm (9 inches) apart using a Rabi drill at 4–5 cm depth, or use zero-tillage happy seeder after rice harvest.',
    cultivationGuideUr:
      'لیزر لینڈ لیولر سے زمین ہموار کریں تاکہ پانی یکساں لگے۔ ربیع ڈرل کے ذریعے قطاروں کا درمیانی فاصلہ 9 انچ رکھ کر کاشت کریں یا دھان کے بعد زیرو ٹلیج ڈرل استعمال کریں۔',
    irrigationGuidanceEn:
      'Requires 3 to 4 irrigations in canal areas: 1st critical irrigation at Crown Root Initiation (20–25 days after sowing), 2nd at booting stage (Feb), 3rd at milk/grain formation stage (mid-March).',
    irrigationGuidanceUr:
      'نہری علاقوں میں 3 سے 4 پانی درکار ہیں: پہلا اہم پانی بوائی کے 20 تا 25 دن بعد (جڑیں بنتے وقت)، دوسرا فروری میں گوبھ کے وقت، اور تیسرا مارچ میں دانہ دودھیا حالت میں آنے پر۔',
    fertilizerGuidanceEn:
      'Incorporate 3–4 trolleys of well-rotted Farmyard Manure (Gobar Khad) 1 month before sowing. For conventional soils: apply phosphorus and potash at sowing, and split nitrogen with 1st and 2nd irrigation based on soil test.',
    fertilizerGuidanceUr:
      'بوائی سے ایک ماہ قبل 3 سے 4 ٹرالیاں گلی سڑی گوبر کی کھاد زمین میں ملائیں۔ فاسفورس اور پوٹاش بوائی کے وقت جبکہ نائٹروجن کھاد پہلی اور دوسری آبپاشی کے ساتھ زمین کے تجزیے کے مطابق دیں۔',
    pestsAndDiseasesEn:
      'Yellow Rust (Kungi), Loose Smut (Kangiari), and Aphids (Tela) in March. Grow rust-tolerant varieties, avoid excessive late nitrogen, and conserve beneficial ladybird beetles that eat aphids naturally.',
    pestsAndDiseasesUr:
      'پیلی کنگی (زنگ)، کانگیاری اور مارچ میں سست تیلہ۔ کنگی کے خلاف قوتِ مدافعت رکھنے والا بیج بوئیں اور تیلے کے تدارک کے لیے دوست کیڑوں (لیڈی برڈ بیٹل) کی حفاظت کریں۔',
    harvestingInfoEn:
      'Harvest in mid-April (Sindh: March–April) when straw turns golden yellow and grain moisture drops below 12–14%. Sun-dry grains thoroughly before storing in clean bins with dried Neem leaves.',
    harvestingInfoUr:
      'جب ناڑ سنہری پیلا ہو جائے اور دانے میں نمی 12 فیصد رہ جائے تو اپریل میں کٹائی کریں۔ ذخیرہ کرنے سے قبل دانوں کو اچھی طرح دھوپ لگوائیں اور نیم کے پتے رکھیں۔',
  },
  {
    id: 'crop-rice',
    nameEn: 'Rice / Paddy (Chawal / Dhaan)',
    nameUr: 'چاول / دھان (Rice)',
    botanicalName: 'Oryza sativa',
    category: 'cereals',
    linkedSeedCategory: 'rice',
    image: '/src/assets/images/seed_basmati_rice_1793414536482.jpg',
    estimatedDurationEn: '120 – 145 Days (Kharif Season)',
    estimatedDurationUr: '120 تا 145 دن (موسمِ خریف)',
    sowingSeasonEn:
      'Nursery Sowing (Paneeri): 20th May to 20th June for Basmati; 1st May to 20th May for Coarse/IRRI varieties. Transplanting (Lab): 25 to 35 days after nursery sowing (mid-June to July).',
    sowingSeasonUr:
      'پنیری کی کاشت: باسمتی اقسام کے لیے 20 مئی تا 20 جون؛ موٹی اقسام کے لیے یکم مئی تا 20 مئی۔ پنیری کی منتقلی (لب لگانا): 25 سے 35 دن کی پنیری جون کے آخر سے جولائی میں منتقل کریں۔',
    soilAndClimateEn:
      'Heavy clay or clay-loam soils (Chikni Mera) with high water-holding capacity, characteristic of the Kalar Tract (Gujranwala, Sheikhupura, Sialkot, Hafizabad) and Upper Sindh. Warm humid monsoon climate.',
    soilAndClimateUr:
      'پانی روکنے کی صلاحیت رکھنے والی چکنی اور بھاری میرا زمین (کلر ٹریکٹ گوجرانوالہ، شیخوپورہ، سیالکوٹ اور بالائی سندھ)۔ گرم اور مرطوب موسمِ برسات۔',
    seedSelectionEn:
      '5 to 6 kg clean paddy seed per acre for nursery raising (8–10 kg for Direct Seeded Rice / DSR). Heirloom & aromatic: Basmati 370, Super Basmati, Kissan Basmati, Chenab Basmati.',
    seedSelectionUr:
      'پنیری کے لیے 5 سے 6 کلوگرام فی ایکڑ صحت مند بیج (براہ راست کاشت DSR کے لیے 8 تا 10 کلو)۔ مشہور اقسام: قدیمی باسمتی 370، سپر باسمتی، چناب باسمتی اور کسان باسمتی۔',
    cultivationGuideEn:
      'Transplant 2 seedlings per hill at 9x9 inch spacing to achieve 80,000 plants per acre. Avoid deep transplanting (keep root crown within 1.5 inches of puddled soil) for vigorous tillering.',
    cultivationGuideUr:
      'کھیت میں فی ایکڑ 80 ہزار پودوں کی تعداد پوری کرنے کے لیے 9x9 انچ کے فاصلے پر دو دو پودے لگائیں۔ پنیری زیادہ گہری نہ لگائیں تاکہ شگوفے زیادہ نکلیں۔',
    irrigationGuidanceEn:
      'Maintain 1.5–2 inches standing water during the first 25 days after transplanting, followed by Alternate Wetting and Drying (AWD / Watar condition) to save water and strengthen roots. Stop water 15 days before harvest.',
    irrigationGuidanceUr:
      'منتقلی کے ابتدائی 25 دن تک کھیت میں ڈیڑھ سے دو انچ پانی کھڑا رکھیں، اس کے بعد وتر آنے پر پانی لگائیں۔ کٹائی سے 15 دن پہلے پانی بند کر دیں۔',
    fertilizerGuidanceEn:
      'Zinc deficiency (Khaira disease) is common in paddy soils—apply Zinc Sulfate (33% Zn at 6 kg/acre) 10–15 days after transplanting along with balanced organic compost or recommended NPK.',
    fertilizerGuidanceUr:
      'دھان میں زنک کی کمی (مورچہ یا خیرہ روگ) سے بچاؤ کے لیے منتقلی کے 10 تا 15 دن بعد زنک سلفیٹ (33 فیصد بحساب 6 کلو فی ایکڑ) ضرور استعمال کریں۔',
    pestsAndDiseasesEn:
      'Rice Stem Borer (Tana Chhedak Sundi), Leaf Folder, Bacterial Leaf Blight (Jhulsaao), and Brown Plant Hopper (Tela). Destroy stubbles in winter and use light traps to monitor moth flights.',
    pestsAndDiseasesUr:
      'تنے کی سنڈی، پتہ لپیٹ سنڈی، بیکٹیریل جھلساؤ اور بھورا تیلہ۔ روشنی کے پھندے لگائیں اور نائٹروجن کھاد کا بے جا استعمال نہ کریں۔',
    harvestingInfoEn:
      'Harvest in October–November when 85–90% of grains on the panicle turn golden straw-colored and grain moisture is 20–22%. Avoid over-drying in hot sun to prevent grain cracking (Toota) during milling.',
    harvestingInfoUr:
      'اکتوبر اور نومبر میں جب سٹے کے 85 سے 90 فیصد دانے سنہری ہو جائیں تو کٹائی کریں۔ دھان کو تیز دھوپ میں زیادہ خشک ہونے سے بچائیں تاکہ چھڑائی میں ٹوٹا کم بنے۔',
  },
  {
    id: 'crop-cotton',
    nameEn: 'Cotton (Kapas)',
    nameUr: 'کپاس (Cotton / Kapas)',
    botanicalName: 'Gossypium arboreum / Gossypium hirsutum',
    category: 'cash_oilseeds',
    linkedSeedCategory: 'cotton',
    image: '/src/assets/images/seed_desi_cotton_1793414537605.jpg',
    estimatedDurationEn: '150 – 175 Days (Kharif Cash Crop)',
    estimatedDurationUr: '150 تا 175 دن (خریف کی نقد آور فصل)',
    sowingSeasonEn:
      'Lower Sindh: 1st March to 15th April. Upper Sindh & Southern Punjab (Multan, Bahawalpur, Rahim Yar Khan, Vehari): 1st April to 15th May.',
    sowingSeasonUr:
      'زیریں سندھ: یکم مارچ تا 15 اپریل۔ بالائی سندھ اور جنوبی پنجاب (ملتان، بہاولپور، رحیم یار خان، وہاڑی): یکم اپریل تا 15 مئی۔',
    soilAndClimateEn:
      'Deep, well-drained alluvial loam soils. Requires hot sunny weather (30°C–42°C) during vegetative growth and dry frost-free autumn weather during boll opening.',
    soilAndClimateUr:
      'گہری زرخیز میرا زمین جس میں پانی کھڑا نہ رہے۔ بڑھوتری کے لیے گرم موسم اور ٹینڈے کھلتے وقت خشک اور صاف دھوپ والا موسم بہترین ہے۔',
    seedSelectionEn:
      '6 to 8 kg delinted seed per acre for bed-furrow planting (10 kg for drill sowing). Desi varieties (FDH-228, Rohi Desi) are naturally immune to Leaf Curl Virus (CLCV) and whitefly flare-ups.',
    seedSelectionUr:
      'پٹڑیوں پر کاشت کے لیے 6 سے 8 کلوگرام بُر اترا بیج فی ایکڑ۔ دیسی کپاس کی اقسام (FDH-228 اور روہی دیسی) پتہ مروڑ وائرس اور سفید مکھی کے خلاف قدرتی قوتِ مدافعت رکھتی ہیں۔',
    cultivationGuideEn:
      'Plant on raised beds/ridges (2.5 feet apart) with plant-to-plant spacing of 9–12 inches. Perform thinning (Chhantai) before first irrigation when plants are 6 inches tall.',
    cultivationGuideUr:
      'ڈھائی فٹ چوڑی کھیلیاں بنا کر 9 سے 12 انچ کے فاصلے پر چوپے لگائیں۔ پہلے پانی سے قبل جب پودے 6 انچ کے ہو جائیں تو کمزور پودوں کی چھدرائی (چھانٹی) ضرور کریں۔',
    irrigationGuidanceEn:
      'First irrigation 30–35 days after drill sowing (or 3–4 days after bed sowing), followed by irrigation at 12–15 day intervals depending on heat. Never let water stand in furrows during monsoon rains.',
    irrigationGuidanceUr:
      'پٹڑیوں پر بوائی کے 3 سے 4 دن بعد ہلکا پانی لگائیں اور بعد میں موسم کی گرمی کے مطابق 12 تا 15 دن کے وقفے سے آبپاشی کریں۔ بارش کا فالتو پانی کھیت سے فوراً نکالیں۔',
    fertilizerGuidanceEn:
      'Apply well-composted farmyard manure before land preparation. Use split applications of nitrogen and foliar potassium/boron during flowering and boll formation to prevent flower shedding (Guddi Kera).',
    fertilizerGuidanceUr:
      'زمین کی تیاری میں گوبر کی کھاد ڈالیں۔ پھول اور گڈی بنتے وقت پوٹاش اور بوران کا استعمال کریں تاکہ گڈی اور ٹینڈوں کا کیڑا (گرنا) رک سکے۔',
    pestsAndDiseasesEn:
      'Whitefly (Safaid Makhi), Pink Bollworm (Gulabi Sundi), Jassid (Sabz Tela), and Cotton Leaf Curl Virus (CLCV). Install PB-Ropes/pheromone traps and yellow sticky cards early in the season.',
    pestsAndDiseasesUr:
      'سفید مکھی، گلابی سنڈی، سبز تیلہ اور پتہ مروڑ وائرس۔ کھیت میں پیلے چپکنے والے کارڈز اور جنسی پھندے (فیرومون ٹریپس) لگائیں۔',
    harvestingInfoEn:
      'Start picking (Chunai) in September–November after morning dew dries completely (after 10 AM). Store first, middle, and last pickings separately in clean cotton cloth sheets (never plastic fertilizer bags).',
    harvestingInfoUr:
      'ستمبر سے نومبر کے دوران صبح شبنم خشک ہونے کے بعد (10 بجے کے بعد) چنائی شروع کریں۔ پھٹی کو پلاسٹک کی بوریوں کے بجائے سوتی کپڑے کی جھولی اور چادر میں رکھیں۔',
  },
  {
    id: 'crop-maize',
    nameEn: 'Maize / Corn (Makai)',
    nameUr: 'مکئی (Maize / Makai)',
    botanicalName: 'Zea mays',
    category: 'cereals',
    linkedSeedCategory: 'traditional',
    image: '/src/assets/images/crop_maize_sugarcane_1793416230635.jpg',
    estimatedDurationEn: '95 – 115 Days (Spring & Autumn Crops)',
    estimatedDurationUr: '95 تا 115 دن (بہاریہ اور موسمی فصل)',
    sowingSeasonEn:
      'Baharia (Spring Maize): 15th January to end of February. Mausami (Kharif/Autumn Maize): 15th July to 15th August in Punjab & KP plains; April–May in high hills.',
    sowingSeasonUr:
      'بہاریہ مکئی: 15 جنوری تا آخر فروری۔ موسمی (خریف) مکئی: میدانی علاقوں میں 15 جولائی تا 15 اگست؛ پہاڑی علاقوں میں اپریل تا مئی۔',
    soilAndClimateEn:
      'Fertile, well-aerated silt loam to clay loam soil rich in organic matter (Sahiwal, Okara, Pakpattan, Kasur, Chiniot, Swabi, Mardan). Sensitive to waterlogging and frost.',
    soilAndClimateUr:
      'نامیاتی مادے سے بھرپور زرخیز میرا زمین (ساہیوال، اوکاڑہ، پاکپتن، قصور، صوابی، مردان)۔ مکئی کی فصل کھڑے پانی اور شدید کورے کو برداشت نہیں کرتی۔',
    seedSelectionEn:
      '8 to 10 kg seed per acre for ridge sowing (12–15 kg for grain/fodder broadcast). Traditional open-pollinated varieties: Sahiwal-2002, Agaiti-2002, Pearl, Jalal, Azam (can be farm-saved).',
    seedSelectionUr:
      'کھیلیوں پر کاشت کے لیے 8 تا 10 کلوگرام بیج فی ایکڑ۔ دیسی اور سنتھیٹک اقسام: ساہیوال 2002، اگیتی 2002، پرل، جلال اور اعظم جن کا بیج اگلے سال کے لیے رکھا جا سکتا ہے۔',
    cultivationGuideEn:
      'Sow on the sun-facing side of 2.5-foot ridges with 7–8 inch plant-to-plant distance to maintain 30,000–34,000 plants per acre.',
    cultivationGuideUr:
      'ڈھائی فٹ کے فاصلے پر بنائی گئی کھیلیوں کے دھوپ والے رخ پر 7 سے 8 انچ کے فاصلے پر بیج لگائیں تاکہ فی ایکڑ 32 ہزار پودے پورے ہوں۔',
    irrigationGuidanceEn:
      'Requires 8–10 irrigations for Autumn crop and 10–12 for Spring crop. Tasseling (Boor nikalna) and silking are the most moisture-sensitive stages—never allow water stress then.',
    irrigationGuidanceUr:
      'موسمی فصل کو 8 تا 10 اور بہاریہ فصل کو 10 تا 12 پانی درکار ہوتے ہیں۔ پھول (بور) اور چھلی کے ریشے نکلتے وقت پانی کی کمی ہرگز نہ آنے دیں۔',
    fertilizerGuidanceEn:
      'High nutrient feeder: incorporate green manure (Jantar/Guara) or 4 trolleys farmyard manure, supplemented with balanced phosphorus, potash, zinc, and split nitrogen dressings.',
    fertilizerGuidanceUr:
      'مکئی خوراک زیادہ لیتی ہے: جنتر یا گوارا کی سبز کھاد یا گوبر کی کھاد ڈالیں اور فاسفورس، پوٹاش اور زنک بوائی کے وقت دیں۔',
    pestsAndDiseasesEn:
      'Maize Stem Borer (Chilo partellus), Fall Armyworm, and Shoot Fly. Use Trichogramma beneficial wasp cards in fields to parasitize borer eggs without toxic sprays.',
    pestsAndDiseasesUr:
      'مکئی کی کونپل کی مکھی، تنے کی سنڈی اور فال آرمی ورم۔ سنڈیوں کے حیاتیاتی تدارک کے لیے کھیت میں ٹرائیکوگراما کارڈز لگائیں۔',
    harvestingInfoEn:
      'Harvest when husks turn dry papery yellow and a black layer forms at the base of kernels. Dry cobs on clean floors until grain moisture reaches 12% before shelling.',
    harvestingInfoUr:
      'جب چھلی کے پردے خشک ہو جائیں اور دانے کے نچلے حصے پر سیاہ تہہ بن جائے تو برداشت کریں۔ دانے نکالنے کے بعد نمی 12 فیصد تک خشک کریں۔',
  },
  {
    id: 'crop-sugarcane',
    nameEn: 'Sugarcane (Ganna / Kamad)',
    nameUr: 'گنا / کماد (Sugarcane)',
    botanicalName: 'Saccharum officinarum',
    category: 'cash_oilseeds',
    linkedSeedCategory: 'traditional',
    image: '/src/assets/images/crop_maize_sugarcane_1793416230635.jpg',
    estimatedDurationEn: '10 – 14 Months (Spring & Autumn Planting)',
    estimatedDurationUr: '10 تا 14 ماہ (بہاریہ اور ستمبر کاشت)',
    sowingSeasonEn:
      'Baharia (Spring Planting): 15th February to 31st March. Autumn Planting (September): 1st September to 15th October (gives 25% higher yield and allows intercropping with Desi Chana, Sarson, or Garlic).',
    sowingSeasonUr:
      'بہاریہ کاشت: 15 فروری تا 31 مارچ۔ ستمبر کاشت: یکم ستمبر تا 15 اکتوبر (ستمبر کاشت میں پیداوار 25 فیصد زیادہ ملتی ہے اور ساتھ چنا، سرسوں یا لہسن کی مخلوط کاشت ہو سکتی ہے)۔',
    soilAndClimateEn:
      'Deep, rich clay-loam soil with good drainage (Faisalabad, Jhang, Chiniot, Sargodha, Rahim Yar Khan, Nawabshah, Charsadda). Requires long warm growing season and cool dry ripening winter.',
    soilAndClimateUr:
      'گہری زرخیز بھاری میرا زمین (فیصل آباد، جھنگ، چنیوٹ، سرگودھا، رحیم یار خان، نوابشاہ، چارسدہ)۔ لمبا گرم موسمِ گرما اور مٹھاس بننے کے لیے ٹھنڈا خشک موسمِ سرما۔',
    seedSelectionEn:
      'Use 100 to 120 maunds (30,000 two-budded or 20,000 three-budded healthy cane setts / Simmay) per acre from top 2/3rd of disease-free 10-month crop (CPF-249, CPF-253, HSF-240).',
    seedSelectionUr:
      'بیماری سے پاک فصل کے اوپری دو تہائی حصے سے تیار کردہ دو یا تین آنکھوں والے 20 سے 30 ہزار صحت مند سمے (تقریباً 100 تا 120 من) فی ایکڑ استعمال کریں۔',
    cultivationGuideEn:
      'Plant in deep trenches 4 feet apart (deep trench technology). Perform earthing-up (Mitti charhana) in May–June to prevent lodging during windstorms.',
    cultivationGuideUr:
      'چار فٹ کے فاصلے پر گہری کھائیوں (ٹرینچ) میں کاشت کریں۔ مئی اور جون میں مڈھوں کے گرد مٹی چڑھائیں تاکہ آندھی سے گنا نہ گرے۔',
    irrigationGuidanceEn:
      'Requires 16 to 20 irrigations across the year: every 8–10 days in hot summer (May–June), 15–20 days in monsoon, and 25–30 days in winter.',
    irrigationGuidanceUr:
      'سال بھر میں تقریباً 16 تا 20 پانی درکار ہوتے ہیں: مئی جون کی گرمی میں 8 تا 10 دن بعد اور سردیوں میں 25 تا 30 دن کے وقفے سے پانی لگائیں۔',
    fertilizerGuidanceEn:
      'Heavy organic matter requirement: apply 6–8 trolleys farmyard manure or filter-press mud before trenching, plus balanced phosphorus, potash, and nitrogen completed before July.',
    fertilizerGuidanceUr:
      'بوائی سے قبل 6 تا 8 ٹرالیاں گوبر کی کھاد یا شوگر مل کی پریس مڈ ڈالیں۔ تمام نائٹروجن کھاد جولائی سے پہلے مکمل کر لیں تاکہ گنے میں مٹھاس کم نہ ہو۔',
    pestsAndDiseasesEn:
      'Red Rot (Ratta Rog — fatal fungal disease), Gurdaspur Borer, Top Borer, and Pyrilla (Ghori). Never use ratoon seed from red-rot infected fields; release Trichogramma cards.',
    pestsAndDiseasesUr:
      'رتہ روگ (سرخ سڑن)، چوٹی کی سنڈی، گرداسپور بورر اور گھوڑی (پائریلا)۔ رتہ روگ سے بچاؤ کے لیے متاثرہ کھیت کا بیج ہرگز استعمال نہ کریں۔',
    harvestingInfoEn:
      'Harvest from November to March when Brix reading reaches 18–20%. Cut stalks flush with the ground using a sharp Toka to encourage strong ratoon (Moodhi) sprouting.',
    harvestingInfoUr:
      'نومبر سے مارچ کے دوران جب گنے میں مٹھاس پوری ہو جائے تو تیز ٹوکے سے زمین کے بالکل برابر کٹائی کریں تاکہ موڈھی فصل کا اگاؤ بہترین ہو۔',
  },
  {
    id: 'crop-mustard',
    nameEn: 'Mustard / Rapeseed (Sarson / Raya)',
    nameUr: 'سرسوں / رایا (Mustard)',
    botanicalName: 'Brassica campestris / Brassica juncea',
    category: 'cash_oilseeds',
    linkedSeedCategory: 'traditional',
    image: '/src/assets/images/crop_mustard_sarson_1793416233841.jpg',
    estimatedDurationEn: '110 – 130 Days (Rabi Oilseed)',
    estimatedDurationUr: '110 تا 130 دن (ربیع کی تیلدار فصل)',
    sowingSeasonEn:
      'Throughout Pakistan (Thal, Cholistan, Barani Potohar, Central Punjab & Sindh): 25th September to 15th November.',
    sowingSeasonUr:
      'تھل، چولستان، بارانی پوٹھووار، وسطی پنجاب اور سندھ میں: 25 ستمبر تا 15 نومبر۔',
    soilAndClimateEn:
      'Thrives in light sandy loam to medium loam soils, including rain-fed (Barani) and marginally saline lands. Cool dry winter favors high oil content (38–42%).',
    soilAndClimateUr:
      'ہلکی ریتلی میرا سے درمیانی میرا زمین اور بارانی علاقوں میں انتہائی کامیاب۔ ٹھنڈا اور خشک موسم بیج میں تیل کی مقدار (38 تا 42 فیصد) بڑھاتا ہے۔',
    seedSelectionEn:
      '1.5 to 2 kg pure seed per acre. Heirloom Peeli Sarson, Desi Toria, Khanpur Raya, and Super Canola (sweet edible oil varieties).',
    seedSelectionUr:
      'صرف ڈیڑھ سے دو کلوگرام بیج فی ایکڑ۔ خالص دیسی پیلی سرسوں، توریا، خانپور رایا اور سپر کینولا۔',
    cultivationGuideEn:
      'Mix fine seed with moist sand for uniform drill sowing in rows 45 cm (1.5 feet) apart. Thin plants to 6–8 inches apart at 20 days after germination.',
    cultivationGuideUr:
      'باریک بیج کو تر ریت میں ملا کر ڈیڑھ فٹ کے فاصلے پر قطاروں میں کاشت کریں۔ اگاؤ کے 20 دن بعد پودوں کا درمیانی فاصلہ 6 تا 8 انچ کر دیں۔',
    irrigationGuidanceEn:
      'Extremely water-efficient: requires only 2 to 3 irrigations (1st at 30 days / branching stage, 2nd at flowering, 3rd at pod filling).',
    irrigationGuidanceUr:
      'انتہائی کم پانی کی ضرورت: پوری فصل میں صرف 2 سے 3 پانی کافی ہیں (پہلا شاخیں نکلتے وقت، دوسرا پھول آنے پر اور تیسرا پھلیاں بنتے وقت)۔',
    fertilizerGuidanceEn:
      'Sulfur is critical for oil synthesis in mustard: prefer Single Super Phosphate (SSP) or Ammonium Sulfate along with farmyard compost.',
    fertilizerGuidanceUr:
      'تیلدار فصلوں میں گندھک (سلفر) تیل کی مقدار بڑھاتی ہے، اس لیے سنگل سپر فاسفیٹ یا سلفر والی کھاد کا استعمال فائدہ مند ہے۔',
    pestsAndDiseasesEn:
      'Mustard Aphid (Sarson ka Tela) during cloudy late-January weather, and Powdery Mildew. Early October sowing escapes peak aphid buildup.',
    pestsAndDiseasesUr:
      'جنوری اور فروری کے ابر آلود موسم میں سرسوں کا تیلہ۔ اکتوبر کی اگیتی کاشت تیلے کے حملے سے قدرتی طور پر محفوظ رہتی ہے۔',
    harvestingInfoEn:
      'Harvest in late February to March when 75% of siliquae (pods) turn golden yellow. Do not wait for dead-ripe stage or pods will shatter in the field.',
    harvestingInfoUr:
      'فروری کے آخر سے مارچ میں جب 75 فیصد پھلیاں زرد سنہری ہو جائیں تو صبح کے وقت کٹائی کر لیں تاکہ پھلیاں چٹخ کر دانے کھیت میں نہ گریں۔',
  },
  {
    id: 'crop-potato',
    nameEn: 'Potato (Aalu)',
    nameUr: 'آلو (Potato)',
    botanicalName: 'Solanum tuberosum',
    category: 'vegetables',
    linkedSeedCategory: 'vegetables',
    image: '/src/assets/images/crop_potato_onion_1793416232625.jpg',
    estimatedDurationEn: '90 – 110 Days',
    estimatedDurationUr: '90 تا 110 دن',
    sowingSeasonEn:
      'Autumn Crop (Main Crop in Okara, Sahiwal, Pakpattan, Kasur, Chiniot): 1st October to 10th November. Spring Crop: Jan–Feb. Hill Summer Crop (Kaghan, Swat, Gilgit, Kalat): April–May.',
    sowingSeasonUr:
      'خزاں کی بڑی فصل (اوکاڑہ، ساہیوال، پاکپتن، قصور، چنیوٹ): یکم اکتوبر تا 10 نومبر۔ بہاریہ فصل: جنوری تا فروری۔ پہاڑی علاقوں کی گرمائی فصل (سوات، کاغان، گلگت، قلات): اپریل تا مئی۔',
    soilAndClimateEn:
      'Loose, friable, well-drained sandy loam to silt loam soil rich in organic humus. Tuberization requires cool nights (15°C–18°C) and sunny days.',
    soilAndClimateUr:
      'نرم اور بھربھری زرخیز ریتلی میرا زمین جس میں پانی کا نکاس بہترین ہو۔ آلو بننے کے لیے رات کا ٹھنڈا موسم (15 تا 18 ڈگری) بہترین ہے۔',
    seedSelectionEn:
      '1200 to 1500 kg (12–15 bags of 100 kg) disease-free whole seed tubers (35–55 mm size) per acre. Popular red & white varieties: Sahiwal Red, Kuroda, Santana, Desiree, Sadaf.',
    seedSelectionUr:
      '12 سے 15 بوری (1200 تا 1500 کلوگرام) بیماری سے پاک گول صحت مند بیج فی ایکڑ۔ مشہور سرخ اور سفید اقسام: ساہیوال ریڈ، کروڈا، ڈیزائری اور صدف۔',
    cultivationGuideEn:
      'Pre-sprout seed tubers in diffused shade for 10 days before planting. Plant on 28-inch ridges with 6–8 inch tuber spacing and earth up soil to prevent greening of tubers.',
    cultivationGuideUr:
      'بوائی سے 10 دن قبل بیج کو سایہ دار جگہ پر پھیلا کر شگوفے نکلنے دیں۔ 28 انچ چوڑی کھیلیوں پر کاشت کریں اور آلوؤں کو دھوپ سے سبز ہونے سے بچانے کے لیے مٹی چڑھائیں۔',
    irrigationGuidanceEn:
      'Light, frequent irrigations every 7–10 days. Water must never overtop the ridges (keep water up to 2/3rd height of ridge). Light irrigation on frosty January nights protects crop from frost injury.',
    irrigationGuidanceUr:
      'ہر 7 تا 10 دن بعد ہلکا پانی لگائیں۔ پانی کھیلیوں کے اوپر نہ چڑھنے دیں۔ جنوری میں کورے کی راتوں میں ہلکا پانی لگانے سے فصل کورے کے نقصان سے محفوظ رہتی ہے۔',
    fertilizerGuidanceEn:
      'Apply well-rotted FYM and Sulfate of Potash (SOP, not Chloride) for crisp skin quality, high starch content, and longer cold-storage life.',
    fertilizerGuidanceUr:
      'گوبر کی کھاد اور سلفیٹ آف پوٹاش (SOP) کا استعمال آلو کے سائز، چمک اور اسٹوریج کی عمر بڑھانے کے لیے انتہائی ضروری ہے۔',
    pestsAndDiseasesEn:
      'Late Blight (agaiti/pachhaiti jhulsaao) during foggy humid December/January weather, Common Scab, and Aphids (virus vectors). Inspect lower leaves daily during fog spells.',
    pestsAndDiseasesUr:
      'دسمبر اور جنوری کی دھند میں اگیتا اور پچھیتا جھلساؤ اور سست تیلہ۔ دھند کے دنوں میں نچلے پتوں کا روزانہ معائنہ کریں۔',
    harvestingInfoEn:
      'Cut haulms (vines) 12–15 days before digging in January–February so tuber skin hardens (curing). Cure harvested potatoes in shade for 10 days before grading.',
    harvestingInfoUr:
      'پٹائی سے 12 تا 15 دن پہلے آلو کی بیلیں کاٹ دیں تاکہ آلو کا چھلکا مضبوط ہو جائے۔ پٹائی کے بعد سایہ دار جگہ پر ڈھیر لگا کر درجہ بندی کریں۔',
  },
  {
    id: 'crop-onion',
    nameEn: 'Onion (Piyaz)',
    nameUr: 'پیاز (Onion / Piyaz)',
    botanicalName: 'Allium cepa',
    category: 'vegetables',
    linkedSeedCategory: 'vegetables',
    image: '/src/assets/images/crop_potato_onion_1793416232625.jpg',
    estimatedDurationEn: '125 – 145 Days (After Transplanting)',
    estimatedDurationUr: '125 تا 145 دن (پنیری منتقلی کے بعد)',
    sowingSeasonEn:
      'Sindh (Hyderabad, Mirpurkhas, Sanghar): Nursery in Aug–Sept, transplant Oct–Nov. Punjab: Nursery in Oct–Nov, transplant Dec–Jan. Balochistan (Kalat, Mastung, Khuzdar) & Swat: Nursery in Feb–March, transplant April–May.',
    sowingSeasonUr:
      'سندھ (حیدرآباد، میرپورخاص): پنیری اگست تا ستمبر۔ پنجاب: پنیری اکتوبر تا نومبر، منتقلی دسمبر تا جنوری۔ بلوچستان (قلات، مستونگ) اور سوات: پنیری فروری تا مارچ۔',
    soilAndClimateEn:
      'Friable fertile loam soil free of clods and weeds. Mild cool temperatures during vegetative leaf growth, followed by warm dry long days for bulb enlargement.',
    soilAndClimateUr:
      'ڈھیلوں اور جڑی بوٹیوں سے پاک نرم زرخیز میرا زمین۔ پتے بننے کے لیے معتدل ٹھنڈا موسم اور گنڈھے موٹے ہونے کے لیے خشک گرم موسم موزوں ہے۔',
    seedSelectionEn:
      '3 to 4 kg high-viability black onion seed (Kalonji-lookalike Allium seed) per acre to raise nursery. Heirloom Pakistani varieties: Phulkara, Nasarpuri (Sindh), Dark Red, Swat-1, Sariab Surkh.',
    seedSelectionUr:
      'پنیری تیار کرنے کے لیے 3 سے 4 کلوگرام تازہ بیج فی ایکڑ (پیاز کے پرانے بیج کی اگاؤ کی شرح کم ہو جاتی ہے)۔ مشہور دیسی اقسام: پھلکارہ، نصرپوری، ڈارک ریڈ، سوات-1 اور سریاب سرخ۔',
    cultivationGuideEn:
      'Transplant pencil-thick seedlings at 4-inch plant spacing on both sides of flat beds or low ridges. Shallow hoeing is essential as onion roots stay in the top 6 inches of soil.',
    cultivationGuideUr:
      'پنسل کی موٹائی جتنی پنیری کو پٹڑیوں کے دونوں کناروں پر 4 انچ کے فاصلے پر لگائیں۔ پیاز کی جڑیں اوپری تہہ میں ہوتی ہیں، اس لیے ہلکی گوڈی کریں۔',
    irrigationGuidanceEn:
      'Irrigate immediately after transplanting, then every 10–12 days in winter and 7 days in April. Stop irrigation 15–20 days before harvest when necks soften and tops fall over.',
    irrigationGuidanceUr:
      'منتقلی کے فوراً بعد پانی لگائیں، سردیوں میں 10 تا 12 دن اور اپریل میں 7 دن بعد پانی دیں۔ جب پودوں کی گردن نرم ہو کر گرنے لگے تو پٹائی سے 15 دن پہلے پانی بند کر دیں۔',
    fertilizerGuidanceEn:
      'Apply composted manure, phosphorus, and sulfur-based potash. Avoid late nitrogen application in March/April as it causes thick necks and poor storage life.',
    fertilizerGuidanceUr:
      'گوبر کی کھاد، فاسفورس اور سلفر والی پوٹاش استعمال کریں۔ پیاز بنتے وقت نائٹروجن کھاد ہرگز نہ دیں ورنہ پیاز ذخیرہ کرنے کے دوران گل جاتا ہے۔',
    pestsAndDiseasesEn:
      'Onion Thrips (tiny yellow/black insects hiding inside central leaf folds) and Purple Blotch fungus. Keep fields weed-free and avoid overhead sprinkler wetting.',
    pestsAndDiseasesUr:
      'پیاز کا تھرپس (گبھ کے اندر چھپے باریک کیڑے) اور جامنی دھبوں کی بیماری (پرپل بلاچ)۔ جڑی بوٹیاں تلف کریں اور کھیت میں نمی زیادہ نہ بڑھنے دیں۔',
    harvestingInfoEn:
      'Pull bulbs when 50–70% of leaves topple naturally. Cure bulbs in windrows shaded by their own leaves for 5–7 days, then trim tops leaving a 1.5-inch neck.',
    harvestingInfoUr:
      'جب 60 فیصد پودوں کی بھوئیں زمین پر گر جائیں تو پیاز نکال لیں۔ سائے میں 5 تا 7 دن خشک کرنے کے بعد ڈیڑھ انچ ڈنٹھل چھوڑ کر پتے کاٹیں۔',
  },
  {
    id: 'crop-tomato',
    nameEn: 'Tomato (Tamatar)',
    nameUr: 'ٹماٹر (Tomato)',
    botanicalName: 'Solanum lycopersicum',
    category: 'vegetables',
    linkedSeedCategory: 'vegetables',
    image: '/src/assets/images/crop_tomato_orchard_1793416234014.jpg',
    estimatedDurationEn: '110 – 135 Days',
    estimatedDurationUr: '110 تا 135 دن',
    sowingSeasonEn:
      'Punjab Plains: Autumn/Winter nursery in Sept–Oct; Spring nursery in Nov–Dec (transplanted Feb). Sindh (Badin, Thatta): Aug–Oct. KP & Balochistan uplands: March–April.',
    sowingSeasonUr:
      'پنجاب: پہلی فصل کی پنیری ستمبر تا اکتوبر اور بہاریہ فصل کی پنیری نومبر تا دسمبر۔ سندھ (بدین، ٹھٹھہ): اگست تا اکتوبر۔ بلوچستان اور سوات: مارچ تا اپریل۔',
    soilAndClimateEn:
      'Well-drained loamy soil rich in organic compost. Optimal fruit set occurs when night temperatures are between 15°C and 22°C; protect winter nursery from frost with low plastic/sarkanda tunnels.',
    soilAndClimateUr:
      'نامیاتی کھاد سے بھرپور زرخیز میرا زمین۔ پھل بننے کے لیے رات کا درجہ حرارت 15 تا 22 ڈگری بہترین ہے۔ جنوری میں کورے سے بچاؤ کے لیے سرکنڈے یا شاپر کی لو ٹنل بنائیں۔',
    seedSelectionEn:
      '150 to 200 grams open-pollinated Desi seed per acre. Traditional Pakistani varieties: Nagina, Roma, Moneymaker, Pakit, Rio Grande (seeds can be fermented and saved from ripe fruits).',
    seedSelectionUr:
      'ایک ایکڑ کی پنیری کے لیے 150 تا 200 گرام خالص دیسی بیج کافی ہے۔ مشہور اقسام: نگینہ، روما، منی میکر اور ریو گرانڈے جن کا بیج پکے ٹماٹروں سے خود تیار کیا جا سکتا ہے۔',
    cultivationGuideEn:
      'Transplant 30-day-old seedlings on one side of 4-foot wide raised beds with 18-inch plant spacing. Stake indeterminate varieties with bamboo sticks to keep fruits off wet soil.',
    cultivationGuideUr:
      '30 دن کی پنیری کو 4 فٹ چوڑی پٹڑیوں کے کنارے 18 انچ کے فاصلے پر لگائیں۔ پودوں کو بانس کی چھڑیوں کا سہارا دیں تاکہ پھل گیلی مٹی سے خراب نہ ہو۔',
    irrigationGuidanceEn:
      'Maintain uniform soil moisture with weekly furrow irrigation. Fluctuating dry-and-flooded cycles cause Blossom End Rot (black bottom spot) and fruit cracking.',
    irrigationGuidanceUr:
      'زمین میں یکساں وتر برقرار رکھیں۔ سوکھے کے بعد اچانک زیادہ پانی لگانے سے ٹماٹر پھٹ جاتے ہیں اور نچلے حصے پر سیاہ دھبہ (کیلشیم کی کمی) پڑ جاتا ہے۔',
    fertilizerGuidanceEn:
      'Incorporate vermicompost/FYM and calcium + boron during flowering to ensure firm, crack-resistant red tomatoes.',
    fertilizerGuidanceUr:
      'گوبر کی کھاد کے ساتھ پھول اور پھل بنتے وقت کیلشیم اور بوران کی فراہمی پھل کو مضبوط اور چمکدار بناتی ہے۔',
    pestsAndDiseasesEn:
      'Fruit Borer (American Sundi), Leaf Miner, Early/Late Blight, and Leaf Curl Virus (transmitted by whitefly). Intercrop with marigold (Gainda) flowers as a natural trap crop for fruit borers.',
    pestsAndDiseasesUr:
      'پھل کی سنڈی، لیف مائنر، جھلساؤ اور پتہ مروڑ وائرس۔ ٹماٹر کے کھیت کے کنارے گیندے کے پھول لگانے سے سنڈیاں ٹماٹر کے بجائے گیندے پر جاتی ہیں۔',
    harvestingInfoEn:
      'Pick at breaker/pink stage for distant city mandis, or vine-ripe red stage for local sale and heirloom seed extraction.',
    harvestingInfoUr:
      'دور کی منڈیوں کے لیے گلابی رنگت آنے پر اور مقامی فروخت یا بیج بنانے کے لیے مکمل سرخ پکنے پر تڑائی کریں۔',
  },
  {
    id: 'crop-seasonal-fruits-veg',
    nameEn: 'Seasonal Fruits & Desi Vegetables (Mango, Kinnow, Bhindi, Karela)',
    nameUr: 'موسمی پھل اور دیسی سبزیاں (آم، کنو، بھنڈی، کریلا)',
    botanicalName: 'Mangifera indica / Citrus reticulata / Abelmoschus esculentus',
    category: 'fruits_seasonal',
    linkedSeedCategory: 'fruits',
    image: '/src/assets/images/seed_heirloom_vegetables_1793414538472.jpg',
    estimatedDurationEn: 'Summer Veg: 60–85 Days · Orchards: Perennial',
    estimatedDurationUr: 'سبزیاں: 60 تا 85 دن · باغات: سدا بہار',
    sowingSeasonEn:
      'Summer Vegetables (Bhindi, Karela, Tinda, Turi, Kaddu): 15th Feb to 30th March & Monsoon June–July. Orchard Saplings & Rootstock Stones (Mango, Citrus, Guava, Falsa): Spring (Feb–March) and Monsoon (Aug–Sept).',
    sowingSeasonUr:
      'گرمیوں کی سبزیاں (بھنڈی، کریلا، ٹنڈے، توری، کدو): 15 فروری تا آخر مارچ اور برسات جون تا جولائی۔ پھلدار باغات (آم، کنو، امرود، فالسہ): بہار (فروری تا مارچ) اور برسات (اگست تا ستمبر)۔',
    soilAndClimateEn:
      'Orchards require deep, salt-free loamy soil at least 6 feet deep without a hardpan (Kankar layer) in Multan, Rahim Yar Khan, Mirpurkhas (Mango) and Sargodha, Bhalwal, Toba Tek Singh (Kinnow).',
    soilAndClimateUr:
      'باغات کے لیے کم از کم 6 فٹ گہری، کلر اور کنکر کی تہہ سے پاک زرخیز میرا زمین (ملتان، رحیم یار خان، میرپورخاص آم کے لیے اور سرگودھا، بھلوال کنو کے لیے)۔',
    seedSelectionEn:
      'Bhindi: 6–8 kg/acre (soak in water for 12 hours before sowing). Karela/Turi: 2–2.5 kg/acre. Mango/Citrus rootstock: fresh Desi mango stones and Kharna Khatta / Rough Lemon seeds.',
    seedSelectionUr:
      'بھنڈی: 6 تا 8 کلو بیج فی ایکڑ (بوائی سے قبل 12 گھنٹے پانی میں بھگوئیں)۔ کریلا اور توری: 2 تا ڈھائی کلو فی ایکڑ۔ باغات کی پنیری کے لیے دیسی آم کی گٹھلیاں اور کھٹی کا تازہ بیج۔',
    cultivationGuideEn:
      'Sow summer gourd vines on wide raised beds (5–6 feet apart) or train onto bamboo trellises (Baan/Jaal) to double yield and prevent soil rot during monsoon rains.',
    cultivationGuideUr:
      'کریلا، توری اور گھیا کدو کو 5 فٹ چوڑی پٹڑیوں پر کاشت کریں یا بانس اور رسی کے جال پر چڑھائیں جس سے پیداوار دگنی اور پھل صاف ملتا ہے۔',
    irrigationGuidanceEn:
      'Summer vegetables need light irrigation every 5–7 days. For mango & citrus orchards, use basin ring irrigation (keep water away from the main trunk collar to prevent Gummosis/Collar Rot).',
    irrigationGuidanceUr:
      'گرمیوں کی سبزیوں کو ہر 5 تا 7 دن بعد پانی دیں۔ آم اور کنو کے باغات میں تنے کے گرد مٹی کی ڈھیری بنائیں تاکہ پانی براہِ راست تنے کو نہ لگے (گوند نکلنے کی بیماری سے بچاؤ)۔',
    fertilizerGuidanceEn:
      'Apply farmyard manure + bone meal/SSP and potash inside the canopy drip-line of orchard trees in December–January before spring flowering.',
    fertilizerGuidanceUr:
      'باغات میں دسمبر اور جنوری کے دوران پودے کے پھیلاؤ (چھتری کے سائے) کے نیچے گوبر کی کھاد، فاسفورس اور پوٹاش ڈال کر گوڈی کریں۔',
    pestsAndDiseasesEn:
      'Fruit Fly (Phal ki Makhi — major pest of Mango, Guava, Melon, Karela) and Mango Hopper. Hang Methyl Eugenol / Cue-Lure pheromone traps (4–6 traps/acre) from flowering onward.',
    pestsAndDiseasesUr:
      'پھل کی مکھی (فروٹ فلائی) آم، امرود، خربوزے اور کریلے کا سب سے بڑا دشمن ہے۔ پھول آنے سے ہی کھیت میں فی ایکڑ 4 سے 6 فرومون ٹریپس (جنس کشش کے ڈبے) لٹکائیں۔',
    harvestingInfoEn:
      'Pick okra every alternate day when pods snap easily. Leave 5% of your best first-flush vegetable pods on the plant until fully dry to harvest pure heirloom seeds for next year!',
    harvestingInfoUr:
      'بھنڈی کی ہر دوسرے دن تڑائی کریں۔ اگلے سال کا خالص دیسی بیج بنانے کے لیے صحت مند پودوں کے بہترین پھل پودے پر ہی پک کر خشک ہونے کے لیے چھوڑ دیں۔',
  },
];
